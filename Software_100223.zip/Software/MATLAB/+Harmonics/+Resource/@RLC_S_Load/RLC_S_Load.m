classdef RLC_S_Load
    properties(SetAccess=private)
        node;
        index;
%         R;
%         L;
%         C;
        alpha;
    end
    
    properties
        P_reference;
        Q_reference;
    end
    
    methods
        function obj = RLC_S_Load(node,index,P_reference,Q_reference,alpha)%,R,L,C
            % obj = RLC_S_Load(node,R,L,C,P_reference,Q_reference,alpha)
            import Harmonics.Resource.*;
            
            if(~isa(node,'char'))
                error('node: type.');
            elseif(~isa(index,'numeric'))
                error('index:type.')
%             elseif(~isa(R,'numeric'))
%                 error('R: type.');
%             elseif(~isa(L,'numeric'))
%                 error('L: type.');
%             elseif(~isa(C,'numeric'))
%                 error('C: type.');
            elseif(~isa(P_reference,'numeric'))
                error('P_reference: type.');
            elseif(~isa(Q_reference,'numeric'))
                error('Q_reference: type.');
            elseif(~isa(alpha,'numeric'))
                error('alpha: type.');
            else
            
                obj.node = node;
                obj.index = index;
                obj.P_reference = P_reference;
                obj.Q_reference = Q_reference;
%                 obj.R = R;
%                 obj.L = L;
%                 obj.C = C;
                obj.alpha = alpha;
            end
        end
        
        I_h = calculateResponse(obj,f_1,h_max,V_h,base);
        [Ih,dIh_dVh] = calculateGridResponse(obj,f_1,h_max,V_h,base);
        
        [outSim] = runTimeDomainSimulation(obj,folder,modelName,converterName,variantName,h_max,Ts)
        [] = initializeTimeDomainSimulation(obj,modelName,converterName,variantName);
    end
    
    methods(Static)
        load = buildFromFile(file,number_of_wires,base,f_1);
    end
end

