function [W_K,dW_KP] = calculateReference(obj,h_max,base)
% [W_K,dW_KP] = calculateReference(obj,h_max,base)

import Harmonics.*;

h = 0:1:(h_max+1);
h = h(:);

VR_h = zeros(obj.internal_transform.getSizeOfCodomain(),length(h));
VR_h(:,1) = sqrt(3/2) * obj.V_reference * [1;0];
VR_h = VR_h/base.getBaseVoltage();

W_K = Fourier.buildVector(h,VR_h);

n_W_K = length(W_K);
n_W_P = obj.internal_transform.getSizeOfDomain()*(2*h_max+1);
dW_KP = zeros(n_W_K,n_W_P);

end