function results = analyseMultipleSpectra(h,X_0_h,X_1_h,X_2_h,X_3_h)

if(~all(size(X_0_h)==size(X_1_h)))
    error('Spectra.');
elseif(~all([]==length(h)))
    dips('Harmonics.');
else
    tol_ignore = 1e-3;
    idx_ignore = find(max(abs(X_1_h),[],1)<tol_ignore);
    h(idx_ignore) = [];
    X_0_h(:,idx_ignore) = [];
    X_1_h(:,idx_ignore) = [];
    X_2_h(:,idx_ignore) = [];
    X_3_h(:,idx_ignore) = [];
    
    e_1_abs = (abs(X_1_h)-abs(X_0_h))./abs(X_0_h)*100;
    e_1_arg = (angle(X_1_h)-angle(X_0_h))/pi*180;
    e_1_arg(e_1_arg>180) = 360 - e_1_arg(e_1_arg>180);
    
    e_1_abs_max = max(e_1_abs,[],1);
    e_1_arg_max = max(abs(e_1_arg),[],1);
 
    e_2_abs = (abs(X_2_h)-abs(X_0_h))./abs(X_0_h)*100;
    e_2_arg = (angle(X_2_h)-angle(X_0_h))/pi*180;
    e_2_arg(e_2_arg>180) = 360 - e_2_arg(e_2_arg>180);
    
    e_2_abs_max = max(e_2_abs,[],1);
    e_2_arg_max = max(abs(e_2_arg),[],1);

    e_3_abs = (abs(X_3_h)-abs(X_0_h))./abs(X_0_h)*100;
    e_3_arg = (angle(X_3_h)-angle(X_0_h))/pi*180;
    e_3_arg(e_3_arg>180) = 360 - e_3_arg(e_3_arg>180);
    
    e_3_abs_max = max(e_3_abs,[],1);
    e_3_arg_max = max(abs(e_3_arg),[],1);
 

    data = [h(:),e_1_abs_max(:),e_2_abs_max(:),e_3_abs_max(:),...
                 e_1_arg_max(:),e_2_arg_max(:),e_3_arg_max(:)];
    names = {'h','e_1_abs_pct','e_2_abs_pct','e_3_abs_pct',...
                 'e_1_arg_deg','e_2_arg_deg','e_3_arg_deg'};
    results = table(data(:,1),data(:,2),data(:,3),data(:,4),...
                    data(:,5),data(:,6),data(:,7),'VariableNames',names);
end


end