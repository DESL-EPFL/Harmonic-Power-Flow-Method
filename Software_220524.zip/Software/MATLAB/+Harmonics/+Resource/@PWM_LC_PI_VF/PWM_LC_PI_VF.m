classdef PWM_LC_PI_VF < Harmonics.Resource.CIR_V
    %   PWM_LC_PI_PQ represents a converter-interfaced resource
    %   which consists of the following components:
    %   -   actuator: pulse-widh modulator (PWM)
    %   -   filter: inductor + capacitor (LC)
    %   -   controller: proportional-integral (PI) cascade
    %   -   reference: active/reactive power (PQ)
    
    properties(SetAccess=private)
        L_stage;    % Actuator-side inductive stage.
        C_stage;    % Grid-side capacitive stage.
        V_reference;
        f_reference;
    end
    
    methods
        function obj = PWM_LC_PI_VF(node,index,L_stage,C_stage,V_reference,f_reference,base)
            % obj = PWM_LC_PI_PQ(node,L_stage,C_stage,V_reference,f_nominal,base)
            
            import Harmonics.Resource.*;
            
            control_software = PWM_LC_PI_VF.buildControlSoftware(L_stage,C_stage,f_reference,base);
            
            power_hardware = PWM_LC_PI_VF.buildPowerHardware(L_stage,C_stage,f_reference,base);
            internal_transform = PWM_LC_PI_VF.buildInternalTransform();
            external_transform = PWM_LC_PI_VF.buildExternalTransform();
            
            obj = obj@Harmonics.Resource.CIR_V(node,index,power_hardware,control_software,internal_transform,external_transform);
            
            obj.L_stage = L_stage;
            obj.C_stage = C_stage;
            
            if(~isa(V_reference,'numeric'))
                error('V_reference: type.');
            elseif(~isa(f_reference,'numeric'))
                error('f_reference: type.');
            elseif(~all(size(V_reference)==1))
                error('V_reference: size.');
            elseif(~all(size(f_reference)==1))
                error('f_reference: size.');
            else
                obj.V_reference = V_reference;
                obj.f_reference = f_reference;
            end
        end
        
        function n_stages = getNumberOfStages(obj)
            % n_stages = getNumberOfStages(obj)
            n_stages = 2; % L+C
        end
        
        function l_operating = getLengthOfOperatingPoint(obj)
            % l_operating = getLengthOfOperatingPoint(obj)
            l_operating = 0;
        end

        % Implement abstract methods
        
        [Vh,dVh_dIh,Oh] = calculateGridResponse(obj,Ts,f_1,h,Ih,Oh,base);
        [W_K,dW_KP] = calculateReference(obj,h_max,base);
        [G_PP,G_PK,G_KP,G_KK] = calculateInternalGain(obj,Ts,f_1,h_max);
        [VA_h,IA_h,VG_h] = calculateInternalResponse(obj,Ts,f_1,h,IG_h,base);
        [T_PG,T_GP] = calculateExternalTransform(obj,h_max);
        [T_KP,T_PK] = calculateInternalTransform(obj,Ts,f_1,h_max);
        
        [outSim] = runTimeDomainSimulation(obj,folder,modelName,converterName,h_max,Ts);
        initializeTimeDomainSimulation(obj,modelName,converterName);
    end
    
    methods(Static)
        % Implement abstract methods;
        
        resource = buildFromFile(file,base);
        power_hardware = buildPowerHardware(L_stage,C_stage,f_1,base);
        control_software = buildControlSoftware(L_stage,C_stage,f_1,base);
        
        function transform = buildExternalTransform()
            import Harmonics.Resource.*;
            
            transform = WyeWye_Connection('yes','yes');
        end
        
        function transform = buildInternalTransform()
            import Harmonics.Resource.*;
            
            transform = DQ_Transform();
        end
    end
end