function [found,indices] = findByName(nodes,names)
% [found,indices] = find(nodes,names)

import Harmonics.Grid.*;

if(~isa(nodes,'Node'))
    error('nodes: type.');
elseif(~isa(names,'cell'))
    error('names: type.');
else
    [found,indices] = ismember(names,{nodes.name});
end

end