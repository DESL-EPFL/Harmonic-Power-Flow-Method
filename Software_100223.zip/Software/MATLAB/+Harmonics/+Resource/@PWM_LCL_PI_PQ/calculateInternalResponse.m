function [VA_h,IA_h,VF_h,IG_h] = calculateInternalResponse(obj,Ts,f_1,h,VG_h,base)
% [VA_h,IA_h,VF_h,IG_h] = calculateInternalResponse(obj,Ts,f_1,h,VG_h,base)
% 
% INPUT
% - Ts          Sampling time.
% - f_1         Fundamental frequency.
% - h           Harmonic orders (w.r.t. the fundamental frequency)
% - VG_h        Fourier coefficients of the grid voltage.
% - base        Per-unit base.
% 
% OUTPUT
% - VA_h        Fourier coefficients of the actuator voltage.
% - IA_h        Fourier coefficients of the actuator current.
% - VF_h        Fourier coefficients of the filter voltage.
% - IG_h        Fourier coefficients of the grid current.

import Harmonics.*;

h_max = max(h);

%% Input

W_P = Fourier.buildVector(h,VG_h);

%% Internal Response

[T_abc2pnz,~] = PNZ_Transform.build();
V1_ABC = VG_h(:,h==1);
V1_PNH = T_abc2pnz*V1_ABC;
theta0 = angle(V1_PNH(1));

[W_K,~] = calculateReference(obj,W_P,theta0,h_max,base);

[G_PP,G_PK,G_KP,G_KK] = obj.calculateInternalGain(theta0,Ts,f_1,h_max);

Y_P = G_PP * W_P + G_PK * W_K;
Y_K = G_KP * W_P + G_KK * W_K;

%% Assign Outputs

[~,Y_K_h] = Fourier.splitVector(Y_K,obj.control_software.getNumberOfOutputs);
VA_h = Y_K_h;

[~,Y_P_h] = Fourier.splitVector(Y_P,obj.power_hardware.getNumberOfOutputs);
n_P = obj.internal_transform.getSizeOfDomain;
IA_h = Y_P_h(1:n_P,:);
VF_h = Y_P_h((1:n_P)+n_P,:);
IG_h = Y_P_h((1:n_P)+2*n_P,:);

end

