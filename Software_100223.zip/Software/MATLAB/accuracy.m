function [results_V,results_I] = accuracy(V_h,I_h,idx_1,idx_2,h,h_max)

tolerance = 1e-4;

X_h = [V_h;I_h];
setStr = {'1','2'};

for i = 1:2
    % Magnitude
    e_abs_1 = errorCalculation(X_h(i).TDS(idx_1,:),X_h(i).HPF(idx_1,:),'abs',tolerance);
    e_abs_2 = errorCalculation(X_h(i).TDS(idx_2,:),X_h(i).HPF(idx_2,:),'abs',tolerance);
    e_abs = [e_abs_1;e_abs_2];
    
    [max_abs_i,h_abs_i] = max(e_abs,[],2);
    [max_abs(i),ind_abs(i)] = max(max_abs_i);
    h_abs(i) = h_abs_i(ind_abs(i))-1;

    % Angle
    e_arg_1 = errorCalculation(X_h(i).TDS(idx_1,:),X_h(i).HPF(idx_1,:),'arg',tolerance);
    e_arg_2 = errorCalculation(X_h(i).TDS(idx_2,:),X_h(i).HPF(idx_2,:),'arg',tolerance);
    e_arg = [e_arg_1;e_arg_2];
    e_arg(:,setdiff(0:h_max,h)'+1) = 0;    
    e_arg(e_arg>180) = 360 - e_arg(e_arg>180);

    e_arg = e_arg*pi/180*1e3; % convert to mrad

    [max_arg_i,h_arg_i] = max(e_arg,[],2);
    [max_arg(i),ind_arg(i)] = max(max_arg_i);
    h_arg(i) = h_arg_i(ind_arg(i))-1;
end
    
data_V = [["e_abs_max (p.u.)";"e_arg_max (mrad)"],[max_abs(1);max_arg(1)],[h_abs(1);h_arg(1)],[setStr(ind_abs(1));setStr(ind_arg(1))]];
names = {'error','value','h','set'};
results_V = table(data_V(:,1),data_V(:,2),data_V(:,3),data_V(:,4),'VariableNames',names);

display(results_V)

data_I = [["e_abs_max (p.u.)";"e_arg_max (mrad)"],[max_abs(2);max_arg(2)],[h_abs(2);h_arg(2)],[setStr(ind_abs(2));setStr(ind_arg(2))]];
names = {'error','value','h','set'};
results_I = table(data_I(:,1),data_I(:,2),data_I(:,3),data_I(:,4),'VariableNames',names);

display(results_I)

end