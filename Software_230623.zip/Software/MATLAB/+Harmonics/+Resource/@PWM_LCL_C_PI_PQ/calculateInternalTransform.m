function [T_KP,T_PK] = calculateInternalTransform(obj,theta_0,Ts,f_1,h_max)
% [T_KP,T_PK] = calculateInternalTransform(obj,theta_0,h_max)

import Harmonics.*;

h = [0,obj.internal_transform.h];
[n_stages_phases,n_stages_dc] = obj.getNumberOfStages();

% Forward matrix

T_KP_0 = [repmat({zeros(size(obj.internal_transform.T_FW_h))},n_stages_phases,1);...
          repmat({1},n_stages_dc,1);...
          {zeros(size(obj.internal_transform.T_FW_h))}];
T_KP_0 = blkdiag(T_KP_0{:});

T_KP_1 = [repmat({obj.internal_transform.T_FW_h*exp(1i*theta_0)},n_stages_phases,1);...
          repmat({0},n_stages_dc,1);...
          {obj.internal_transform.T_FW_h*exp(1i*theta_0)}];
T_KP_1 = blkdiag(T_KP_1{:});

T_KP_h = zeros([size(T_KP_0),length(h)]);
T_KP_h(:,:,h==0) = T_KP_0;
T_KP_h(:,:,h==1) = T_KP_1;

T_KP = Toeplitz.buildRectangularMatrix(h,T_KP_h,h_max+1,h_max);

% Backward matrix

T_PK_0 = {zeros(size(obj.internal_transform.T_BW_h))};
T_PK_0 = blkdiag(T_PK_0{:});

T_PK_1 = {obj.internal_transform.T_BW_h*exp(1i*theta_0)};
T_PK_1 = blkdiag(T_PK_1{:});

T_PK_h = zeros([size(T_PK_0),length(h)]);
T_PK_h(:,:,h==0) = T_PK_0;
T_PK_h(:,:,h==1) = T_PK_1;

T_PK = Toeplitz.buildRectangularMatrix(h,T_PK_h,h_max,h_max+1);

% Delay

tau_h = repmat({zeros(3)},1,1,2*h_max+1);
h_0 = h_max+1;
       
for k = 1:h_max+1
    h_i = k-1;
    tau_h_i = eye(3)*exp(-1i*2*pi*(k-1)*f_1*Ts);
    
    if(h_i==0)
        tau_h{h_0} = tau_h_i;
    else
        tau_h{h_0+h_i} = tau_h_i;
        tau_h{h_0-h_i} = conj(tau_h_i);
    end
end
tau = blkdiag(tau_h{:});

T_PK = tau*T_PK;
end