classdef CIR < matlab.mixin.Heterogeneous
    % CIR is a Converter-Interfaced Resource (CIR).
    
    properties(SetAccess=private)
        node
        index
        power_hardware;
        control_software;
        internal_transform;
        external_transform;
    end
    
    methods
        function obj = CIR(node,index,power_hardware,control_software,internal_transform,external_transform)
            % obj = CIR(node,power_hardware,control_software,transform)
            
            import Harmonics.Resource.*;
            
            if(~isa(node,'char'))
                error('node: type.');
            elseif(~isa(index,'numeric'))
                error('index: type.')
            elseif(~isa(power_hardware,'LTP_System'))
                error('power_hardware: type.');
            elseif(~isa(control_software,'LTP_System'))
                error('control_software: type.');
            elseif(~isa(internal_transform,'LTP_Transform'))
                error('internal_transform: type.');
            elseif(~isa(external_transform,'LTP_Transform'))
                error('external_transform: type.');
            else
                obj.node = node;
                obj.index = index;
                obj.power_hardware = power_hardware;
                obj.control_software = control_software;
                obj.internal_transform = internal_transform;
                obj.external_transform = external_transform;
            end
        end
    end
    
    methods(Abstract)
        n_stages = getNumberOfStages(obj);
        l_operating = getLengthOfOperatingPoint(obj);
        
        % HPF
        outputs = calculateGridResponse(obj,inputs);
        outputs = calculateExternalTransform(obj,inputs);
        outputs = calculateInternalTransform(obj,inputs);
        outputs = calculateReference(obj,inputs);
        outputs = calculateInternalGain(obj,inputs);
        outputs = calculateInternalResponse(obj,inputs);
        
        % TDS
        outputs = runTimeDomainSimulation(obj,inputs);
        outputs = initializeTimeDomainSimulation(obj,inputs);
    end
    
    methods(Abstract,Static)
        outputs = buildFromFile(inputs);
        outputs = buildPowerHardware(inputs);
        outputs = buildControlSoftware(inputs);
        outputs = buildInternalTransform(inputs);
        outputs = buildExternalTransform(inputs);
    end
end