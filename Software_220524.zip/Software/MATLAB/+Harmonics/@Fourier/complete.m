function X_h_full = complete(h,X_h,h_max)
% X_h_full = complete(h,X_h,h_max)

if(~isa(h,'numeric'))
    error('h: type.');
elseif(~isa(X_h,'numeric'))
    error('X_h: type.');
elseif(~isa(h_max,'numeric'))
    error('h_max: type.');
elseif(~all(size(h_max))==1)
    error('h_max: size.');
else
    switch(ndims(X_h))
        case 2  % Vector quantity
            if(size(X_h,2)~=length(h))
                error('X_h: size.');
            else
                n_var = size(X_h,1);
                
                X_h_full = zeros(n_var,h_max+1);
                
                for k=1:length(h)
                    X_h_full(:,h(k)+1) = X_h(:,k);
                end
            end
        case 3  % Matrix quantity
            if(size(X_h,3)~=length(h))
                error('X_h: size.');
            else
                n_var_row = size(X_h,1);
                n_var_col = size(X_h,2);
                
                X_h_full = zeros(n_var_row,n_var_col,h_max+1);
                
                for k=1:length(h)
                    X_h_full(:,:,h(k)+1) = X_h(:,:,k);
                end
            end
        otherwise
            error('X_h: size.');
    end
end

end