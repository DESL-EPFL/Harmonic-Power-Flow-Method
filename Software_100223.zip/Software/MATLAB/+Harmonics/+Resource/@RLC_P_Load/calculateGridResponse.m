function [I_h,dIh_dVh] = calculateGridResponse(obj,f_1,h_max,V_h,base)

import Harmonics.*;

%% belongs in build from file
% Phase powers
S_ref_ph = obj.alpha*(obj.P_reference + 1j*obj.Q_reference)/3;

% Output impedance
V_rms = base.getBaseVoltage()/sqrt(2);
Y = conj(S_ref_ph)/V_rms^2;

if obj.P_reference == 0
    R0 = 0;
else
    R0 = 1./real(Y);
end

if obj.Q_reference <= 0
    L0 = 1./(imag(Y)*2*pi*f_1);
    C0 = zeros(size(L0));
else
    C0 = -imag(Y)/(2*pi*f_1);
    L0 = zeros(size(C0));
end

%%

% Base Values
Z_base = base.getBaseImpedance();

R = diag(R0) / Z_base;%obj.
L = diag(L0) / Z_base;
C = diag(C0) * Z_base;

Y_h = zeros(3,3,h_max+1,h_max+1);

k = 0;
if all(R0 == 0)
    Y_h(:,:,k+1,k+1) = 0;
else
    Y_h(:,:,k+1,k+1) = inv(R);
end

for k=1:h_max
    if all(R0 == 0)
        if all(L0 == 0)
            Y_h(:,:,k+1,k+1) = -1i*2*pi*f_1*k*C; 
        else
            Y_h(:,:,k+1,k+1) = -inv(1i*2*pi*f_1*k*L);
        end
    else
        if all(L0 == 0)
            Y_h(:,:,k+1,k+1) = inv(R) - 1i*2*pi*f_1*k*C; 
        else
            Y_h(:,:,k+1,k+1) = inv(R) - inv(1i*2*pi*f_1*k*L);
        end
    end
end

I_h = zeros(3,h_max+1);
for k=1:(h_max+1) % no coupling between harmonics
    I_h(:,k) = Y_h(:,:,k,k) * V_h(:,k);
end

dIh_dVh = Y_h;

end