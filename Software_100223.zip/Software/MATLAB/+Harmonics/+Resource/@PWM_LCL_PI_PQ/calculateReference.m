function [W_K,dW_KP] = calculateReferenceNew(obj,W_P,theta_0,h_max,base)
% ...

import Harmonics.*;

%% Preparation

n_ABC = obj.power_hardware.getNumberOfDisturbances();
n_DQ = obj.control_software.getNumberOfDisturbances();

T_RP = Toeplitz.buildRectangularMatrix(obj.internal_transform.h,obj.internal_transform.T_FW_h*exp(1i*theta_0),h_max+1,h_max);
W_R = T_RP * W_P;

%% Function value

% Step 1: Taylor approximation of 1/v_D(t)

V_DQ = W_R;
[h,V_DQ_h] = Fourier.splitVector(V_DQ,n_DQ);
n_h = length(h)-1;

V_D_h = V_DQ_h;
V_D_h(2,:) = V_D_h(1,:); % Replace Q-components by D-components.
V_D_0 = V_D_h(:,1);

xi_h = diag(1./V_D_0) * V_D_h(:,2:end);
xi = Fourier.buildVector((1:n_h)',xi_h);

diag_xi_h = zeros(n_DQ,n_DQ,n_h);
for k=1:n_h
    diag_xi_h(:,:,k) = diag(xi_h(:,k));
end
diag_xi = Toeplitz.buildSquareMatrix((1:n_h)',diag_xi_h,n_h);

id = Fourier.buildVector([0;n_h],[ones(n_DQ,1),zeros(n_DQ,1)]);

% Taylor series (2nd order)
inv_V_D = diag(1./repmat(V_D_0,2*n_h+1,1)) * (id - xi + diag_xi * xi);

% Step 2: Calculation of IR_DQ = [P;Q] * 1/v_D

S_DQ = [obj.P_reference;-obj.Q_reference] / base.getBasePower();
S_DQ = repmat(S_DQ,2*n_h+1,1);

I_DQ = S_DQ .* inv_V_D;

W_K = I_DQ;

%% Jacobian matrix

S_DQ = [obj.P_reference;-obj.Q_reference] / base.getBasePower();

% Extract V_d components
idx_D = 1:n_DQ:length(V_DQ);
V_D_h = V_DQ(idx_D);
T_D_h = T_RP(idx_D,:);

idx_D_0 = n_h+1;
V_D_0 = V_D_h(idx_D_0);
T_D_0 = T_D_h(idx_D_0,:);

dIdq_dVabc = zeros(size(T_RP));

j = 1:2;
for k = 1:length(idx_D)
    if k == idx_D_0
        dIdq_dVabc(j,:) = -S_DQ/(V_D_0^2) * T_D_0;
    else    
        dIdq_dVabc(j,:) = -S_DQ/(V_D_0^2) * (T_D_h(k,:)-2*V_D_h(k)/V_D_0 * T_D_0);
    end
    j = j+2;
end

%[~,dIdq_dVabc] = Fourier.splitMatrix(dIdq_dVabc,n_DQ,n_ABC);

dW_KP = dIdq_dVabc;

end