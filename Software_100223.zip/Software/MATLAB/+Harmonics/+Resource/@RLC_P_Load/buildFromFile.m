function load = buildFromFile(file,base,f_1)
% load = buildFromFile(file,base,f_1,type)

import Harmonics.*;
import Harmonics.Resource.*;

if(~isa(file,'char'))
    error('file: type.');
else
    
    
    %% Read
    
    [numeric,text,raw] = xlsread(file,'Node');
    node = raw{2,1};
    index = raw{2,2};
    
    % Reference
    
    [numeric,text,raw] = xlsread(file,'Reference');
    P_reference = numeric(1);
    Q_reference = numeric(2);
    
    % Coefficients
    
    [numeric,text,raw] = xlsread(file,'Coefficients');
    alpha = numeric(1:3)';
    
    %% moved to calculateGridResponse
%     % Phase powers
%     S_ref_ph = alpha*(P_reference + 1j*Q_reference)/3;
%     
%     % Output impedance
%     V_rms = base.getBaseVoltage()/sqrt(2);
%     Y = conj(S_ref_ph)/V_rms^2;
%     
%     if P_reference == 0
%         R = 0;
%     else
%         R = 1./real(Y);
%     end
%     
%     if Q_reference <= 0
%         L = 1./(imag(Y)*2*pi*f_1);
%         C = zeros(size(L));
%     else
%         C = -imag(Y)/(2*pi*f_1);
%         L = zeros(size(C));
%     end
%     warning('Check impedance calculation for P = 0 in detail.');

    %% Build
    
    load = RLC_P_Load(node,index,P_reference,Q_reference,alpha);%,R,L,C
end

end