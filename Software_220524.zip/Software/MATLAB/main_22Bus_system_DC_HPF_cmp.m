clear all;
close all;
clc;

disp('START');

import Harmonics.*
import Harmonics.Grid.*;
import Harmonics.Resource.*;
import Harmonics.System.*;
  
f_nominal = 50;
h_max = 25;
P_base = 50e3;
V_base = 230*sqrt(2);
unit_base = Base(P_base,V_base);

h = transpose(0:1:h_max);
n_phases = 3;

time = struct('Ts_HW',1e-06,'Ts_SW',1e-06,'Tend',1); % in (s)

%% Build

folder = '/Users/johanna/Documents/Material/HPF/HPF-Method';

folder_config = [folder filesep() 'Configuration Files/22Bus_LCL_DC'];
folder_results = [folder filesep() 'Results' filesep() 'Systems'];

file_results = '22Bus_DC_h25_cmp';


file = [folder_config filesep() 'System_22Bus_param.xlsx'];
power_grid = Grid.buildFromFile(file,n_phases,unit_base);

file = [folder_config filesep() 'TE.xlsx'];
slack = Thevenin.buildFromFile(file);%,unit_base);

% init
for r = 1 : 5
    file = [folder_config filesep() 'PWM_LCL_C_PI_VQ_P_' num2str(r) '_Pn60k.xlsx'];
    converter_following_DC(r) = PWM_LCL_C_PI_VQ_I.buildFromFile(file,unit_base,f_nominal);
    converter_following(r) = PWM_LCL_PI_PQ.buildFromFile(file,unit_base,f_nominal);
end
for r = 1 : 4
    file = [folder_config filesep() 'RLC_Load_' num2str(r) '_Pn60k.xlsx'];
    passive_loads(r) = RLC_S_Load.buildFromFile(file,n_phases,unit_base,f_nominal);
end
system_DC = AC_Subsystem(power_grid,slack,[],converter_following_DC,passive_loads);
system = AC_Subsystem(power_grid,slack,[],converter_following,passive_loads);

%% Simulate HPF

% Total harmonic distortion
THD = sqrt(sum(abs(2*slack.E_h(1,2:end)).^2))/abs(2*slack.E_h(1,1))*100

Vdc = converter_following_DC.Vdc_reference;

n_nodes = length(system.grid.nodes);
percentage = 0;

% Init
V_h_0 = zeros(n_nodes*n_phases,h_max+1);
I_h_0 = zeros(n_nodes*n_phases,h_max+1);
O_V_h_0 = cell(length(system.resources_forming),1);
O_I_h_0 = cell(length(system.resources_following),1);

V_h_0 = initializeHarmonicPowerFlow(V_h_0,n_phases,[1],percentage,h_max);
% I_h_0 = initializeHarmonicPowerFlow(I_h_0,n_phases,[1],percentage,h_max);

% Operating point - init (ordered w.r.t. CIDERs)
for k = 1:length(O_I_h_0)
    VAref_d = zeros(n_phases,h_max+1);
    IA_d    = zeros(n_phases,h_max+1);
    VD_d    = zeros(1,h_max+1);

    VAref_d = initializeHarmonicPowerFlow(VAref_d,n_phases,[1],percentage,h_max);
%     IA_d    = initializeHarmonicPowerFlow(IA_d,n_phases,[1],percentage,h_max);
    VD_d(:,h==0) = Vdc / V_base * (1 + rand(size(VD_d(:,h==0)))*percentage/100);

    O_I_h_0{k} = [VAref_d;IA_d;VD_d];
end

% Method including DC side
options = struct('maxIteration',20, ...
                 'tolerance',1e-8, ...
                 'alpha',1, ...
                 'kronReduction',1, ...
                 'slackMode','forming');
[V_f_HPF,I_f_HPF,~,~] = ...
            system_DC.solveNewtonRaphson(time.Ts_SW,f_nominal,h_max, ...
                                      V_h_0,I_h_0,O_V_h_0,O_I_h_0, ...
                                      unit_base,options);

V_h.HPF_DC = V_f_HPF(:,:,end);
I_h.HPF_DC = I_f_HPF(:,:,end);

% Method excluding DC side
options = struct('maxIteration',20, ...
                 'tolerance',1e-8, ...
                 'alpha',1, ...
                 'kronReduction',1, ...
                 'slackMode','forming');
[V_f_HPF,I_f_HPF,~,~] = ...
            system.solveNewtonRaphson(time.Ts_SW,f_nominal,h_max, ...
                                      V_h_0,I_h_0,O_V_h_0,O_I_h_0, ...
                                      unit_base,options);

V_h.HPF = V_f_HPF(:,:,end);
I_h.HPF = I_f_HPF(:,:,end);


disp('STOP');

%%  Analyze

node_names_all = [];
for n = 1:n_nodes
    node_names_all = [node_names_all, {['N',num2str(n)]}];
end

% THD
for n = 1:size(V_h.HPF,1)
    THD_V_h(n) = sqrt(sum(abs(2*V_h.HPF(n,3:end)).^2))./abs(2*V_h.HPF(n,2))*100;
    THD_I_h(n) = sqrt(sum(abs(2*I_h.HPF(n,3:end)).^2))./abs(2*I_h.HPF(n,2))*100;
end

nodes = 1:22;%[1,15:22];%[1,15:18,20];

idx = (1:n_phases)+(nodes'-1)*n_phases;

THD_V.HPF = round(THD_V_h(idx)',2);
THD_I.HPF = round(THD_I_h(idx)',2);

% THD
for n = 1:size(V_h.HPF,1)
    THD_V_h(n) = sqrt(sum(abs(2*V_h.HPF_DC(n,3:end)).^2))./abs(2*V_h.HPF_DC(n,2))*100;
    THD_I_h(n) = sqrt(sum(abs(2*I_h.HPF_DC(n,3:end)).^2))./abs(2*I_h.HPF_DC(n,2))*100;
end

THD_V.HPF_DC = round(THD_V_h(idx)',2);
THD_I.HPF_DC = round(THD_I_h(idx)',2);

node_names = repmat(node_names_all(nodes)',[1,3])';
phase_names = repmat([{'a'};{'b'};{'c'}],[1,length(nodes)]);

names = {'Node','Phase','THD_V_HPF','THD_V_HPF_DC','THD_I_HPF','THD_I_HPF_DC'};
results = table(node_names(:),phase_names(:),THD_V.HPF(:),THD_V.HPF_DC(:),THD_I.HPF(:),THD_I.HPF_DC(:),'VariableNames',names)

names = {'Node','Phase','d_THD_V','d_THD_I'};
results = table(node_names(:),phase_names(:),THD_V.HPF(:)-THD_V.HPF_DC(:),THD_I.HPF(:)-THD_I.HPF_DC(:),'VariableNames',names)

names = {'Node','THD_V_HPF_max','THD_V_HPF_DC_max','THD_I_HPF_max','THD_I_HPF_DC_max'};
results = table(node_names(1,:)',max(THD_V.HPF)',max(THD_V.HPF_DC)',max(THD_I.HPF)',max(THD_I.HPF_DC)','VariableNames',names)

% for exporting to latex
% writetable(results,'myData.txt','Delimiter',';')
% type 'myData.txt'

%% Plot
h_set = [1,5,7,11,13,17,19,23,25];

i = 1;
idx_revision{1} = (1:n_phases)+(i-1)*n_phases;%idx_slack;
titleStr{1} = 'N1';

i = 15;
idx_revision{2} = (1:n_phases)+(i-1)*n_phases;
titleStr{2} = 'N15';

i =  18;%20;%
idx_revision{3} = (1:n_phases)+(i-1)*n_phases;
titleStr{3} = 'N18';

file_location = [folder_results filesep() file_results '_IG_N1_15_18'];
semilog_Resource_3Nodes(I_h,idx_revision,h_set,h_max,'I','A',titleStr,file_location,1);
file_location = [folder_results filesep() file_results '_VG_N1_15_18'];
semilog_Resource_3Nodes(V_h,idx_revision,h_set,h_max,'V','A',titleStr,file_location,2);
