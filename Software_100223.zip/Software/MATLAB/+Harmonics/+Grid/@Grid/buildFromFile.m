function grid = buildFromFile(file,number_of_wires,base)
% grid = buildFromFile(file,base)

import Harmonics.*;
import Harmonics.Grid.*;
import Harmonics.Grid.Line.*;

if(~isa(file,'char'))
    error('file: type.');
elseif(~isa(base,'Base'))
    error('base: type.');
else
    Z_base = base.getBaseImpedance();
    Y_base = base.getBaseAdmittance();
    
    %% Read
    
    [numeric,text,raw] = xlsread(file,'Lines');
    
    line_names = raw(2:end,1);
    nodes_from = raw(2:end,2);
    nodes_to = raw(2:end,3);
    line_lengths = cell2mat(raw(2:end,4));

    if number_of_wires == 3
        R_pn = cell2mat(raw(2:end,5));% .* line_lengths / Z_base;
        R_0  = cell2mat(raw(2:end,6));% .* line_lengths / Z_base;
        L_pn = cell2mat(raw(2:end,7));% .* line_lengths / Z_base;
        L_0  = cell2mat(raw(2:end,8));% .* line_lengths / Z_base;
        C_pn = cell2mat(raw(2:end,9));% .* line_lengths / Y_base;
        C_0  = cell2mat(raw(2:end,10));%.* line_lengths / Y_base;
    else
        R = cell2mat(raw(2:end,5));% .* line_lengths / Z_base;
        L = cell2mat(raw(2:end,6));% .* line_lengths / Z_base;
        C = cell2mat(raw(2:end,7));% .* line_lengths / Y_base;
    end
    %% Build
    
    % Nodes
    
    node_names = sort(unique([nodes_from(:);nodes_to(:)]));
    
    nodes = cell(length(node_names),1);
    for n=1:length(node_names)
        nodes{n} = Node(node_names{n});
    end
    nodes = [nodes{:}];
    
    % Lines
    
    lines = cell(length(line_names),1);
    for l=1:length(line_names)
        name = line_names{l};
        node_from = nodes_from{l};
        node_to = nodes_to{l};
        if number_of_wires == 3
            lines{l} = Three_Wire_Line(name,node_from,node_to,R_pn(l),R_0(l),L_pn(l),L_0(l),C_pn(l),C_0(l),line_lengths(l));
        else
            lines{l} = One_Wire_Line(name,node_from,node_to,R(l),L(l),C(l),line_lengths(l));
        end
    end
    lines = [lines{:}];
    
    grid = Grid(nodes,lines,number_of_wires);
end

end