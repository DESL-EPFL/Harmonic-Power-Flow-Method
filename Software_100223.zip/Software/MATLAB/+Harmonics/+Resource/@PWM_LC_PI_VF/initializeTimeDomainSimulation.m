function [] = initializeTimeDomainSimulation(obj,modelName,converterName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

nodeName = obj.node;
nodeName_index = [nodeName,'_',num2str(obj.index)];
blockName = [modelName,filesep(),nodeName,filesep(),nodeName_index,filesep()];

set_param(blockName,'L_Stage',[converterName,'.L_stage']);
set_param(blockName,'C_Stage',[converterName,'.C_stage']);
set_param(blockName,'f_reference',[converterName,'.f_reference']);
set_param(blockName,'V_reference',[converterName,'.V_reference']);

end