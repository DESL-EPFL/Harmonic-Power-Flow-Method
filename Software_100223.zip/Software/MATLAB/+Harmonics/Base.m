classdef Base
    properties(Access=private)
        P_base;
        V_base;
    end
    
    methods
        function obj = Base(P_base,V_base)
            % obj = Base(P_base,V_base)
            
            if(~isa(P_base,'numeric'))
                error('P_base: type.');
            elseif(~isa(V_base,'numeric'))
                error('V_base: type.');
            elseif(~all(size(P_base)==1))
                error('P_base: size.');
            elseif(~all(size(V_base)==1))
                error('V_base: size.');
            elseif(P_base<0)
                error('P_base: value.');
            elseif(V_base<0)
                error('V_base: value.');
            else
                obj.P_base = P_base;
                obj.V_base = V_base;
            end
        end
        
        function P_base = getBasePower(obj)
            P_base = obj.P_base;
        end
        
        function V_base = getBaseVoltage(obj)
            V_base = obj.V_base;
        end
        
        function I_base = getBaseCurrent(obj)
            I_base = obj.P_base/obj.V_base;
        end
        
        function Y_base = getBaseAdmittance(obj)
            Y_base = obj.P_base/(obj.V_base)^2;
        end
        
        function Z_base = getBaseImpedance(obj)
            Z_base = (obj.V_base)^2/obj.P_base;
        end
    end
end

