classdef DC_Subsystem < Harmonics.System.Subsystem
    % DC_SUBSYSTEM Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        resources_forming;
        resources_following;
        passive_loads;
    end
    
    methods
        function obj = DC_Subsystem(grid,resources_forming,resources_following,passive_loads)
            % obj = DC_Subsystem(grid,resources_forming,resources_following,passive_loads)
            
            import Harmonics.*;
            import Harmonics.Grid.*;
            import Harmonics.Resource.*;
            
            obj = obj@Harmonics.System.Subsystem(grid);

            if...(xor(~isa(resources_forming,'Thevening'),...
                       ~isempty(resources_forming)%))
                error('resources_forming: type.');
            elseif(xor(~(isa(resources_following,'I_Source')),...
                       isempty(resources_following)))  
                error('resources_following: type.');
            elseif(xor(~(isa(passive_loads,'DC_Load')),...
                       isempty(passive_loads)))  
                error('passive_loads: type.');
            else
                obj.resources_forming = resources_forming;
                obj.resources_following = resources_following;
                obj.passive_loads = passive_loads;
            end
        end
        
        function n = getNumberOfResources(obj)
            n.slack = 0;
            n.forming = length(obj.resources_forming);
            n.following = length(obj.resources_following);
            n.passive = length(obj.passive_loads);
        end
        
        function nodes = getNodePartition(obj)
            
            import Harmonics.*;
            import Harmonics.Grid.*;
            
            N_slack = {};
            nodes.slack = [];
            
            if ~isempty(obj.resources_forming)
                N_form = {obj.resources_forming.node};
                [found_form,nodes.form] = Node.findByName(obj.grid.nodes,N_form);
                if(~all(found_form))
                    error('resources_forming.');
                end
            else
                N_form = {};
                nodes.form = [];
            end
            
            if ~isempty(obj.resources_following)
                N_follow = {obj.resources_following.node};
                [found_follow,nodes.follow] = Node.findByName(obj.grid.nodes,N_follow);
                if(~all(found_follow))
                    error('resources_following.');
                end
            else
                N_follow = {};
                nodes.follow = [];
            end

            if ~isempty(obj.passive_loads)
                N_passive = {obj.passive_loads.node};
                [found_passive,nodes.passive] = Node.findByName(obj.grid.nodes,N_passive);
                if(~all(found_passive))
                    error('passive_loads.');
                end
            else
                N_passive = {};
                nodes.passive = [];
            end
            
            N_resources = [N_slack,N_form,N_follow,N_passive];
            N_internal = setdiff({obj.grid.nodes.name},N_resources); % internal nodes
            [found_internal,nodes.internal] = Node.findByName(obj.grid.nodes,N_internal);
            if(~all(found_internal))
                error('internal.');
            end
        end
        
        % HPF
        [VSh,IRh,dVSh_dISh,dIRh_dVRh,O_V_h,O_I_h] = calculateResourceQuantities(obj,Ts,f_1,h_max,ISh,VRh,O_V_h,O_I_h,nodes,base,options)

        [] = initializeTimeDomainSimulation(obj,modelName,subsystemName)
    end
end