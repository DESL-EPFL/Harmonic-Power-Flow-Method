classdef LTP_Transform
    % LTP_Transform represents a Linear Time-Periodic (LTP) transform,
    % which is described by the forward transformation matrix T_FW(t)
    % and the backward transformation matrix T_BW(t).
    % These matrices satisfy
    %
    %   T_FW(t)*T_BW(t) = identity
    %   T_BW(t)*T_FW(t) = identity
    %
    % The two aforestated identity matrices need not have the same size.
    
    properties(SetAccess=private)
        h;
        T_FW_h;
        T_BW_h;
    end
    
    methods
        function obj = LTP_Transform(h,T_FW_h,T_BW_h)
            % obj = LTP_Transform(h,T_FW_h,T_BW_h)
            
            % Check data type
            if(~isa(h,'numeric'))
                error('h: format.');
            elseif(~isa(T_FW_h,'numeric'))
                error('T_FW_h: format.');
            elseif(~isa(T_BW_h,'numeric'))
                error('T_BW_h: format.');
            else
                % Check data size
                
                n_h = size(h,1);
                
                if(~all(size(h)==[n_h,1]))
                    error('h: size.');
                elseif(~all([size(T_FW_h,1),size(T_FW_h,2)]==[size(T_BW_h,2),size(T_BW_h,1)]))
                    error('T_{FW/BW}_h: domain and codomain.');
                elseif(~all([size(T_FW_h,3),size(T_BW_h,3)]==n_h))
                    error('T_{FW/BW}_h: harmonics.');
                else
                    % Construct object.
                    
                    obj.h = h;
                    obj.T_FW_h = T_FW_h;
                    obj.T_BW_h = T_BW_h;
                end
            end
        end
    end
    
    methods(Abstract)
        [T_FW,T_BW] = buildHarmonicModel(obj,args);
        outputs = transformForward(inputs);
        outputs = transformBackward(inputs);
    end
    
    methods(Static,Abstract)
        outputs = getSizeOfDomain(inputs);
        outputs = getSizeOfCodomain(inputs);
    end
end