function I_source = buildFromFile(file,base,f_1)
% load = buildFromFile(file,base,f_1,type)

import Harmonics.*;
import Harmonics.Resource.*;

if(~isa(file,'char'))
    error('file: type.');
else
    
    
    %% Read
    
    [numeric,text,raw] = xlsread(file,'Node');
    node = raw{2,1};
    index = raw{2,2};
    
    % Reference
    
    [numeric,text,raw] = xlsread(file,'Reference');
    I_reference = numeric(1);
    
    %% Build
    
    I_source = I_Source(node,index,I_reference);
end

end