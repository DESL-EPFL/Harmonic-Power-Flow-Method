function [I_h,dIh_dVh] = calculateGridResponse(obj,f_1,h_max,V_h,base)

import Harmonics.*;

n_wires = 1;%length(obj.alpha);

%% belongs in build from file
% Phase powers
P_ref = obj.P_reference;

% Output impedance
warning('DC voltage level is hardcoded.')
Vdc = 900;

G = -P_ref/Vdc^2;
R = -Vdc^2./P_ref;


%%

% Base Values
Z_base = base.getBaseImpedance();

R = R / Z_base;%obj.

Y_h = zeros(n_wires,n_wires,h_max+1,h_max+1);

if ~(R == 0)
    for k=0:h_max
        Y_h(:,:,k+1,k+1) = inv(R);
    end
else
    error('Problem in DC load.')
end

I_h = zeros(n_wires,h_max+1);
for k=1:(h_max+1) % no coupling between harmonics
    I_h(:,k) = -Y_h(:,:,k,k) * V_h(:,k);
end

dIh_dVh = -Y_h;

end