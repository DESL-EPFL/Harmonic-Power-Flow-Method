function [IGh,VDh,dIGh,dVDh,Oh] = calculateGridResponse(obj,Ts,f_1,h,VGh,IEh,Oh,base)
% [Ih,dIh_dVh,Oh] = calculateGridResponse(obj,Ts,f_1,h,Vh,Oh,base)
% 
% INPUT
% - f1          Fundamental frequency.
% - h           Harmonic orders (w.r.t. the fundamental frequency)
% - Vh          Fourier coefficients of the AC grid voltage.
% - Idh         Fourier coefficients of the DC grid current.
% - Oh          Fourier coefficients of the operating point.
% - base        Per-unit base.
% 
% OUTPUT
% - Ih          Fourier coefficients of the AC grid current.
% - Vdh         Fourier coefficients of the DC grid voltage.
% - dIh         Fourier coefficients of the Jacobian matrix
%               of the AC grid current w.r.t. the inputs 
%               (AC grid voltage and DC grid current).
% - dVdh        Fourier coefficients of the Jacobian matrix
%               of the DC grid voltage w.r.t. the inputs 
%               (AC grid voltage and DC grid current).
% - Oh          Fourier coefficients of the updated operating point.

import Harmonics.*;

h_max = max(h);

%% Input

W_G = Fourier.buildVector(h,[VGh;IEh]);

%% External Transform

[T_PG,T_GP] = obj.calculateExternalTransform(h_max);

%% Operating Point for Linearization

VAref_h = Oh(1:3,:);
IA_h    = Oh(4:6,:);
VD_h    = Oh(7,:);

% init
h_d_AC = h';%[1,5,7];%,11,13];
i_d_AC = logical(sum(h==h_d_AC,2));
h_d_DC = h';%,6];
i_d_DC = logical(sum(h==h_d_DC,2));

VAref_d = zeros(size(VAref_h));
IA_d    = zeros(size(IA_h));
VD_d    = zeros(size(VD_h));

VAref_d(:,i_d_AC)  = VAref_h(:,i_d_AC);
IA_d(:,i_d_AC)     = IA_h(:,i_d_AC);
VD_d(:,i_d_DC)     = VD_h(:,i_d_DC);

O_P_h = [VAref_d;IA_d;VD_d];

%% Disturbance - Grid Voltage & Linearization Point

W_P_1 = T_PG*W_G;%Vh&Idh;
[~, W_P_h_1] = Fourier.splitVector(W_P_1,7);
W_P_h_2 = VAref_d; % disturbance from linearization

W_P_h = [W_P_h_1(1:4,:);W_P_h_2];
W_P = Fourier.buildVector(h,W_P_h);

%% Internal Response

[T_abc2pnz,~] = PNZ_Transform.build();
V1_ABC = VGh(:,h==1);
V1_PNH = T_abc2pnz*V1_ABC;
theta0 = angle(V1_PNH(1));

[W_K,dW_KP] = calculateReference(obj,T_PG*W_G,theta0,h_max,base);

[G_PP,G_PK,G_KP,G_KK] = obj.calculateInternalGain(O_P_h,theta0,Ts,f_1,h_max,base);

Y_P = G_PP * W_P + G_PK * W_K;
Y_K = G_KP * W_P + G_KK * W_K;

dY_PP = G_PP + G_PK * dW_KP;

% % debugging
% n_Y_P = 14;
% n_W_P = 7;
% [~,dY_PP_h] = Fourier.splitMatrix(dY_PP,n_Y_P,n_W_P);
% 
% [~,G_PP_h] = Fourier.splitMatrix(G_PP,n_Y_P,n_W_P);
% 
% n_W_K = 2;
% n_W_P = 7;
% [~,dW_KP_h] = Fourier.splitMatrix(dW_KP,n_W_K,n_W_P);

%% Update Operating Point

[T_KP,T_PK] = obj.calculateInternalTransform(theta0,Ts,f_1,h_max);
U_P = T_PK*Y_K;
[~,Y_P_h] = Fourier.splitVector(Y_P,size(obj.power_hardware.C_h,1));
[~,U_P_h] = Fourier.splitVector(U_P,size(obj.power_hardware.B_h,2));

Oh = [U_P_h(1:3,:);Y_P_h(1:3,:);Y_P_h(10,:)];

%% External Response

Y_G = T_GP * Y_P;
dY_GG = T_GP * dY_PP * T_PG;

n_W_G = obj.external_transform.getSizeOfCodomain()+1;
n_Y_G = n_W_G;

[~,Yh] = Fourier.splitVector(Y_G,n_Y_G);
IGh = Yh(1:3,:);
VDh = Yh(4,:);

[~,dYh_dWh] = Fourier.splitMatrix(dY_GG,n_Y_G,n_W_G);
dIGh.dVGh = dYh_dWh(1:3,1:3,:,:);
dIGh.dIEh = dYh_dWh(4,1:3,:,:);
dVDh.dVGh = dYh_dWh(1:3,4,:,:);
dVDh.dIEh = dYh_dWh(4,4,:,:);

end