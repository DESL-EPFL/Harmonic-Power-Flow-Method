function [VSh,IRh,dVSh_dISh,dIRh_dVRh,O_V_h,O_I_h] = calculateResourceQuantities(obj,Ts,f_1,h_max,ISh,VRh,O_V_h,O_I_h,nodes,base,options)

import Harmonics.*;
import Harmonics.Grid.*;
import Harmonics.Resource.*;
import Harmonics.System.*;

n_phases = obj.grid.getNumberOfWires();
h = transpose(0:1:h_max);

%% Grid-forming

VSh = zeros(size(ISh));
dVSh_dISh = zeros(size(VSh,1),size(VSh,1),h_max+1,h_max+1); % with coupling

for s=1:length(obj.resources_forming)        
    
    [~,index] = ismember(nodes.form(s),nodes.S);
    idx_s = (1:n_phases)+n_phases*(index-1);
    
    [Vh_s,dVh_dIh_s,Oh_s] = obj.resources_forming(s).calculateGridResponse(Ts,f_1,h,ISh(idx_s,:),O_V_h{s},base);
    
    VSh(idx_s,:) = Vh_s;
    dVSh_dISh(idx_s,idx_s,:,:) = dVh_dIh_s;

    % Update operating point
    O_V_h{s} = Oh_s;
end

% Slack (belongs to set 1 or 2 depending on options.slackMode)
for s=1:length(obj.slack)
    if strcmp(options.slackMode,'forming') %
        [~,index] = ismember(nodes.slack(s),nodes.S);
        idx_s = (1:n_phases)+n_phases*(index-1);
    
        [Vh_s,dVh_dIh_s] = obj.slack.calculateGridResponse_forming(f_1,h,ISh(idx_s,:),base);
    
        VSh(idx_s,:) = Vh_s;
        dVSh_dISh(idx_s,idx_s,:,:) = dVh_dIh_s;
    end
end

%% Grid-following + passive loads

IRh = zeros(size(VRh));
dIRh_dVRh = zeros(size(IRh,1),size(IRh,1),h_max+1,h_max+1); % with coupling

for r=1:length(obj.resources_following)
    
    [~,index] = ismember(nodes.follow(r),nodes.R);
    idx_r = (1:n_phases)+n_phases*(index-1);
    
    [Ih_r,dIh_dVh_r,Oh_r] = obj.resources_following(r).calculateGridResponse(Ts,f_1,h,VRh(idx_r,:),O_I_h{r},base);
    
    IRh(idx_r,:) = IRh(idx_r,:) + Ih_r;
    dIRh_dVRh(idx_r,idx_r,:,:) = dIRh_dVRh(idx_r,idx_r,:,:) + dIh_dVh_r;

    % Update operating point
    O_I_h{r} = Oh_r;
end

for r=1:length(obj.passive_loads)
    
    [~,index] = ismember(nodes.passive(r),nodes.R);
    idx_r = (1:n_phases)+n_phases*(index-1);
    
    [Ih_r,dIh_dVh_r] = obj.passive_loads(r).calculateGridResponse(f_1,h_max,VRh(idx_r,:),base);
    
    IRh(idx_r,:) = IRh(idx_r,:) + Ih_r;
    dIRh_dVRh(idx_r,idx_r,:,:) = dIRh_dVRh(idx_r,idx_r,:,:) + dIh_dVh_r;
end

% Slack (belongs to set 1 or 2 depending on options.slackMode)
for r=1:length(obj.slack)
    if ~strcmp(options.slackMode,'forming') %
        [~,index] = ismember(nodes.slack(r),nodes.R);
        idx_r = (1:n_phases)+n_phases*(index-1);
            
        [Ih_r,dIh_dVh_r] = obj.slack.calculateGridResponse(f_1,h,VRh(idx_r,:),base);

        IRh(idx_r,:) = IRh(idx_r,:) + Ih_r;
        dIRh_dVRh(idx_r,idx_r,:,:) = dIRh_dVRh(idx_r,idx_r,:,:) + dIh_dVh_r;
    end
end

% Internal Nodes
if options.kronReduction == 0
    for r=1:length(nodes.internal)
    %         idx_r = (1:n_phases)+n_phases*(n.follow+n.passive+n.slack+r-1);
        [~,index] = ismember(nodes.internal(r),nodes.R);
        idx_r = (1:n_phases)+n_phases*(index-1);
        
        IRh(idx_r,:) = zeros(size(Ih_r));
        dIRh_dVRh(idx_r,idx_r,:,:) = zeros(size(dIh_dVh_r));
    end
end

end

