function [V_h,I_h,n_iter] = solveNewtonRaphson(obj,Ts,f_1,h_max,V_h_0,I_h_0,O_V_h_0,O_I_h_0,base,options)
%SOLVENEWTONRAPHSON Summary of this function goes here
%   Detailed explanation goes here

import Harmonics.*;
import Harmonics.Grid.*;
import Harmonics.Resource.*;
import Harmonics.System.*;

timer = tic();

disp('HPF (Newton-Raphson): start.');
disp(' ');

h = transpose(0:1:h_max);
f = f_1 * h;

%% Kron Reduction & Hybrid Parameters - once per subsystem

n_subsystems = length(obj.subsystems);

for j = 1:n_subsystems
    sys_temp = obj.subsystems(j);

    n_phases(j) = sys_temp.grid.getNumberOfWires();
    n_nodes(j) = length(obj.subsystems(j).grid.nodes);

    % Sets of grid-forming and grid-following nodes
    n{j}     = sys_temp.getNumberOfResources();
    nodes{j} = sys_temp.getNodePartition();

    % slack
    if strcmp(options.slackMode,'forming')
        nodes_1 = [nodes{j}.slack,nodes{j}.form];
        nodes_2 = unique([nodes{j}.follow,nodes{j}.passive]);
    else
        nodes_1 = [nodes{j}.form];
        nodes_2 = unique([nodes{j}.slack,nodes{j}.follow,nodes{j}.passive]);
    end

    % interfacing converters
    node_interfacing = obj.getInteracingConvertersNode();
    nodes{j}.interfacing = node_interfacing{j};
    if isa(sys_temp,'AC_Subsystem')
        nodes_2 = [nodes_2,nodes{j}.interfacing];
    else
        nodes_1 = [nodes_1,nodes{j}.interfacing];
    end
    nodes{j}.internal = setdiff(nodes{j}.internal,nodes{j}.interfacing);

    % Admittance Matrix
    Y_h_full{j} = sys_temp.grid.buildAdmittanceMatrix(f,base);

    % Reduction
    if options.kronReduction == 1 %strcmp('Reduced',options.unRed)
        nodes_3 = [];
    
        n_nodes_kron = length([nodes_1,nodes_2]);
        Y_h_kron = KronTechnique.reduce(Y_h_full{j},[nodes_1,nodes_2]',n_phases(j));
        
        nodes_1_kron = 1:length(nodes_1);
        nodes_2_kron = length(nodes_1)+(1:length(nodes_2));
        nodes_3_kron = [];
        
    else
        nodes_3 = nodes{j}.internal;
    
        n_nodes_kron = length([nodes_1,nodes_2,nodes_3]);
        Y_h_kron = Y_h_full{j};
        
        nodes_1_kron = nodes_1;
        nodes_2_kron = nodes_2;
        nodes_3_kron = nodes_3;
        
    end

    nodes{j}.S = nodes_1;
    nodes{j}.R = [nodes_2,nodes_3];
    
    nodes_red{j}.S = [nodes_1_kron];
    nodes_red{j}.R = [nodes_2_kron,nodes_3_kron];

    % Hybrid matrix
    [H_h(j).SS,H_h(j).SR,H_h(j).RS,H_h(j).RR] = sys_temp.grid.buildHybridMatrix(Y_h_kron,nodes_red{j}.S,nodes_red{j}.R,f); % opposite to fixed-point

end

%% Initialization

itr_max = options.maxIteration;%10;

% Init (i = 1)
% Nodal quantities
I_h_0 = mat2cell(I_h_0,[n_phases(1)*n_nodes(1),n_phases(2)*n_nodes(2)]);
V_h_0 = mat2cell(V_h_0,[n_phases(1)*n_nodes(1),n_phases(2)*n_nodes(2)]);

for j = 1:n_subsystems
    sys_temp = obj.subsystems(j);

    ISh{j} = zeros(n_phases(j)*length(nodes_red{j}.S),h_max+1,itr_max+1);
    VRh{j} = zeros(n_phases(j)*length(nodes_red{j}.R),h_max+1,itr_max+1);
    
    VSh_res{j} = ISh{j};
    IRh_res{j} = VRh{j};
    VSh_grd{j} = VSh_res{j};
    IRh_grd{j} = IRh_res{j};
    
    Ih_0 = mat2cell(I_h_0{j},n_phases(j)*ones(n_nodes(j),1),h_max+1);
    Vh_0 = mat2cell(V_h_0{j},n_phases(j)*ones(n_nodes(j),1),h_max+1);
    
    ISh{j}(:,:,1) = cell2mat(Ih_0(nodes{j}.S));
    VSh{j}(:,:,1) = cell2mat(Vh_0(nodes{j}.S));
    IRh{j}(:,:,1) = cell2mat(Ih_0(nodes{j}.R));
    VRh{j}(:,:,1) = cell2mat(Vh_0(nodes{j}.R));

    % Operating point
    if isa(sys_temp,'AC_Subsystem')
        O_V_h{j} = O_V_h_0;
        O_I_h{j} = O_I_h_0;
    else
        O_V_h{j} = [];
        O_I_h{j} = [];
    end
end

dx_max = zeros(itr_max+1,1);
df_max = zeros(itr_max+1,1);
% cond_df_dx = zeros(itr_max+1,1);

dx_met = 0;
df_met = 0;

%% Newton Raphson

for i=(1:itr_max)+1
    disp('***');
    disp(['Newton-Raphson method: iteration ' int2str(i-1)]);
    
    %% Resources
    
    % subsystems
    for j = 1:n_subsystems

        [VS_h,IR_h,dVSh_dISh,dIRh_dVRh,O_V_h{j},O_I_h{j}] = ...
            obj.subsystems(j).calculateResourceQuantities(Ts,f_1,h_max,...
                ISh{j}(:,:,i-1),VRh{j}(:,:,i-1),O_V_h{j},O_I_h{j},nodes{j},base,options);
        
        VSh_res{j}(:,:,i) = VS_h;
        IRh_res{j}(:,:,i) = IR_h;

        dVSh_dISh_res{j} = dVSh_dISh;
        dIRh_dVRh_res{j} = dIRh_dVRh;
        dVSh_dVRh_res{j} = zeros(size(dVSh_dISh_res{j},1),size(dIRh_dVRh_res{j},2),h_max+1,h_max+1);
        dIRh_dISh_res{j} = zeros(size(dIRh_dVRh_res{j},1),size(dVSh_dISh_res{j},2),h_max+1,h_max+1);
        
    end

    % interfacing converters
    dVS1h_dIS2h_res = zeros(size(dVSh_dISh_res{1},1),size(dVSh_dISh_res{2},2),h_max+1,h_max+1);
    dVS1h_dVR2h_res = zeros(size(dVSh_dISh_res{1},1),size(dVSh_dVRh_res{2},2),h_max+1,h_max+1);
    dIR1h_dIS2h_res = zeros(size(dIRh_dISh_res{1},1),size(dVSh_dISh_res{2},2),h_max+1,h_max+1);
    dIR1h_dVR2h_res = zeros(size(dIRh_dISh_res{1},1),size(dVSh_dVRh_res{2},2),h_max+1,h_max+1);

    dVS2h_dIS1h_res = zeros(size(dVSh_dISh_res{2},1),size(dVSh_dISh_res{1},2),h_max+1,h_max+1);
    dVS2h_dVR1h_res = zeros(size(dVSh_dISh_res{2},1),size(dVSh_dVRh_res{1},2),h_max+1,h_max+1);
    dIR2h_dIS1h_res = zeros(size(dIRh_dISh_res{2},1),size(dVSh_dISh_res{1},2),h_max+1,h_max+1);
    dIR2h_dVR1h_res = zeros(size(dIRh_dISh_res{2},1),size(dVSh_dVRh_res{1},2),h_max+1,h_max+1);

    for r=1:length(obj.interfacing_converters)
        
%         warning('Hardcoded for two subsystems.')
        
        [~,index_AC] = ismember(nodes{1}.interfacing(r),nodes{1}.R);
        idx_AC = (1:n_phases(1))+n_phases(1)*(index_AC-1);
        [~,index_DC] = ismember(nodes{2}.interfacing(r),nodes{2}.S);
        idx_DC = (1:n_phases(2))+n_phases(2)*(index_DC-1);

        Ih_s = ISh{2}(idx_DC,:,i-1);
        Vh_r = VRh{1}(idx_AC,:,i-1);
        
        [Ih_r,Vh_s,dIh_r,dVh_s,Oh_r] = ...
            obj.interfacing_converters(r).calculateGridResponse(Ts,f_1,h,...
                Vh_r,Ih_s,O_I_h{1}{n{1}.follow+r},base);
       
        VSh_res{2}(idx_DC,:,i) = Vh_s;
        IRh_res{1}(idx_AC,:,i) = IRh_res{1}(idx_AC,:,i) + Ih_r;

        dIRh_dVRh_res{1}(idx_AC,idx_AC,:,:) = dIh_r.dVGh;
        dVSh_dISh_res{2}(idx_DC,idx_DC,:,:) = dVh_s.dIEh;

        dIR1h_dIS2h_res(idx_AC,idx_DC,:,:) = dIh_r.dIEh;
        dVS2h_dVR1h_res(idx_DC,idx_AC,:,:) = dVh_s.dVGh;
  
        % Update operating point
        O_I_h{1}{n{1}.follow+r} = Oh_r;

    end

    %% Grid - once per subsystem

    % subsystems
    for j = 1:n_subsystems
        for k=1:length(f) % no coupling between harmonics
            VSh_grd{j}(:,k,i) = H_h(j).SS(:,:,k,k)*ISh{j}(:,k,i-1) + H_h(j).SR(:,:,k,k)*VRh{j}(:,k,i-1);
            IRh_grd{j}(:,k,i) = H_h(j).RS(:,:,k,k)*ISh{j}(:,k,i-1) + H_h(j).RR(:,:,k,k)*VRh{j}(:,k,i-1);
        end
    end

    %% Mismatch

%     warning('Hardcoded for two subsystems.')
        
    % df
    f_h_res = cell(n_subsystems,1);
    f_h_res{1} = [VSh_res{1}(:,:,i);IRh_res{1}(:,:,i)];
    f_h_res{2} = [VSh_res{2}(:,:,i);IRh_res{2}(:,:,i)];
    
    f_h_grd = cell(n_subsystems,1);
    f_h_grd{1} = [VSh_grd{1}(:,:,i);IRh_grd{1}(:,:,i)];
    f_h_grd{2} = [VSh_grd{2}(:,:,i);IRh_grd{2}(:,:,i)];

    f_h_res = cell2mat(f_h_res);
    f_h_grd = cell2mat(f_h_grd);
    
    df_h = f_h_res-f_h_grd;
    df = Fourier.buildVector(h,df_h);
    
    % Jacobian
    df_dx_h_res = cell(n_subsystems,n_subsystems);
    df_dx_h_res{1,1} = [dVSh_dISh_res{1},dVSh_dVRh_res{1};dIRh_dISh_res{1},dIRh_dVRh_res{1}];
    df_dx_h_res{2,2} = [dVSh_dISh_res{2},dVSh_dVRh_res{2};dIRh_dISh_res{2},dIRh_dVRh_res{2}];
    df_dx_h_res{1,2} = [dVS1h_dIS2h_res,dVS1h_dVR2h_res;dIR1h_dIS2h_res,dIR1h_dVR2h_res];
    df_dx_h_res{2,1} = [dVS2h_dIS1h_res,dVS2h_dVR1h_res;dIR2h_dIS1h_res,dIR2h_dVR1h_res];

    df_dx_h_grd = cell(n_subsystems,n_subsystems);
    df_dx_h_grd{1,1} = [H_h(1).SS,H_h(1).SR;H_h(1).RS,H_h(1).RR];
    df_dx_h_grd{2,2} = [H_h(2).SS,H_h(2).SR;H_h(2).RS,H_h(2).RR];
    df_dx_h_grd{1,2} = zeros(size(df_dx_h_grd{1,1},1),size(df_dx_h_grd{2,2},2),h_max+1,h_max+1);
    df_dx_h_grd{2,1} = zeros(size(df_dx_h_grd{2,2},1),size(df_dx_h_grd{1,1},2),h_max+1,h_max+1);

    df_dx_h_res = cell2mat(df_dx_h_res);
    df_dx_h_grd = cell2mat(df_dx_h_grd);

    df_dx_h = -df_dx_h_res + df_dx_h_grd;
    df_dx = Fourier.buildMatrix(df_dx_h,size(df_dx_h,1),size(df_dx_h,2));

%     cond(df_dx)

    dx = df_dx \ df * options.alpha;
    length_x_1 = n_phases(1)*length([nodes{1}.S,nodes{1}.R]);
    length_x_2 = n_phases(2)*length([nodes{2}.S,nodes{2}.R]);
    length_x = length_x_1 + length_x_2;
    [~,dx_h] = Fourier.splitVector(dx,length_x);

    % Update x
    dx_h_new = mat2cell(dx_h,[length_x_1,length_x_2]);
    dx_h_1 = dx_h_new{1};
    dx_h_2 = dx_h_new{2};

    dISh_1 = dx_h_1(1:n_phases(1)*length(nodes_red{1}.S),:);
    dVRh_1 = dx_h_1(n_phases(1)*length(nodes_red{1}.S)+1:end,:);

    dISh_2 = dx_h_2(1:n_phases(2)*length(nodes_red{2}.S),:);
    dVRh_2 = dx_h_2(n_phases(2)*length(nodes_red{2}.S)+1:end,:);

    ISh{1}(:,:,i) = ISh{1}(:,:,i-1) + dISh_1;
    VRh{1}(:,:,i) = VRh{1}(:,:,i-1) + dVRh_1;
    
    ISh{2}(:,:,i) = ISh{2}(:,:,i-1) + dISh_2;
    VRh{2}(:,:,i) = VRh{2}(:,:,i-1) + dVRh_2;

    %% Convergence

    dx_max(i) = max(max(abs(dx_h)));
    df_max(i) = max(max(abs(df_h)));
    disp(['Convergence: dx_max = ' num2str(dx_max(i),'%.2e')...
                     ', df_max = ' num2str(df_max(i),'%.2e')]);%...
%                      ', cond(df_dx) = ' num2str(cond_df_dx(i),'%.2e')...
%                      ', rho(df_dx) = ' num2str(max(abs(eig(df_dx))),'%.2e')]);
    
    if (dx_max(i)<=options.tolerance && dx_met == 0)
        dx_met = 1;
        disp(['Convergence criterion (dx) met after ' int2str(i-1) ' iterations.']);
    end
    if (df_max(i)<=options.tolerance && df_met == 0)
        df_met = 1;
        disp(['Convergence criterion (df) met after ' int2str(i-1) ' iterations.']);
    end
    if (dx_met == 1 && df_met == 1)
        disp(['HPF (Newton-Raphson) converged after ' int2str(i-1) ' iterations.']);
        disp(' ');
%         convergence.cond = cond_df_dx(i);
%         convergence.rho  = max(abs(eig(df_dx)));
        break;
    end
end

%% Write Output

%% Write Output

n_iter = i-1;

V_h = cell(2,1);
I_h = cell(2,1);

for j = 1:n_subsystems
    
    if options.kronReduction == 1 && ~isempty(nodes{j}.internal)

    %     sys_temp = obj.subsystems(j); 
        V_h{j} = zeros([size(V_h_0{j}),n_iter+1]);
        I_h{j} = zeros([size(I_h_0{j}),n_iter+1]);
        
        % Kron reconstruct
        for i = 1:size(V_h{j},3)
                V_h{j}(:,:,i) = KronTechnique.reconstruct(Y_h_full{j},[nodes{j}.S,nodes{j}.R]',[VSh_res{j}(:,:,i);VRh{j}(:,:,i)],n_phases(j));
                for k = 1:h_max+1
                    I_h{j}(:,k,i) = Y_h_full{j}(:,:,k)*V_h{j}(:,k,i);
                end
        end

        disp(' ');
        disp(['Kron Reduction - maximum violation (Sybsystem ',num2str(j),'):']);   
        
        idx_S = reshape((nodes{j}.S-1)*n_phases(j) + (1:n_phases(j))',1,[])';
        idx_R = reshape((nodes{j}.R-1)*n_phases(j) + (1:n_phases(j))',1,[])';

        dI_max_S = max(max(abs(I_h{j}(idx_S,:,end)-ISh{j}(:,:,n_iter+1))));
        dI_max_R = max(max(abs(I_h{j}(idx_R,:,end)-IRh_res{j}(:,:,n_iter+1))));

        disp(table(dI_max_S,dI_max_R));
    else
        
        idx_S = reshape((nodes{j}.S-1)*n_phases(j) + (1:n_phases(j))',1,[])';
        idx_R = reshape((nodes{j}.R-1)*n_phases(j) + (1:n_phases(j))',1,[])';

        I_h{j}(idx_S,:,:) = ISh{j}(:,:,1:i);
        I_h{j}(idx_R,:,:) = IRh_res{j}(:,:,1:i);
        V_h{j}(idx_S,:,:) = VSh_res{j}(:,:,1:i);
        V_h{j}(idx_R,:,:) = VRh{j}(:,:,1:i);
    
    end
end

V_h = cell2mat(V_h);
I_h = cell2mat(I_h);

disp('HPF (Newton-Raphson): stop.');
disp(' ');

disp('##########');
t_exec = toc(timer);
disp(['Execution time: ' num2str(t_exec) ' s.']);

end

