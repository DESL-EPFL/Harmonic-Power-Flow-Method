function [] = initializeTimeDomainSimulation(obj,modelName,converterName,variantName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

nodeName = obj.node;
nodeName_index = [nodeName,'_',num2str(obj.index)];
blockName = [modelName,filesep(),nodeName,filesep(),nodeName_index,filesep(),variantName];

set_param(blockName,'P_reference',[converterName,'.P_reference']);
set_param(blockName,'Q_reference',[converterName,'.Q_reference']);
set_param(blockName,'alpha',[converterName,'.alpha']);
set_param(blockName,'load_type',['(',converterName,'.Q_reference <= 0)']);
      
% set_param([modelName,filesep(),'y_',nodeName],'VariableName',['y_',nodeName]);

end