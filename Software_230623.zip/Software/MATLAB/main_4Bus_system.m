clear all;
close all;
clc;

disp('START');

import Harmonics.*
import Harmonics.Grid.*;
import Harmonics.Resource.*;
import Harmonics.System.*;
  
% Parameters

f_nominal = 50;
h_max = 25;
P_base = 50e3;
V_base = 230*sqrt(2);
unit_base = Base(P_base,V_base);

h = transpose(0:1:h_max);
n_phases = 3;

time = struct('Ts_HW',5e-06,'Ts_SW',5e-06,'Tend',2); % in (s)

%% Build

folder = '/Users/johanna/Desktop/Harmonic-Power-Flow-Method-main/Software/';

folder_config = [folder filesep() 'Configuration Files/4Bus'];
folder_results = [folder filesep() 'Results' filesep() 'Systems'];

file_results = '4Bus_h25';

% Grid
file = [folder_config filesep() 'System_4Bus_param.xlsx'];
power_grid = Grid.buildFromFile(file,n_phases,unit_base);

file = [folder_config filesep() 'TE.xlsx'];
slack = Thevenin.buildFromFile(file);%,unit_base);

% Resources
file = [folder_config filesep() 'PWM_LC_PI_VF_Pn100k.xlsx'];
converter_forming = PWM_LC_PI_VF.buildFromFile(file,unit_base);

file = [folder_config filesep() 'PWM_LCL_PI_PQ_Pn60k.xlsx'];
converter_following = PWM_LCL_PI_PQ.buildFromFile(file,unit_base,f_nominal);

file = [folder_config filesep() 'RLC_S_Load.xlsx'];
passive_loads = RLC_S_Load.buildFromFile(file,n_phases,unit_base,f_nominal);


% System
system = AC_Subsystem(power_grid,slack,converter_forming,converter_following,passive_loads);

%%  Simulate TDS

V_h = struct();
I_h = struct();

% Simulation Workspace Parameter
Vdc = 900;
PLL = struct('TsetPLL',0.5,'zeta',0.7);

% Thevenin Equivalent for TDS
TE   = struct('h',slack.h,'bin',slack.E_h,'R',slack.R,'L',slack.L,'Name','VTE');
dist = TDSAnalysis.getWaveform(TE,0,time.Tend,f_nominal,time.Ts_HW); % Waveform of the distorted grid supply voltage
THD  = sqrt(sum(abs(2*slack.E_h(1,2:end)).^2))/abs(2*slack.E_h(1,1))*100 % Total harmonic distortion


% ------- Comment in/out for simulating/loading

% [t_TDS_exc,t_TDS_prc,simOut] = system.runTimeDomainSimulation('TDS_4Bus_System','system',h_max,time.Ts_HW);
% 
% for n = 1: length(simOut{1})
%     V_h_TDS{n,1} = simOut{1}(n).Y.VG.bin;
%     I_h_TDS{n,1} = simOut{1}(n).Y.IG.bin;
% end
% V_h.TDS = cell2mat(V_h_TDS);
% I_h.TDS = cell2mat(I_h_TDS);
% 
% 
% save([folder_results filesep() 'TDS_' file_results '.mat'],'V_h','I_h','t_TDS_exc','t_TDS_prc')

% ------- 

load([folder_results filesep() 'TDS_' file_results '.mat'],'V_h','I_h','t_TDS_exc','t_TDS_prc');

% normalize
V_base = unit_base.getBaseVoltage;
I_base = unit_base.getBaseCurrent;

V_h.TDS = V_h.TDS(:,1:h_max+1) / V_base;
I_h.TDS = I_h.TDS(:,1:h_max+1) / I_base;

%% Simulate HPF

n_nodes = length(system.grid.nodes);

% Init - nodal quantities
V_h_0 = zeros(n_nodes*n_phases,h_max+1);
I_h_0 = zeros(n_nodes*n_phases,h_max+1);

V_h_0 = initializeHarmonicPowerFlow(V_h_0,n_phases,[1],10,h_max);

% Init - operating points (not needed for the chosen resources)
O_V_h_0 = cell(length(system.resources_forming),1);
O_I_h_0 = cell(length(system.resources_following),1);

% Method
options = struct('maxIteration',20, ...
                 'tolerance',1e-8, ...
                 'alpha',1, ...
                 'kronReduction',1, ...
                 'slackMode','forming');
[V_f_HPF,I_f_HPF,n_HPF,t_HPF] = ...
            system.solveNewtonRaphson(time.Ts_SW,f_nominal,h_max, ...
                                      V_h_0,I_h_0,O_V_h_0,O_I_h_0, ...
                                      unit_base,options);
% Select final iteration
V_h.HPF = V_f_HPF(:,:,end);
I_h.HPF = I_f_HPF(:,:,end);

disp('STOP');

%% Plot Phase A of all Nodes

h_set = [1,5,7,11,13,17,19,23,25];

i = 1;
idx{1} = (1:n_phases)+(i-1)*n_phases;
titleStr{1} = 'N1';

i = 3;
idx{2} = (1:n_phases)+(i-1)*n_phases;
titleStr{2} = 'N3';

i =  4;
idx{3} = (1:n_phases)+(i-1)*n_phases;
titleStr{3} = 'N4';

file_location = [folder_results filesep() file_results '_IG_N1_3_4'];
semilog_Resource_Demo(I_h,idx,h_set,h_max,'I','A',titleStr,file_location,2);

file_location = [folder_results filesep() file_results '_VG_N1_3_4'];
semilog_Resource_Demo(V_h,idx,h_set,h_max,'V','A',titleStr,file_location,3);

%% Error Plot

idx_slack = 1:3;
n_follow = 4;
idx_follow = reshape((n_follow-1)*n_phases+[1:n_phases]',1,[]);
n_form = 3;
idx_form = reshape((n_form-1)*n_phases+[1:n_phases]',1,[]);

% Voltage and Current Errors of all grid-following resources
file_location = [folder_results filesep() file_results '_error'];
semilog_Error(V_h,I_h,idx_follow,idx_form,h_set,h_max,{'PQ','Vf'},file_location,1);

%% Sequence decomposition

[T_abc2pnz,T_pnz2abc] = PNZ_Transform.build();

nodesIdx = [1:4];
k = 1;
for i = nodesIdx    
    idx = (1:n_phases)+(i-1)*n_phases;
    V_abc_TDS = V_h.TDS(idx,2);
    V_pnz_TDS = T_abc2pnz*V_abc_TDS;
    V_abc_HPF = V_h.HPF(idx,2);
    V_pnz_HPF = T_abc2pnz*V_abc_HPF;
    
    rVnp(k) = abs(V_pnz_HPF(2))/abs(V_pnz_HPF(1));
    rVzp(k) = abs(V_pnz_HPF(3))/abs(V_pnz_HPF(1));
    
    I_abc_TDS = I_h.TDS(idx,2);
    I_pnz_TDS = T_abc2pnz*I_abc_TDS;
    I_abc_HPF = I_h.HPF(idx,2);
    I_pnz_HPF = T_abc2pnz*I_abc_HPF;

    rInp(k) = abs(I_pnz_HPF(2))/abs(I_pnz_HPF(1));
    rIzp(k) = abs(I_pnz_HPF(3))/abs(I_pnz_HPF(1));
    k = k+1;
end

rVnp = round(rVnp*100,2);
rVzp = round(rVzp*100,2);
rInp = round(rInp*100,2);
rIzp = round(rIzp*100,2);

data = [nodesIdx',rVnp',rVzp',rInp',rIzp'];
names = {'Node','|V_n|/|V_p| (%)','|V_z|/|V_p| (%)','|I_n|/|I_p| (%)','|I_z|/|I_p| (%)'};
seq_ratios = table(data(:,1),data(:,2),data(:,3),data(:,4),data(:,5),'VariableNames',names);

display(seq_ratios)