function [I_h,dIh_dVh] = calculateGridResponse(obj,f_1,h_max,V_h,base)

import Harmonics.*;


I_h = zeros(length(obj.I_reference),h_max+1);
I_h(:,1) = obj.I_reference / base.getBaseCurrent();

dIh_dVh = zeros(size(I_h,1),size(I_h,1),size(I_h,2));

end