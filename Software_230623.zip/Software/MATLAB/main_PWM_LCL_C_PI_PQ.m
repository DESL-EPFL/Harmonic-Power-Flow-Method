clear all;
close all;
clc;

disp('START');

import Harmonics.*;
import Harmonics.Grid.*;
import Harmonics.Resource.*;

% Parameters

f_nominal = 50;
h_max = 25;
P_base = 50e3;
V_base = 230*sqrt(2);
unit_base = Base(P_base,V_base); % HPF in nominal values

h = (0:1:h_max)';
n_phases = 3;

time = struct('Ts_HW',1e-06,'Ts_SW',1e-06,'Tend',0.5); % in (s)

%%  Prepare

folder = '/Users/johanna/EPFL GDrive/GIT/Software/';

folder_config = [folder filesep() 'Configuration Files'];
folder_results = [folder filesep() 'Results' filesep() 'Resources'];

file_results = 'PWM_LCL_C_PI_PQ_h25';


file = [folder_config filesep() 'PWM_LCL_C_PI_PQ_V_Pn60k.xlsx'];
converter_following_DC = PWM_LCL_C_PI_PQ.buildFromFile(file,unit_base,f_nominal);

file = [folder_config filesep() 'TE_resource.xlsx']; % needed for TDS
slack = Thevenin.buildFromFile(file);%,unit_base);

%%  Simulate TDS

VG_h = struct();
IG_h = struct();
VF_h = struct();
IA_h = struct();
VA_h = struct();

% Simulation Workspace Parameter
Vdc = 900;
PLL = struct('TsetPLL',0.5,'zeta',0.7);

% Thevenin Equivalent for TDS
TE = struct('h',slack.h,'bin',slack.E_h,'R',slack.R,'L',slack.L,'Name','VTE');
dist = TDSAnalysis.getWaveform(TE,0,time.Tend,f_nominal,time.Ts_HW);
THD = sqrt(sum(abs(2*slack.E_h(1,2:end)).^2))/abs(2*slack.E_h(1,1))*100 % Total harmonic distortion

% ------- Comment in/out for simulating/loading

[simOut] = converter_following_DC.runTimeDomainSimulation(folder,'TDS_PWM_LCL_C_PI_PQ','converter_following_DC','CIDER',h_max+1,time.Ts_HW);

VG_h.TDS = simOut.Y.VG.bin(:,1:h_max+1);
IG_h.TDS = simOut.Y.IG.bin(:,1:h_max+1);
VF_h.TDS = simOut.Y.VF.bin(:,1:h_max+1);
IA_h.TDS = simOut.Y.IA.bin(:,1:h_max+1);
VA_h.TDS = simOut.Y.VA.bin(:,1:h_max+1);
VAref_h.TDS = simOut.Y.VAref.bin(:,1:h_max+1);
VD_h.TDS = simOut.Y.VD.bin(:,1:h_max+1);
ID_h.TDS = simOut.Y.ID.bin(:,1:h_max+1);
IE_h.TDS = simOut.Y.IE.bin(:,1:h_max+1);

save([folder_results filesep() 'TDS_' file_results '.mat'],'VG_h','IG_h','VF_h','IA_h','VA_h','VAref_h','VD_h','ID_h','IE_h')

% ------- 

% load TDS from matfile
load([folder_results filesep() 'TDS_' file_results '.mat'])

% normalize
V_base = unit_base.getBaseVoltage;
I_base = unit_base.getBaseCurrent;
VG_h.TDS = VG_h.TDS / V_base;
IG_h.TDS = IG_h.TDS / I_base;
VF_h.TDS = VF_h.TDS / V_base;
IA_h.TDS = IA_h.TDS / I_base;
VA_h.TDS = VA_h.TDS / V_base;
VAref_h.TDS = VAref_h.TDS / V_base;
VD_h.TDS = VD_h.TDS / V_base;
ID_h.TDS = ID_h.TDS / I_base;
IE_h.TDS = IE_h.TDS / I_base;

%% Simulate HPF 

[VAref_h.HPF,IA_h.HPF,VF_h.HPF,IG_h.HPF,VD_h.HPF] = converter_following_DC.calculateInternalResponse(time.Ts_SW,f_nominal,h,VG_h.TDS,IE_h.TDS,VAref_h.TDS,IA_h.TDS,VD_h.TDS,unit_base);

% O_h = [VAref_h.TDS;...
%        IA_h.TDS;...
%        VD_h.TDS];
% [IG_h.HPF,VD_h.HPF,dIh,dVdh,Oh] = converter_following_DC.calculateGridResponse(time.Ts_SW,f_nominal,h,VG_h.TDS,IE_h.TDS,O_h,unit_base);

%% Check - Power Setpoints

Pref = converter_following_DC.P_reference / P_base;
Qref = converter_following_DC.Q_reference / P_base;

S_TDS = 2*VG_h.TDS(:,2)/sqrt(2) .* conj(2*IG_h.TDS(:,2)/sqrt(2));
P_TDS = sum(real(S_TDS));
Q_TDS = sum(imag(S_TDS));

S_HPF = 2*VG_h.TDS(:,2)/sqrt(2) .* conj(2*IG_h.HPF(:,2)/sqrt(2));
P_HPF = sum(real(S_HPF));
Q_HPF = sum(imag(S_HPF));

ref = [Pref,Qref,0,0];
TDS = [P_TDS,Q_TDS,Pref-P_TDS,Qref-Q_TDS];
HPF = [P_HPF,Q_HPF,Pref-P_HPF,Qref-Q_HPF];
data = [ref(:),TDS(:),HPF(:)];
names = {'Ref','TDS','HPF'};
rowNames = {'P','Q','dP','dQ'};
powers = table(data(:,1),data(:,2),data(:,3),'VariableNames',names,'RowNames',rowNames)

%% Plot

h_set = [1,5,7,11,13,17,19,23,25];

file_location = [folder_results filesep() file_results '_IG'];
[h_abs,max_abs,h_arg,max_arg] = semilog_Resource(IG_h.TDS,IG_h.HPF,(1:3),h_set,h_max,'I','A','\gamma',file_location,1);
% file_location = [folder_results filesep() file_results '_VF'];
%semilog_Resource(VF_h.TDS,VF_h.HPF,(1:3),h_set,h_max,'V','A','\varphi',file_location,3);

h_set = [6,12,18,24];
file_location = [folder_results filesep() file_results '_VD'];
[h_abs,max_abs,h_arg,max_arg] = semilog_Resource(VD_h.TDS,VD_h.HPF,1,h_set,h_max,'V','DC','\delta',file_location,2);
