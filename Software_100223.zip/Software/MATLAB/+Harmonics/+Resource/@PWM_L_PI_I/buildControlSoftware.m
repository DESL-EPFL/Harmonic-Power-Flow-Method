function control_software = buildControlSoftware(L_stage,f_1,base)
% control_software = buildControlSoftware(L_stage,f_1)

import Harmonics.*;
import Harmonics.Resource.*;

if(~isa(L_stage,'PI_Loop_L'))
    error('L_stage: type.');
elseif(~isa(f_1,'numeric'))
    error('f_1: type.');
elseif(~isa(base,'Base'))
    error('base: type.');
else
    h = 0;
        
    [K_FT,K_FF,K_FB,T_FB] = L_stage.buildSoftwareModel(f_1,base);
    
    Z = zeros(2,2); % Zero matrix (w.r.t. DQ frame).
    I = eye(2); % Identity matrix (w.r.t. DQ frame).
    
    A_h = Z;
    B_h = [-I,Z];
    E_h = I;
    
    C_h = K_FB/T_FB;
    D_h = [-K_FB, K_FT];
    F_h = K_FF+K_FB;
    
    control_software = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h);
end

end