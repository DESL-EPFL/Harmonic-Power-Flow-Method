function [] = initializeTimeDomainSimulation(obj,modelName,parameterName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

lineName = obj.name;
blockName = [modelName,filesep(),lineName];

set_param(blockName,'Rpn0',['[',parameterName,'.R_pn',' ',parameterName,'.R_0',']']);
set_param(blockName,'Lpn0',['[',parameterName,'.L_pn',' ',parameterName,'.L_0',']']); 
set_param(blockName,'Cpn0',['[',parameterName,'.C_pn',' ',parameterName,'.C_0',']']);
set_param(blockName,'len',[parameterName,'.length']);

end