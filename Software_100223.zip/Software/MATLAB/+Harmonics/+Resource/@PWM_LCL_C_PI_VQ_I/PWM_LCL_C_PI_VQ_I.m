classdef PWM_LCL_C_PI_VQ_I < Harmonics.Resource.CIR_I
    %   PWM_LCL_PI_PQ represents a converter-interfaced resource
    %   which consists of the following components:
    %   -   actuator: pulse-widh modulator (PWM)
    %   -   AC side filter: inductor + capacitor + inductor (LCL)
    %   -   DC side filter: capacitor (C)
    %   -   controller: proportional-integral (PI) cascade
    %   -   reference: active/reactive power (PQ) and DC voltage
    
    properties(SetAccess=private)
        LA_stage;   % Actuator-side inductive stage.
        CF_stage;   % Grid-side capacitive stage.
        LG_stage;   % Grid-side inductive stage.
        CD_stage;  % DC-side capacitive stage.
    end
    
    properties
        P_reference;
        Q_reference;
        Vdc_reference;
    end
    
    methods
        function obj = PWM_LCL_C_PI_VQ_I(node,index,LA_stage,CF_stage,LG_stage,CD_stage,f_nominal,P_reference,Q_reference,Vdc_reference,base)
            % obj = PWM_LCL_C_PI_VQ_IE(node,index,LA_stage,CF_stage,LG_stage,CD_stage,f_nominal,P_reference,Q_reference,Vdc_reference,base)
            
            import Harmonics.Resource.*;
            
            control_software = PWM_LCL_C_PI_VQ_I.buildControlSoftware(LA_stage,CF_stage,LG_stage,CD_stage,f_nominal,base);
            
            warning('Matrices (LTI) of the power hardware are function of reference values.')
            power_hardware = PWM_LCL_C_PI_VQ_I.buildPowerHardware(LA_stage,CF_stage,LG_stage,CD_stage,P_reference,Vdc_reference,f_nominal,base);
            internal_transform = PWM_LCL_C_PI_VQ_I.buildInternalTransform();
            external_transform = PWM_LCL_C_PI_VQ_I.buildExternalTransform();
            
            obj = obj@Harmonics.Resource.CIR_I(node,index,power_hardware,control_software,internal_transform,external_transform);
            
            obj.LA_stage = LA_stage;
            obj.CF_stage = CF_stage;
            obj.LG_stage = LG_stage;
            obj.CD_stage = CD_stage;
            
            if(~isa(P_reference,'numeric'))
                error('P_reference: type.');
            elseif(~isa(Q_reference,'numeric'))
                error('Q_reference: type.');
            elseif(~isa(Vdc_reference,'numeric'))
                error('Vdc_reference: type.');
            elseif(~all(size(P_reference)==1))
                error('P_reference: size.');
            elseif(~all(size(Q_reference)==1))
                error('Q_reference: size.');
            elseif(~all(size(Vdc_reference)==1))
                error('Vdc_reference: size.');
            else
                obj.P_reference = P_reference;
                obj.Q_reference = Q_reference;
                obj.Vdc_reference = Vdc_reference;
            end
        end
        
        function [n_stages_phases,n_stages_dc] = getNumberOfStages(obj)
            % [n_stages_phases,n_stages_dc] = getNumberOfStages(obj)
            n_stages_phases = 3; % L+C+L
            n_stages_dc     = 1; % C
        end

        function l_operating = getLengthOfOperatingPoint(obj)
            % l_operating = getLengthOfOperatingPoint(obj)
            l_operating = 7; % Varef(3),Ia(3),Vd(1)
        end
        
        % Implement abstract methods
        
        [Ih,dIh_dVh,Oh] = calculateGridResponse(obj,Ts,f1,h,Vh,Oh,base);
        [W_K,dW_KP] = calculateReference(obj,W_P,theta_0,h_max,base)
        [G_PP,G_PK,G_KP,G_KK] = calculateInternalGain(obj,O_P_d,theta_0,Ts,f_1,h_max,base);
        [VAref_h,IA_h,VF_h,IG_h,VD_h] = calculateInternalResponse(obj,Ts,f_1,h,VG_h,VA_ref_h,IA_h,VD_h,base)
        [T_PG,T_GP] = calculateExternalTransform(obj,h_max);
        [T_KP,T_PK] = calculateInternalTransform(obj,theta_0,Ts,f_1,h_max);
        
        [outSim] = runTimeDomainSimulation(obj,folder,modelName,converterName,variantName,h_max,Ts);
        initializeTimeDomainSimulation(obj,modelName,converterName,variantName);
    end
    
    methods(Static)
        % Implement abstract methods;
        
        resource = buildFromFile(file,base,f_nominal)
        power_hardware = buildPowerHardware(LA_stage,CF_stage,LG_stage,CD_stage,P_reference,Vdc_reference,f_1,base);
        control_software = buildControlSoftware(LA_stage,CF_stage,LG_stage,CD_stage,f_1,base);
        
        function transform = buildInternalTransform()
            
            import Harmonics.Resource.*;
            
            transform = DQ_Transform();
        end
        
        function transform = buildExternalTransform()
            
            import Harmonics.Resource.*;
            
            transform = WyeWye_Connection('yes','no');
        end
    end
end
