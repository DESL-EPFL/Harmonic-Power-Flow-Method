classdef Fourier
    methods(Static)
        X = buildVector(h,X_h,h_max);
        [h,X_h] = splitVector(X,n_x);
        M = buildMatrix(M_h,n_y,n_x)
        [h,M_h] = splitMatrix(M,n_y,n_x);
        X_h_full = complete(h,X_h,h_max);
    end
end