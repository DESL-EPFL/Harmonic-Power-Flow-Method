function resource = buildFromFile(file,base,f_nominal)
% resource = buildFromFile(file,base,f_nominal)

import Harmonics.*
import Harmonics.Resource.*;

if(~isa(file,'char'))
    error('file: type.');
elseif(~isa(base,'Base'))
    error('base: type.')
elseif(~isa(f_nominal,'numeric'))
    error('f_nominal: type.');
elseif(~all(size(base)==1))
    error('base: size.');
elseif(~all(size(f_nominal)==1))
    error('f_nominal: size.');
else
    [numeric,text,raw] = xlsread(file,'Node');
    node = raw{2,1};
    index = raw{2,2};
    
    [numeric,text,raw] = xlsread(file,'Reference');
    P_reference = numeric(1);%/base.getBasePower();
    Q_reference = numeric(2);%/base.getBasePower();
    
    L_stage = PI_Loop_L.buildFromFile(file,'L_stage',base);
    
    resource = PWM_L_PI_PQ(node,index,L_stage,f_nominal,P_reference,Q_reference,base);
end

end