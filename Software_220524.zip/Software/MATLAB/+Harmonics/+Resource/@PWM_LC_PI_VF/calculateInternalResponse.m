function [VA_h,IA_h,VG_h] = calculateInternalResponse(obj,Ts,f_1,h,IG_h,base)
% [VA_h,IA_h,VF_h,IG_h] = calculateInternalResponse(obj,Ts,f_1,h,IG_h,base)
% 
% INPUT
% - Ts          Sampling time.
% - f_1         Fundamental frequency.
% - h           Harmonic orders (w.r.t. the fundamental frequency)
% - IG_h        Fourier coefficients of the grid current.
% - base        Per-unit base.
% 
% OUTPUT
% - VA_h        Fourier coefficients of the actuator voltage.
% - IA_h        Fourier coefficients of the actuator current.
% - VG_h        Fourier coefficients of the grid voltage.

import Harmonics.*;

h_max = max(h);

%% Input

W_P = Fourier.buildVector(h,IG_h);

%% Internal Response

[W_K,~] = calculateReference(obj,h_max,base);

[G_PP,G_PK,G_KP,G_KK] = obj.calculateInternalGain(Ts,f_1,h_max);

Y_P = G_PP * W_P + G_PK * W_K;
Y_K = G_KP * W_P + G_KK * W_K;

%% Assign Outputs

[~,Y_K_h] = Fourier.splitVector(Y_K,obj.control_software.getNumberOfOutputs);
VA_h = Y_K_h;

[~,Y_P_h] = Fourier.splitVector(Y_P,obj.power_hardware.getNumberOfOutputs);
n_P = obj.internal_transform.getSizeOfDomain;
IA_h = Y_P_h(1:n_P,:);
VG_h = Y_P_h((1:n_P)+n_P,:);

end

