function [] = initializeTimeDomainSimulation(obj,modelName,converterName,variantName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

nodeName = obj.node;
nodeName_index = [nodeName,'_',num2str(obj.index)];
blockName = [modelName,'/',nodeName,'/',nodeName_index,'/',variantName];

if strcmp(variantName,"CIDER")
    set_param(blockName,'LA_Stage',[converterName,'.LA_stage']);
    set_param(blockName,'C_Stage',[converterName,'.CF_stage']);
    set_param(blockName,'LG_Stage',[converterName,'.LG_stage']);
    set_param(blockName,'CD_Stage',[converterName,'.CD_stage']);
    set_param(blockName,'P_reference',[converterName,'.P_reference']);
    set_param(blockName,'Q_reference',[converterName,'.Q_reference']);
    set_param(blockName,'Vdc',[converterName,'.Vdc_reference']);
else
    set_param(blockName,'P_reference',[converterName,'.P_reference']);
    set_param(blockName,'Q_reference',[converterName,'.Q_reference']);
end

end