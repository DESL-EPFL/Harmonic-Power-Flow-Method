function [YL_f,YT_f] = buildPrimitiveAdmittanceMatrices(obj,f,base)
% [YL_f,YT_f] = buildPrimitiveAdmittanceMatrices(obj,f)
%
% INPUT
%   f       Frequencies
% 
% OUTPUT
%   YL_f    Primitive branch admittance matrix.
%   YT_f    Primitive shunt admittance matrix.

import Harmonics.Grid.*;
import Harmonics.Grid.Line.*;

n_nodes = obj.getNumberOfNodes();
n_lines = obj.getNumberOfLines();
n_phases = obj.getNumberOfWires();

%% Primitive branch admittance matrix

if n_phases == 3
    [R_branch,L_branch,G_shunt,C_shunt] = Three_Wire_Line.buildPiSectionEquivalent(obj.lines,n_phases,n_lines,base);
else
    [R_branch,L_branch,G_shunt,C_shunt] = One_Wire_Line.buildPiSectionEquivalent(obj.lines,n_phases,n_lines,base);
end

R = cell2mat(R_branch);
L = cell2mat(L_branch);

YL_f = zeros([size(R),length(f)]);

for i=1:length(f)
    YL_f(:,:,i) = inv(R + 1i * 2*pi*f(i) * L);
end

%% Primitive shunt admittance matrix

G = repmat({zeros(n_phases,n_phases)},n_nodes,n_nodes);
C = repmat({zeros(n_phases,n_phases)},n_nodes,n_nodes);

for l=1:n_lines
    [found,m] = Node.findByName(obj.nodes,{obj.lines(l).node_from});
    [found,n] = Node.findByName(obj.nodes,{obj.lines(l).node_to});
    
    G{m,m} = G{m,m} + 1/2 * G_shunt{l,l};
    G{n,n} = G{n,n} + 1/2 * G_shunt{l,l};
    C{m,m} = C{m,m} + 1/2 * C_shunt{l,l};
    C{n,n} = C{n,n} + 1/2 * C_shunt{l,l};
end

G = cell2mat(G);
C = cell2mat(C);

YT_f = zeros([size(G),length(l)]);

for i=1:length(f)
    YT_f(:,:,i) = G + 1i * 2*pi*f(i) * C;
end

end