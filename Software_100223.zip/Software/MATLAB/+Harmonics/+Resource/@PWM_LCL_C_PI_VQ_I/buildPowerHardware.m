function power_hardware = buildPowerHardware(LA_stage,CF_stage,LG_stage,CD_stage,P_reference,Vdc_reference,f_1,base)
% power_hardware = buildPowerHardware(LA_stage,C_stage,LG_stage,Cdc_stage,f_1,base)

import Harmonics.*;
import Harmonics.Resource.*;

if(~isa(LA_stage,'PI_Loop_L'))
    error('LA_stage: type.');
elseif(~isa(CF_stage,'PI_Loop_C'))
    error('CF_stage: type.');
elseif(~isa(LG_stage,'PI_Loop_L'))
    error('LG_stage: type.');
elseif(~isa(CD_stage,'PI_Loop_C'))
    error('CFDstage: type.');
else
    
    P_ref = P_reference / base.getBasePower;
    Vdc_ref = Vdc_reference / base.getBaseVoltage;

    n_phases = LA_stage.dim_ph;
    n_dc = CD_stage.dim_ph;
    
    [RA,LA] = LA_stage.buildHardwareModel(f_1,base);
    [GF,CF] = CF_stage.buildHardwareModel(f_1,base);
    [RG,LG] = LG_stage.buildHardwareModel(f_1,base);
    [GD,CD] = CD_stage.buildHardwareModel(f_1,base);
    
    h = 0;
    
    Z33 = zeros(n_phases,n_phases); % Zero matrix (w.r.t. ABC coordinates).
    Z13 = zeros(n_dc,n_phases);
    Z31 = zeros(n_phases,n_dc);
    I = eye(n_phases); % Identity matrix (w.r.t. ABC coordinates).
  
    
    A_h = [-inv(LA)*RA,-inv(LA),Z33,Z31;...
           inv(CF),-inv(CF)*GF,-inv(CF),Z31;...
           Z33,inv(LG),-inv(LG)*RG,Z31;...
           Z13,Z13,Z13,-inv(CD)*GD];
    A_h(end,end) = A_h(end,end) - inv(CD)*P_ref/Vdc_ref^2;
    B_h = zeros(3*n_phases+n_dc,n_phases);
    E_h = [Z33,Z31,Z33;...
           Z33,Z31,Z33;...
           -inv(LG),Z31,Z33;...
           Z13,inv(CD),Z13];
    E_h(end,4) = E_h(end,4) + inv(CD);
    
    C_h = [eye(3*n_phases+n_dc);...
           zeros(n_phases+n_dc,3*n_phases+n_dc)];
    C_h(end,end) = C_h(end,end) - P_ref/Vdc_ref^2;
    D_h = zeros(4*n_phases+2*n_dc,n_phases);
    F_h = [zeros(3*n_phases+n_dc,2*n_phases+n_dc);...
           eye(n_phases),zeros(n_phases,n_phases+n_dc);...
           Z13,1,zeros(n_dc,n_phases)];
    F_h(end,4) = F_h(end,4) + 1;
    
    power_hardware = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h);
end

end