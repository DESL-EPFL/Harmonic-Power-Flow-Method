classdef Grid
    properties(SetAccess=private)
        nodes;
        lines;
        number_of_wires;
    end
    
    methods
        function obj = Grid(nodes,lines,number_of_wires)
            
            import Harmonics.Grid.*;
            import Harmonics.Grid.Line.*;
            
            if(~isa(nodes,'Node'))
                error('nodes: type.');
            elseif(~(isa(lines,'Three_Wire_Line')||...
                     isa(lines,'One_Wire_Line')))
                error('lines: type.');
            elseif(~isa(number_of_wires,'numeric'))
                error('number_of_wires: type.');
            else
                
                obj.nodes = nodes;
                obj.lines = lines;
                obj.number_of_wires = number_of_wires;
            end
        end
        
        function n_nodes = getNumberOfNodes(obj)
            n_nodes = length(obj.nodes);
        end
        
        function n_lines = getNumberOfLines(obj)
            n_lines = length(obj.lines);
        end
        
        function n_wires = getNumberOfWires(obj)
            n_wires = obj.number_of_wires;
        end
        
        A = buildIncidenceMatrix(obj);
        [YL_f,YT_f] = buildPrimitiveAdmittanceMatrices(obj,f,base);
        Y_f = buildAdmittanceMatrix(obj,f,base);
        [H_11_f,H_12_f,H_21_f,H_22_f] = buildHybridMatrix(obj,N_1,N_2,f,base);
        [H_11_f,H_12_f,H_21_f,H_22_f] = buildHybridMatrix_new(obj,Y_f,idx_1,idx_2,f);
        initializeTimeDomainSimulation(obj,modelName,gridName);
    end
    
    methods(Static)
        grid = buildFromFile(folder,number_of_wires,file);
    end
end