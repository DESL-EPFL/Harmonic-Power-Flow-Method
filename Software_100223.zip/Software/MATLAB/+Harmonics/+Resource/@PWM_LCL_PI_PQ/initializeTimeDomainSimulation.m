function [] = initializeTimeDomainSimulation(obj,modelName,converterName,variantName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

nodeName = obj.node;
nodeName_index = [nodeName,'_',num2str(obj.index)];
blockName = [modelName,filesep(),nodeName,filesep(),nodeName_index,filesep(),variantName];

if strcmp(variantName,"CIDER")
    set_param(blockName,'LA_Stage',[converterName,'.LA_stage']);
    set_param(blockName,'C_Stage',[converterName,'.C_stage']);
    set_param(blockName,'LG_Stage',[converterName,'.LG_stage']);
    set_param(blockName,'P_reference',[converterName,'.P_reference']);
    set_param(blockName,'Q_reference',[converterName,'.Q_reference']);
else
    set_param(blockName,'P_reference',[converterName,'.P_reference']);
    set_param(blockName,'Q_reference',[converterName,'.Q_reference']);
end
    
% set_param([modelName,filesep(),'y_',nodeName],'VariableName',['y_',nodeName]);

end