clear all;
close all;
clc;

disp('START');

import Harmonics.*
import Harmonics.Grid.*;
import Harmonics.Resource.*;
import Harmonics.System.*;
  
f_nominal = 50;
h_max = 25;
P_base = 50e3;
V_base = 230*sqrt(2);x
unit_base = Base(P_base,V_base);

h = transpose(0:1:h_max);
n_phases = 3;

Vdc = 900;%converter_following.Vdc_reference;
time = struct('Ts_HW',1e-06,'Ts_SW',1e-06,'Tend',0.5); % in (s)

%% Build

folder = '/Users/johanna/EPFL GDrive/GIT/Software/';

folder_config = [folder filesep() 'Configuration Files/22Bus_LCL_DC'];
folder_results = [folder filesep() 'Results' filesep() 'Systems'];

file_results = '22Bus_DC_h25';


file = [folder_config filesep() 'System_22Bus_param.xlsx'];
power_grid = Grid.buildFromFile(file,n_phases,unit_base);

file = [folder_config filesep() 'TE.xlsx'];
slack = Thevenin.buildFromFile(file);%,unit_base);

for r = 1 : 5
    file = [folder_config filesep() 'PWM_LCL_C_PI_VQ_P_' num2str(r) '_Pn60k.xlsx'];
    converter_following(r) = PWM_LCL_C_PI_VQ_I.buildFromFile(file,unit_base,f_nominal);
end
for r = 1 : 4
    file = [folder_config filesep() 'RLC_Load_' num2str(r) '_Pn60k.xlsx'];
    passive_loads(r) = RLC_S_Load.buildFromFile(file,n_phases,unit_base,f_nominal);
end

system = AC_Subsystem(power_grid,slack,[],converter_following,passive_loads);

%%  Simulate TDS

V_h = struct();
I_h = struct();

% Simulation Workspace Parameter
PLL = struct('TsetPLL',0.5,'zeta',0.7);

% Thevenin Equivalent
TE = struct('h',slack.h,'bin',slack.E_h,'R',slack.R,'L',slack.L,'Name','VTE');
dist = TDSAnalysis.getWaveform(TE,0,time.Tend,f_nominal,time.Ts_HW);
spectrum = TDSAnalysis.getSpectrum(dist,50,time.Ts_HW,h_max);
THD = sqrt(sum(abs(2*slack.E_h(1,2:end)).^2))/abs(2*slack.E_h(1,1))*100; % Total harmonic distortion

% ------- Comment in/out for simulating/loading

[t_TDS_exc,t_TDS_prc,simOut] = system.runTimeDomainSimulation('TDS_22Bus_System_DC','system',h_max,time.Ts_HW);

for n = 1: length(simOut{1})
    V_h_TDS{n,1} = simOut{1}(n).Y.VG.bin;
    I_h_TDS{n,1} = simOut{1}(n).Y.IG.bin;
end
V_h.TDS = cell2mat(V_h_TDS);
I_h.TDS = cell2mat(I_h_TDS);

for n = 1: length(simOut{2})
    Yo_h{n,1}.VAref = simOut{2}(n).Yo.VAref.bin;
    Yo_h{n,1}.IA    = simOut{2}(n).Yo.IA.bin;
    Yo_h{n,1}.VD    = simOut{2}(n).Yo.VD.bin;
end

save([folder_results filesep() 'TDS_' file_results '.mat'],'V_h','I_h','Yo_h','t_TDS_exc','t_TDS_prc')

% ------- 

load([folder_results filesep() 'TDS_' file_results '.mat'],'V_h','I_h','Yo_h','t_TDS_exc','t_TDS_prc');

% normalize
V_base = unit_base.getBaseVoltage;
I_base = unit_base.getBaseCurrent;

V_h.TDS = V_h.TDS(:,1:h_max+1) / V_base; 
I_h.TDS = I_h.TDS(:,1:h_max+1) / I_base; 

for n = 1: length(Yo_h)
    Yo_h{n,1}.VAref = Yo_h{n,1}.VAref(:,1:h_max+1) / V_base;
    Yo_h{n,1}.IA    = Yo_h{n,1}.IA(:,1:h_max+1) / I_base;
    Yo_h{n,1}.VD    = Yo_h{n,1}.VD(:,1:h_max+1) / V_base;
end

%% Simulate HPF

n_nodes = length(system.grid.nodes);
percentage = 0;

% Init
V_h_0 = zeros(n_nodes*n_phases,h_max+1);
I_h_0 = zeros(n_nodes*n_phases,h_max+1);
O_V_h_0 = cell(length(system.resources_forming),1);
O_I_h_0 = cell(length(system.resources_following),1);

V_h_0 = initializeHarmonicPowerFlow(V_h_0,n_phases,[1],percentage,h_max);
% I_h_0 = initializeHarmonicPowerFlow(I_h_0,n_phases,[1],percentage,h_max);

% Operating point - init (ordered w.r.t. CIDERs)
for k = 1:length(O_I_h_0)
    VAref_d = zeros(n_phases,h_max+1);
    IA_d    = zeros(n_phases,h_max+1);
    VD_d    = zeros(1,h_max+1);

    VAref_d = initializeHarmonicPowerFlow(VAref_d,n_phases,[1],percentage,h_max);
%     IA_d    = initializeHarmonicPowerFlow(IA_d,n_phases,[1],percentage,h_max);
    VD_d(:,h==0) = Vdc / V_base * (1 + rand(size(VD_d(:,h==0)))*percentage/100);

    O_I_h_0{k} = [VAref_d;IA_d;VD_d];
end

% Method
options = struct('maxIteration',10, ...
                 'tolerance',1e-8, ...
                 'alpha',1, ...
                 'kronReduction',1, ...
                 'slackMode','forming');
[V_f_HPF,I_f_HPF,n_HPF,t_HPF] = ...
            system.solveNewtonRaphson(time.Ts_SW,f_nominal,h_max, ...
                                      V_h_0,I_h_0,O_V_h_0,O_I_h_0, ...
                                      unit_base,options);
results.time = timing(t_HPF,n_HPF,t_TDS_exc,t_TDS_prc,time,f_nominal);

V_h.HPF = V_f_HPF(:,:,end);
I_h.HPF = I_f_HPF(:,:,end);

disp('STOP');

%% Sequence decomposition

[T_abc2pnz,T_pnz2abc] = PNZ_Transform.build();

nodesIdx = [1,11,15:17,18,19:22];
k = 1;
for i = nodesIdx    
    idx = (1:n_phases)+(i-1)*n_phases;
    V_abc_TDS = V_h.TDS(idx,2);
    V_pnz_TDS = T_abc2pnz*V_abc_TDS;
    V_abc_HPF = V_h.HPF(idx,2);
    V_pnz_HPF = T_abc2pnz*V_abc_HPF;
    
    rVnp(k) = abs(V_pnz_HPF(2))/abs(V_pnz_HPF(1));
    rVzp(k) = abs(V_pnz_HPF(3))/abs(V_pnz_HPF(1));
    
    I_abc_TDS = I_h.TDS(idx,2);
    I_pnz_TDS = T_abc2pnz*I_abc_TDS;
    I_abc_HPF = I_h.HPF(idx,2);
    I_pnz_HPF = T_abc2pnz*I_abc_HPF;

    rInp(k) = abs(I_pnz_HPF(2))/abs(I_pnz_HPF(1));
    rIzp(k) = abs(I_pnz_HPF(3))/abs(I_pnz_HPF(1));
    k = k+1;
end

rVnp = round(rVnp*100,2);
rVzp = round(rVzp*100,2);
rInp = round(rInp*100,2);
rIzp = round(rIzp*100,2);

data = [nodesIdx',rVnp',rVzp',rInp',rIzp'];
names = {'Node','|V_n|/|V_p| (%)','|V_z|/|V_p| (%)','|I_n|/|I_p| (%)','|I_z|/|I_p| (%)'};
seq_ratios = table(data(:,1),data(:,2),data(:,3),data(:,4),data(:,5),'VariableNames',names);

display(seq_ratios)

%% Plot
% copy plots after each run

figNr = 400;

idx_slack = 1:3;
n_follow = [11,15:17,18];
idx_follow = reshape((n_follow-1)*n_phases+[1:n_phases]',1,[]);
n_unbal = 19:22;
idx_unbal = reshape((n_unbal-1)*n_phases+[1:n_phases]',1,[]);
idx_form = [];

h_set = [1,5,7,11,13,17,19,23,25];

% Voltage and Current Errors of all grid-following resources
file_location = [folder_results filesep() file_results '_error'];
semilog_Error(V_h,I_h,idx_follow,idx_unbal,h_set,h_max,{'PQ','Z'},file_location,figNr+1);

[results.errorV,results.errorI] = accuracy(V_h,I_h,idx_follow,idx_unbal,h_set,h_max);

%% Plot nodes
% copy plots after each run

h_set = [1,5,7,11,13,17,19,23,25];

% single nodes
for i = 11%[11,15:17,18]
%     file_location = [folder_results filesep() file_results '_IG_N',num2str(i)];
%     semilog_Resource(I_h.TDS,I_h.HPF,(1:n_phases)+(i-1)*n_phases,h_set,h_max,'I','A','\gamma',file_location,i+100);
end
for i = 19:22
%     file_location = [folder_results filesep() file_results '_IG_N',num2str(i)];
%     semilog_Resource(I_h.TDS,I_h.HPF,(1:n_phases)+(i-1)*n_phases,h_set,h_max,'I','A','\gamma',file_location,i+100);
end

% three nodes
i = 1;
idx_revision{1} = (1:n_phases)+(i-1)*n_phases;%idx_slack;
titleStr{1} = 'N1';

i = 15;
idx_revision{2} = (1:n_phases)+(i-1)*n_phases;
titleStr{2} = 'N15';

i = 20;% 18;%
idx_revision{3} = (1:n_phases)+(i-1)*n_phases;
titleStr{3} = 'N20';

I_h.HPF_DC = I_h.TDS;
V_h.HPF_DC = V_h.TDS;

% file_location = [folder_results filesep() file_results '_IG_N1_15_20'];
% semilog_Resource_3Nodes(I_h,idx_revision,h_set,h_max,'I','A',titleStr,file_location,1);
% file_location = [folder_results filesep() file_results '_VG_N1_15_20'];
% semilog_Resource_3Nodes(V_h,idx_revision,h_set,h_max,'V','A',titleStr,file_location,2);