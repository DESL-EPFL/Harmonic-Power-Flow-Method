function [Ih,dIh_dVh,Oh] = calculateGridResponse(obj,Ts,f_1,h,Vh,Oh,base)
% [Ih,dIh_dVh] = calculateGridResponse(obj,f1,h,Vh,base)
% 
% INPUT
% - Ts          Sampling time.
% - f_1         Fundamental frequency.
% - h           Harmonic orders (w.r.t. the fundamental frequency)
% - Vh          Fourier coefficients of the grid voltage.
% - Oh          Fourier coefficients of the operating point (empty).
% - base        Per-unit base.
% 
% OUTPUT
% - Ih          Fourier coefficients of the grid current.
% - dIh_dVh     Fourier coefficients of the Jacobian matrix
%               of the grid current w.r.t. the grid voltage.
% - Oh          Fourier coefficients of the new operating point (empty).

import Harmonics.*;

h_max = max(h);

%% Input

W_G = Fourier.buildVector(h,Vh);

%% External Transform

[T_PG,T_GP] = obj.calculateExternalTransform(h_max);

%% Internal Response

[T_abc2pnz,~] = PNZ_Transform.build();
V1_ABC = Vh(:,h==1);
V1_PNH = T_abc2pnz*V1_ABC;
theta0 = angle(V1_PNH(1));

W_P = T_PG * W_G;
[W_K,dW_KP] = calculateReference(obj,h_max,base);

[G_PP,G_PK,G_KP,G_KK] = obj.calculateInternalGain(theta0,Ts,f_1,h_max);

Y_P = G_PP * W_P + G_PK * W_K;
%Y_K = G_KP * W_P + G_KK * W_K;

dY_PP = G_PP + G_PK * dW_KP;

%% External Response

Y_G = T_GP * Y_P;
dY_GG = T_GP * dY_PP * T_PG;

n_W_G = obj.external_transform.getSizeOfCodomain();
n_Y_G = n_W_G;

[~,Ih] = Fourier.splitVector(Y_G,n_Y_G);
[~,dIh_dVh] = Fourier.splitMatrix(dY_GG,n_Y_G,n_W_G);

end