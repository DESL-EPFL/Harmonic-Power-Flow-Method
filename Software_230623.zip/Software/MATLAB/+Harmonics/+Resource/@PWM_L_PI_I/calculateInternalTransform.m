function [T_KP,T_PK] = calculateInternalTransform(obj,theta_0,Ts,f_1,h_max)
% [T_KP,T_PK] = calculateInternalTransform(obj,theta_0,Ts,f_1,h_max)

import Harmonics.*;

h = obj.internal_transform.h;
n_stages = obj.getNumberOfStages();

% Forward matrix

T_KP_h = repmat({obj.internal_transform.T_FW_h*exp(1i*theta_0)},n_stages+1,1);
T_KP_h = blkdiag(T_KP_h{:});
T_KP = Toeplitz.buildRectangularMatrix(h,T_KP_h,h_max+1,h_max);

% Backward matrix

T_PK_h = obj.internal_transform.T_BW_h*exp(1i*theta_0);
T_PK = Toeplitz.buildRectangularMatrix(h,T_PK_h,h_max,h_max+1);

% Delay

% use diag(Fourier.buildVector) instead?!
tau_h = repmat({zeros(3)},1,1,2*h_max+1);
h_0 = h_max+1;
       
for k = 1:h_max+1
    h_i = k-1;
    tau_h_i = eye(3)*exp(-1i*2*pi*(k-1)*f_1*Ts);
    
    if(h_i==0)
        tau_h{h_0} = tau_h_i;
    else
        tau_h{h_0+h_i} = tau_h_i;
        tau_h{h_0-h_i} = conj(tau_h_i);
    end
end
tau = blkdiag(tau_h{:});

T_PK = tau*T_PK;
       
end