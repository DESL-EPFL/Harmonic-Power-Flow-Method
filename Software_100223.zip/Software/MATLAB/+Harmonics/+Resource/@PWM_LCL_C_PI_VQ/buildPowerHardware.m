function power_hardware = buildPowerHardware(LA_stage,CF_stage,LG_stage,CD_stage,f_1,base)
% power_hardware = buildPowerHardware(LA_stage,C_stage,LG_stage,Cdc_stage,f_1,base)

import Harmonics.*;
import Harmonics.Resource.*;

if(~isa(LA_stage,'PI_Loop_L'))
    error('LA_stage: type.');
elseif(~isa(CF_stage,'PI_Loop_C'))
    error('CF_stage: type.');
elseif(~isa(LG_stage,'PI_Loop_L'))
    error('LG_stage: type.');
elseif(~isa(CD_stage,'PI_Loop_C'))
    error('CD_stage: type.');
else
    
    n_phases = LA_stage.dim_ph;
    n_dc = CD_stage.dim_ph;
    
    [RA,LA] = LA_stage.buildHardwareModel(f_1,base);
    [GF,CF] = CF_stage.buildHardwareModel(f_1,base);
    [RG,LG] = LG_stage.buildHardwareModel(f_1,base);
    [GD,CD] = CD_stage.buildHardwareModel(f_1,base);
    
    h = 0;
    
    Z33 = zeros(n_phases,n_phases); % Zero matrix (w.r.t. ABC coordinates).
    Z13 = zeros(n_dc,n_phases);
    Z31 = zeros(n_phases,n_dc);
    I = eye(n_phases); % Identity matrix (w.r.t. ABC coordinates).
  
    
    A_h = [-inv(LA)*RA,-inv(LA),Z33,Z31;...
           inv(CF),-inv(CF)*GF,-inv(CF),Z31;...
           Z33,inv(LG),-inv(LG)*RG,Z31;...
           Z13,Z13,Z13,-inv(CD)*GD];
    B_h = zeros(3*n_phases+n_dc,n_phases);
    E_h = [Z33,Z31,Z33;...
           Z33,Z31,Z33;...
           -inv(LG),Z31,Z33;...
           Z13,-inv(CD),Z13];
    
    C_h = [eye(3*n_phases+n_dc);...
           zeros(n_phases+n_dc,3*n_phases+n_dc)];
    D_h = zeros(4*n_phases+2*n_dc,n_phases);
    F_h = [zeros(3*n_phases+n_dc,2*n_phases+n_dc);...
           eye(n_phases),zeros(n_phases,n_phases+n_dc);...
           Z13,1,zeros(n_dc,n_phases)];
    
    power_hardware = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h);
end

end