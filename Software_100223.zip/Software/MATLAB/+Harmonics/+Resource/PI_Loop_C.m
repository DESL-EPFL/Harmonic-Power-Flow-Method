classdef PI_Loop_C < Harmonics.Resource.PI_Loop
    % PI_Loop_C represents a control loop for a capacitive filter stage.
    
    properties(SetAccess=private)
        G;  % Conductance of the capacitor.
        C;  % Capacitance of the capacitor.
    end
    
    methods
        function obj = PI_Loop_C(G,C,dim_ph,dim_cs,K_FT,K_FB,T_FB)
            % obj = PI_Loop_C(G,C,K_FT,K_FB,T_FB)
            
            obj = obj@Harmonics.Resource.PI_Loop(dim_ph,dim_cs,K_FT,K_FB,T_FB);
            
            % Check type
            if(~isa(G,'numeric'))
                error('G: type.');
            elseif(~isa(C,'numeric'))
                error('C: type.');
            else
                % Check size
                if(length(G)~=1)
                    error('G: size.');
                elseif(length(C)~=1)
                    error('C: size.');
                else
                    % Construct object
                    
                    obj.G = G;
                    obj.C = C;
                end
            end
        end
        
        % Implement abstract methods
        
        function [G,C] = buildHardwareModel(obj,f_1,base)
            % [G,C] = buildHardwareModel(obj)
            %
            % OUTPUT
            %   G/C     Resistance/inductance matrix (positive/negative sequence).
            
            Y_base = base.getBaseAdmittance();
            
            G = obj.G * eye(obj.dim_ph);% + 2*pi*f_1*obj.C * [0,-1;1,0];
            C = obj.C * eye(obj.dim_ph);
            
            G = G/Y_base;
            C = C/Y_base;
        end
        
        function [K_FT,K_FF,K_FB,T_FB] = buildSoftwareModel(obj,f_1,base)
            % [K_FT,K_FF,K_FB,T_FB] = buildSoftwareModel(obj,f_1)
            %
            % INPUT
            %   f_1             Fundamental frequency.
            %
            % OUTPUT
            %   K_{FT/FF/FB}    Gain matrices (DQ coordinates).
            %   T_FB            Feed-back integration time.
            
%             dim = 2;
            
            Y_base = base.getBaseAdmittance();
            
            K_FT = obj.K_FT * eye(obj.dim_cs);
            K_FF = obj.G * eye(obj.dim_cs);
            if obj.dim_cs == 2
                K_FF = K_FF + 2*pi*f_1*obj.C * [0,-1;1,0];
            end
            K_FB = obj.K_FB * eye(obj.dim_cs);
            T_FB = obj.T_FB;
            
            K_FF = K_FF/Y_base;
            K_FB = K_FB/Y_base;
        end
    end
    
    methods(Static)
        function stage = buildFromFile(file,sheet,base)
            % stage = buildFromFile(file,sheet,base)
            
            import Harmonics.*;
            import Harmonics.Resource.*;
            
            if(~isa(file,'char'))
                error('file: type.');
            elseif(~isa(sheet,'char'))
                error('sheet: type.');
            elseif(~isa(base,'Base'))
                error('base: type.');
            else
                [numeric,text,raw] = xlsread(file,sheet);
                
                Y_base = base.getBaseAdmittance();
                
                C = numeric(1);%/Y_base;
                G = numeric(2);%/Y_base;
                K_FB = numeric(3);%/Y_base;
                T_FB = numeric(4);
                K_FT = numeric(5);
                dim_ph = numeric(6);
                dim_cs = numeric(7);
                
                stage = PI_Loop_C(G,C,dim_ph,dim_cs,K_FT,K_FB,T_FB);
            end
        end
    end
end