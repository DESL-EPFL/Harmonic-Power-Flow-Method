function [T_PG,T_GP] = calculateExternalTransform(obj,h_max)
% [T_PG,T_GP] = calculateExternalTransform(obj,h_max)

import Harmonics.*;

h = obj.external_transform.h;
[n_stages_AC,n_stages_DC] = obj.getNumberOfStages();

% Forward matrix

T_PG_h = [{obj.external_transform.T_FW_h};...
          {zeros([1,size(obj.external_transform.T_FW_h,2)])};...
          {zeros(size(obj.external_transform.T_FW_h))}];
T_PG_h = cell2mat(T_PG_h);
T_PG = Toeplitz.buildSquareMatrix(h,T_PG_h,h_max);

% Backward matrix

T_GP_h = [repmat({zeros(size(obj.external_transform.T_BW_h))},1,n_stages_AC),...
          repmat({zeros([size(obj.external_transform.T_BW_h,2),1])},1,n_stages_DC),...
          {zeros(size(obj.external_transform.T_BW_h))},...
          {zeros([size(obj.external_transform.T_BW_h,1),1])}];
T_GP_h{end-3} = obj.external_transform.T_BW_h;
T_GP_h = cell2mat(T_GP_h);
T_GP = Toeplitz.buildSquareMatrix(h,T_GP_h,h_max);

end
