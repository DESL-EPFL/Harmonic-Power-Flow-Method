classdef PNZ_Transform
    % PNZ_Transform is the transform between phase (ABC) coordinates
    % and positive/negative/zero (PNZ) components.
   
    methods(Static)
        function [T_FW,T_BW] = build()
            % [T_FW,T_BW] = build()
            
            T_abc2pnz = zeros(3,3);
            T_abc2pnz(1,1) = 1;
            T_abc2pnz(1,2) = exp(1i*2*pi/3);
            T_abc2pnz(1,3) = exp(1i*2*pi/3)^2;
            T_abc2pnz(2,1) = 1;
            T_abc2pnz(2,2) = exp(1i*2*pi/3)^2;
            T_abc2pnz(2,3) = exp(1i*2*pi/3);
            T_abc2pnz(3,1) = 1;
            T_abc2pnz(3,2) = 1;
            T_abc2pnz(3,3) = 1;
            T_abc2pnz = 1/3*T_abc2pnz;
            
            T_pnz2abc = inv(T_abc2pnz);
            
            T_FW = T_abc2pnz;
            T_BW = T_pnz2abc;
        end
    end
end