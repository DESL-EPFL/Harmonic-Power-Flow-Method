function [t_exec,t_proc,yOut] = runTimeDomainSimulation(obj,modelName,systemName,h_max,Ts)
% [] = runTimeDomainSimulation()
%
% INPUT
%   
% OUTPUT
%

import Harmonics.*

open_system(modelName);%[folder,filesep(),modelName]);

% subsystems
for j = 1:length(obj.subsystems)
    obj.subsystems(j).initializeTimeDomainSimulation([modelName],[systemName,'.subsystems(',num2str(j),')'])
end

% interfacing converters
for r = 1:length(obj.interfacing_converters)
    obj.interfacing_converters(r).initializeTimeDomainSimulation(modelName,[systemName,'.interfacing_converters(',num2str(r),')'],'CIDER')
end

% Simulate

timer = tic();

disp('TDS (Simulink): start.');
disp(' ');

simOut = sim(modelName,'ReturnWorkspaceOutputs','on');
y_sim = struct2cell(simOut.y);
yo_sim = struct2cell(simOut.yo);

disp('##########');
t_exec = toc(timer);
disp(['Total Execution time: ' num2str(t_exec) ' s.']);


% Fourier analysis

timer = tic();

N_periods = 5;
f_nominal = 50;
window = N_periods*1/f_nominal; %s 5 periods

%y
y = cell(size(y_sim));
Y = cell(size(y_sim));
for n = 1: size(y_sim)
    y{n}.vG = TDSAnalysis.windowingFcn(y_sim{n}.vG,Ts,window);
    y{n}.iG = TDSAnalysis.windowingFcn(y_sim{n}.iG,Ts,window);
    Y{n}.VG = TDSAnalysis.getSpectrum(y{n}.vG,f_nominal,Ts,h_max);
    Y{n}.IG = TDSAnalysis.getSpectrum(y{n}.iG,f_nominal,Ts,h_max);
end

%yo
yo = cell(size(yo_sim));
Yo = cell(size(yo_sim));
for n = 1: size(yo_sim)
    yo{n}.vAref = TDSAnalysis.windowingFcn(yo_sim{n}.vAref,Ts,window);
    yo{n}.iA = TDSAnalysis.windowingFcn(yo_sim{n}.iA,Ts,window);
    yo{n}.vD = TDSAnalysis.windowingFcn(yo_sim{n}.vD,Ts,window);
    Yo{n}.VAref = TDSAnalysis.getSpectrum(yo{n}.vAref,f_nominal,Ts,h_max);
    Yo{n}.IA = TDSAnalysis.getSpectrum(yo{n}.iA,f_nominal,Ts,h_max);
    Yo{n}.VD = TDSAnalysis.getSpectrum(yo{n}.vD,f_nominal,Ts,h_max);
end

t_proc = toc(timer);
disp(['Processing time: ' num2str(t_proc) ' s.']);

disp('TDS (Simulink): stop.');
disp(' ');

yOut{1} = struct('y',y,'Y',Y);
yOut{2} = struct('yo',yo,'Yo',Yo);

end