function X = buildVector(h,X_h)
% X = buildVector(h,X_h)
%
% INPUT
%   h       Harmonic orders h>=0 (column vector).
%   X_h     Fourier coefficients (rows=variables, columns=harmonics).
%
% OUTPUT
%   X       Fourier spectrum (column vector).

if(~isa(h,'numeric'))
    error('h: type.');
elseif(~isa(X_h,'numeric'))
    error('X_h: type');
else
   [n_variables,n_harmonics] = size(X_h);
   
   if(~all(size(h)==[n_harmonics,1]))
       error('X_h: size.');
   else
       %warning('h_max should be entered (just like for Toeplitz).');
       h_max = max(h);
       
       X = repmat({zeros(n_variables,1)},2*h_max+1,1);
       h_0 = h_max+1;
       
       for i=1:length(h)
           h_i = h(i);
           X_h_i = X_h(:,i);
           
           if(h_i==0)
               X{h_0} = X_h_i;
           else
               X{h_0+h_i} = X_h_i;
               X{h_0-h_i} = conj(X_h_i);
           end
       end
       
       X = cell2mat(X);
   end
end

end