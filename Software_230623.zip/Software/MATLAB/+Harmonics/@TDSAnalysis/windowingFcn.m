function signalOut = windowingFcn(signalIn,Ts,windowLength)

% rectangular window
% extracts last part of signal with length of obj.windowLength
L = length(signalIn.Data);

Tw = (L - windowLength/Ts):1:L-1;

signalOut = timeseries(signalIn.Data(Tw,:),signalIn.Time(Tw,1),'Name',signalIn.Name);

end