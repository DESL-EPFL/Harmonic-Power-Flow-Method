classdef TDSAnalysis    
    methods(Static)     
        FT = getSpectrum(signal,f_1,fs,h_max);
        signal = getWaveform(FT,Tstart,Tend,f_1,fs)
        
        signalOut = windowingFcn(signalIn,fs,windowLength);
    end
end

