function [R,L,G,C] = buildPiSectionEquivalent(lines,n_phases,n_lines,base)
% grid = buildFromFile(file,base)

import Harmonics.*;
import Harmonics.Grid.*;

% if(~isa(file,'char'))
%     error('file: type.');
% elseif(~isa(base,'Base'))
%     error('base: type.');
% else

    Z_base = base.getBaseImpedance();
    Y_base = base.getBaseAdmittance();
    
    R = repmat({zeros(n_phases,n_phases)},n_lines,n_lines);
    L = repmat({zeros(n_phases,n_phases)},n_lines,n_lines);
    G = repmat({zeros(n_phases,n_phases)},n_lines,n_lines);
    C = repmat({zeros(n_phases,n_phases)},n_lines,n_lines);

    for l = 1:length(lines)
        
        % Lines
        
        R{l,l} = 2 * lines(l).R .* lines(l).length / Z_base;
        L{l,l} = 2 * lines(l).L .* lines(l).length / Z_base;
        C{l,l} = 2 * lines(l).C .* lines(l).length / Y_base;
        G{l,l} = 0;

    end
    
% end

end