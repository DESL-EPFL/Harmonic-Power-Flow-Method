function [I_h,dIh_dVh] = calculateGridResponse(obj,f_1,h,V_h,base)

import Harmonics.*;

% if(max(obj.h)>max(h))
%     error('h: range of harmonics is incompatible.');
% else
    h_max = max(h);%max(max(obj.h),max(h));
    
    % Base Values
    V_base = base.getBaseVoltage();
    Z_base = base.getBaseImpedance();
    
    E_h = obj.E_h / V_base;
    E_h = Fourier.complete(obj.h,E_h,h_max);
    V_h = Fourier.complete(h,V_h,h_max);
    
    R = obj.R * eye(3) / Z_base;
    L = obj.L * eye(3) / Z_base;
    
    Y_h = zeros(3,3,h_max+1,h_max+1);
    for k=1:h_max+1
        Y_h(:,:,k,k) = inv(R + 1i*2*pi*f_1*(k-1)*L);
    end
    
    I_h = zeros(3,h_max+1);
    for k=1:(h_max+1) % no coupling between harmonics
        I_h(:,k) = Y_h(:,:,k,k) * (E_h(:,k)-V_h(:,k));
    end

    dIh_dVh = -Y_h;
% end

end