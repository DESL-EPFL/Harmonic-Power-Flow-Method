function Y_f = buildAdmittanceMatrix(obj,f,base)
% Y_f = buildAdmittanceMatrix(obj,f)
%
% INPUT
%   f       Frequencies.
% 
% OUTPUT
%   Y_h     Nodal admittance matrix.

% Incidence matrix

A = obj.buildIncidenceMatrix();
n_phases = obj.getNumberOfWires();
AL = kron(A,eye(n_phases));

% Primitive admittance matrices

[YL_f,YT_f] = obj.buildPrimitiveAdmittanceMatrices(f,base);

% Admittance matrix

Y_f = zeros(size(YT_f));

for i=1:length(f)
    Y_f(:,:,i) = transpose(AL)*YL_f(:,:,i)*AL + YT_f(:,:,i);
end

end