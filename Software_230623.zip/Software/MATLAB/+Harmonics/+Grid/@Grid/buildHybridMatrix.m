function [H_11_f,H_12_f,H_21_f,H_22_f] = buildHybridMatrix(obj,Y_f,idx_1,idx_2,f)
% [H_11_f,H_12_f,H_21_f,H_22_f] = buildHybridMatrix(obj,Y_f,idx_1,idx_2,f)
%
% INPUT
%   Y_f         Admittance matrix.
%   idx_1,idx_2 Set of indices for node partition.
%   f           Frequencies of interest.
%
% OUTPUT
%   H_X_f   Hybrid parameters w.r.t. N_1 and N_2 such that
%           I_1_f = H_11_f*V_1_f + H_12_f*I_2_f
%           V_2_f = H_21_f*V_1_f + H_22_f*I_2_f

import Harmonics.Grid.*;

if(~isa(idx_1,'numeric'))
    error('idx_1: type.');
elseif(~isa(idx_2,'numeric'))
    error('idx_2: type.');
elseif(~isa(f,'numeric'))
    error('f: type.');
elseif(~isempty(intersect(idx_1,idx_2)))
    error('idx_{1,2} are not disjoint.');
% elseif(~isempty(setdiff(union(idx_1,idx_2),{obj.nodes.name})))
%     error('idx_{1,2} are not complete.');
else
    n_nodes = length([idx_1,idx_2]);
    n_phases = obj.getNumberOfWires();
    n_frequencies = length(f);
    
    Y_f = mat2cell(Y_f,n_phases*ones(n_nodes,1),n_phases*ones(n_nodes,1),n_frequencies);

    Y_11_f = cell2mat(Y_f(idx_1,idx_1,:));
    Y_12_f = cell2mat(Y_f(idx_1,idx_2,:));
    Y_21_f = cell2mat(Y_f(idx_2,idx_1,:));
    Y_22_f = cell2mat(Y_f(idx_2,idx_2,:));
    
    H_11_f = zeros([size(Y_11_f),size(Y_11_f,3)]);
    H_12_f = zeros([size(Y_12_f),size(Y_12_f,3)]);
    H_21_f = zeros([size(Y_21_f),size(Y_21_f,3)]);
    H_22_f = zeros([size(Y_22_f),size(Y_22_f,3)]);
    
%     warning('No frequency coupling in grid (inefficient storage)');
    for k=1:length(f)
        H_11_f(:,:,k,k) = inv(Y_11_f(:,:,k));
        H_12_f(:,:,k,k) = -H_11_f(:,:,k,k)*Y_12_f(:,:,k);
        H_21_f(:,:,k,k) = Y_21_f(:,:,k)*H_11_f(:,:,k,k);
        H_22_f(:,:,k,k) = Y_22_f(:,:,k) - Y_21_f(:,:,k)*H_11_f(:,:,k,k)*Y_12_f(:,:,k);
    end
end

end