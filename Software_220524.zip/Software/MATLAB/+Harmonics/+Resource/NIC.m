classdef NIC < matlab.mixin.Heterogeneous
    % NIC is a Network-Interfacing Converter (NIC).
    
    properties(SetAccess=private)
        node_AC
        node_DC
        power_hardware;
        control_software;
        internal_transform;
        external_transform;
    end
    
    methods
        function obj = NIC(node_AC,node_DC,power_hardware,control_software,internal_transform,external_transform)
            % obj = NIC(node,power_hardware,control_software,transform)
            
            import Harmonics.Converter.*;
            import Harmonics.Resource.*;
            
            if(~isa(node_AC,'char'))
                error('node: type.');
            elseif(~isa(node_DC,'char'))
                error('node: type.');
            elseif(~isa(power_hardware,'LTP_System'))
                error('power_hardware: type.');
            elseif(~isa(control_software,'LTP_System'))
                error('control_software: type.');
            elseif(~isa(internal_transform,'LTP_Transform'))
                error('internal_transform: type.');
            elseif(~isa(external_transform,'LTP_Transform'))
                error('external_transform: type.');
            else
                obj.node_AC = node_AC;
                obj.node_DC = node_DC;
                obj.power_hardware = power_hardware;
                obj.control_software = control_software;
                obj.internal_transform = internal_transform;
                obj.external_transform = external_transform;
            end
        end
    end
    
    methods(Abstract)
        n_stages = getNumberOfStages(obj);
        l_operating = getLengthOfOperatingPoint(obj);
        
        % HPF
        outputs = calculateGridResponse(obj,inputs);
        outputs = calculateExternalTransform(obj,inputs);
        outputs = calculateInternalTransform(obj,inputs);
        outputs = calculateReference(obj,inputs);
        outputs = calculateInternalGain(obj,inputs);
        outputs = calculateInternalResponse(obj,inputs);
        
        % TDS
        outputs = runTimeDomainSimulation(obj,inputs);
        outputs = initializeTimeDomainSimulation(obj,inputs);
    end
    
    methods(Abstract,Static)
        outputs = buildFromFile(inputs);
        outputs = buildPowerHardware(inputs);
        outputs = buildControlSoftware(inputs);
        outputs = buildInternalTransform(inputs);
        outputs = buildExternalTransform(inputs);
    end
end