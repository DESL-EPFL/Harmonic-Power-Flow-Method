classdef PWM_L_PI_PQ < Harmonics.Resource.CIR_I
    %   PWM_L_PI_PQ represents a converter-interfaced resource
    %   which consists of the following components:
    %   -   actuator: pulse-widh modulator (PWM)
    %   -   filter: inductor (L)
    %   -   controller: proportional-integral (PI) cascade
    %   -   reference: active/reactive power (PQ)
    
    properties(SetAccess=private)
        L_stage;   % Actuator-side inductive stage.
    end
    
    properties
        P_reference;
        Q_reference;
    end
    
    methods
        function obj = PWM_L_PI_PQ(node,index,L_stage,f_nominal,P_reference,Q_reference,base)
            % obj = PWM_LCL_PI_PQ(node,L_stage,f_nominal,P_reference,Q_reference)
            
            import Harmonics.Resource.*;
            
            control_software = PWM_L_PI_PQ.buildControlSoftware(L_stage,f_nominal,base);
            
            power_hardware = PWM_L_PI_PQ.buildPowerHardware(L_stage,f_nominal,base);
            
            internal_transform = PWM_L_PI_PQ.buildInternalTransform();
            external_transform = PWM_L_PI_PQ.buildExternalTransform();
            
            obj = obj@Harmonics.Resource.CIR_I(node,index,power_hardware,control_software,internal_transform,external_transform);
            
            obj.L_stage = L_stage;
            
            if(~isa(P_reference,'numeric'))
                error('P_reference: type.');
            elseif(~isa(Q_reference,'numeric'))
                error('Q_reference: type.');
            elseif(~all(size(P_reference)==1))
                error('P_reference: size.');
            elseif(~all(size(Q_reference)==1))
                error('Q_reference: size.');
            else
                obj.P_reference = P_reference;
                obj.Q_reference = Q_reference;
            end
        end
        
        function n_stages = getNumberOfStages(obj)
            % n_stages = getNumberOfStages(obj)
            n_stages = 1; % L
        end
        
        function l_operating = getLengthOfOperatingPoint(obj)
            % l_operating = getLengthOfOperatingPoint(obj)
            l_operating = 0;
        end
        
        % Implement abstract methods
        
        [Ih,dIh_dVh,Oh] = calculateGridResponse(obj,Ts,f_1,h,Vh,Oh,base);
        [W_K,dW_KP] = calculateReference(obj,W_P,theta_0,h_max,base)
        [G_PP,G_PK,G_KP,G_KK] = calculateInternalGain(obj,theta_0,Ts,f_1,h_max);
        [VA_h,IA_h,VF_h,IG_h] = calculateInternalResponse(obj,Ts,f_1,h,VG_h,base);
        [T_PG,T_GP] = calculateExternalTransform(obj,h_max);
        [T_KP,T_PK] = calculateInternalTransform(obj,theta_0,Ts,f_1,h_max);
        
        [outSim] = runTimeDomainSimulation(obj,folder,modelName,converterName,variantName,h_max,Ts);
        initializeTimeDomainSimulation(obj,modelName,converterName,variantName);
    end
    
    methods(Static)
        % Implement abstract methods;
        
        resource = buildFromFile(file,base,f_nominal)
        power_hardware = buildPowerHardware(L_stage,f_1,base);
        control_software = buildControlSoftware(L_stage,f_1,base);
        
        function transform = buildInternalTransform()
            
            import Harmonics.Resource.*;
            
            transform = DQ_Transform();
        end
        
        function transform = buildExternalTransform()
            
            import Harmonics.Resource.*;
            
            transform = WyeWye_Connection('yes','no');
        end
    end
end
