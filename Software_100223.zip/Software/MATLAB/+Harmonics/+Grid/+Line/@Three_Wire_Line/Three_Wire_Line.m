classdef Three_Wire_Line < Harmonics.Grid.Line.Line
    properties(SetAccess=private)
        R_pn;
        R_0;
        L_pn;
        L_0;
        C_pn;
        C_0;
    end
    
    methods
        function obj = Three_Wire_Line(name,node_from,node_to,R_pn,R_0,L_pn,L_0,C_pn,C_0,length)
            % obj = Line(name,node_from,node_to,R_pn,R_0,L_pn,L_0,C_pn,C_0)
            import Harmonics.Grid.Line.*;
            
            obj = obj@Harmonics.Grid.Line.Line(name,node_from,node_to,length);

            if(~isa(R_pn,'numeric'))
                error('R_pn: type.');
            elseif(~isa(R_0,'numeric'))
                error('R_0: type.');
            elseif(~isa(L_pn,'numeric'))
                error('L_pn: type.');
            elseif(~isa(L_0,'numeric'))
                error('L_0: type.');
            elseif(~isa(C_pn,'numeric'))
                error('C_pn: type.');
            elseif(~isa(C_0,'numeric'))
                error('C_0: type.');
            else
                obj.R_pn = R_pn;
                obj.R_0 = R_0;
                obj.L_pn = L_pn;
                obj.L_0 = L_0;
                obj.C_pn = C_pn;
                obj.C_0 = C_0;
            end
        end
        
        initializeTimeDomainSimulation(obj,modelName,converterName);
    end
    
    methods(Static)
        [found,indices] = findByName(lines,names);
        [R,L,G,C] = buildPiSectionEquivalent(lines,n_phases,n_lines,base);
    end
end