function control_software = buildControlSoftware(LA_stage,CF_stage,LG_stage,CD_stage,f_1,base)
% control_software = buildControlSoftware(LA_stage,C_stage,LG_stage,f_1)

import Harmonics.Resource.*;

if(~isa(LA_stage,'PI_Loop_L'))
    error('LA_stage: type.'),
elseif(~isa(CF_stage,'PI_Loop_C'))
    error('CF_stage: type.');
elseif(~isa(LG_stage,'PI_Loop_L'))
    error('LG_stage: type.');
elseif(~isa(CD_stage,'PI_Loop_C'))
    error('CD_stage: type.');
elseif(~isa(f_1,'numeric'))
    error('f_1: type.');
else
    h = 0;
    
    [KA_FT,KA_FF,KA_FB,TA_FB] = LA_stage.buildSoftwareModel(f_1,base);
    [KF_FT,KF_FF,KF_FB,TF_FB] = CF_stage.buildSoftwareModel(f_1,base);
    [KG_FT,KG_FF,KG_FB,TG_FB] = LG_stage.buildSoftwareModel(f_1,base);
    [KD_FT,KD_FF,KD_FB,TD_FB] = CD_stage.buildSoftwareModel(f_1,base);
    
    Z22 = zeros(2,2); % Zero matrix (w.r.t. DQ frame).
    Z12 = zeros(1,2);
    Z21 = zeros(2,1);
    e1 = [1;0];
    e2 = [0;1];
    I = eye(2); % Identity matrix (w.r.t. DQ frame).
    
    KA_FFB = KA_FF+KA_FB;
    KF_FFB = KF_FF+KF_FB;
    KG_FFB = KG_FF+KG_FB;
    KD_FFB = KD_FF+KD_FB;
    
    A_h = [Z22,KF_FB/TF_FB,KF_FFB*KG_FB/TG_FB,KF_FFB*KG_FFB*e1*KD_FB/TD_FB;...
           Z22,Z22,KG_FB/TG_FB,KG_FFB*e1*KD_FB/TD_FB;...
           Z12,Z12,Z12,KD_FB/TD_FB;...
           Z12,Z12,Z12,0;...
           Z12,Z12,Z12,0];
    B_h = [-I,-KF_FB,KF_FT-KF_FFB*KG_FB,-KF_FFB*KG_FFB*e1*KD_FB,KF_FFB*KG_FT,KF_FFB*KG_FFB*e1*KD_FT;...
           Z22,-I,-KG_FB,-KG_FFB*e1*KD_FB,KG_FT,KG_FFB*e1*KD_FT;...
           Z12,Z12,-e1.',-KD_FB,Z12,KD_FT;...
           Z12,Z12,-e2.',0,Z12,0;...
           Z12,Z12,Z12,-1,Z12,0];
    E_h = [KF_FFB*KG_FFB*e2,KF_FFB*KG_FFB*e1*KD_FFB;...
           KG_FFB*e2,KG_FFB*e1*KD_FFB;...
           0,KD_FFB;...
           1,0;...
           0,1];
    
    C_h = [KA_FB/TA_FB,KA_FFB*KF_FB/TF_FB,KA_FFB*KF_FFB*KG_FB/TG_FB,KA_FFB*KF_FFB*KG_FFB*e1*KD_FB/TD_FB];
    D_h = [-KA_FB,KA_FT-KA_FFB*KF_FB,KA_FFB*(KF_FT-KF_FFB*KG_FB),-KA_FFB*KF_FFB*KG_FFB*e1*KD_FB,KA_FFB*KF_FFB*KG_FT,KA_FFB*KF_FFB*KG_FFB*e1*KD_FT];
    F_h = [KA_FFB*KF_FFB*KG_FFB*e2,KA_FFB*KF_FFB*KG_FFB*e1*KD_FFB];
    
    control_software = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h);
end

end