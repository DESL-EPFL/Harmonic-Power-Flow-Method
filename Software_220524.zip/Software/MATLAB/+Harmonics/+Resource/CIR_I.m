classdef CIR_I < Harmonics.Resource.CIR 
    % CIR_I is a grid-following Converter-Interfaced Resource (CIR).
    
    properties
        %
    end
    
    methods
        function obj = CIR_I(node,index,power_hardware,control_software,internal_transform,external_transform)
            % obj = CIR_I(node,power_hardware,control_software,transform)
            
            import Harmonics.Resource.*;
            
            obj = obj@Harmonics.Resource.CIR(node,index,power_hardware,control_software,internal_transform,external_transform);

        end
    end
    
    methods(Abstract)
        %
    end
    
    methods(Abstract,Static)
        %
    end
end