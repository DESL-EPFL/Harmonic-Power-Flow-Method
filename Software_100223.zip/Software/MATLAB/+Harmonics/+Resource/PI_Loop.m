classdef PI_Loop
    % PI_Loop represents a control loop (hardware + software)
    % based on Proportional-Integral (PI) laws.
    % More precisely, the loop consists of a feed-through controller (P),
    % a feed-forward controller (P), and a feed-back controller (PI).
    % The hardware is modeled in ABC and the software in DQ coordinates.
    % The feed-forward gain is calculated from the hardware parameters.
    
    properties(SetAccess=private)
        dim_ph; % Dimension of the filter power hardware (e.g., 3ph, dc).
        dim_cs; % Dimension of the filter control software (e.g., dq)
        K_FT;   % Proportional gain of the feed-through controller.
        K_FB;   % Proportional gain of the feed-back controller.
        T_FB;   % Integration time of the feedb-back controller.
    end
    
    methods
        function obj = PI_Loop(dim_ph,dim_cs,K_FT,K_FB,T_FB)
            % obj = PI_Loop(K_FT,K_FB,T_FB)
            
            % Check type
            if(~isa(K_FT,'numeric'))
                error('K_FT: type.');
            elseif(~isa(K_FB,'numeric'))
                error('KF_FB: type.');
            elseif(~isa(T_FB,'numeric'))
                error('T_FB: type.');
            else
                % Check size
                if(length(K_FT)~=1)
                    error('K_FT: size.');
                elseif(length(K_FB)~=1)
                    error('K_FB: size.');
                elseif(length(T_FB)~=1)
                    error('T_FB: size.');
                else
                    % Construct object
                    
                    obj.dim_ph = dim_ph;
                    obj.dim_cs = dim_cs;
                    
                    obj.K_FT = K_FT;
                    obj.K_FB = K_FB;
                    obj.T_FB = T_FB;
                end
            end
        end
    end
    
    methods(Abstract)
        outputs = buildHardwareModel(obj,inputs);
        outputs = buildSoftwareModel(obj,inputs);
    end
    
    methods(Static,Abstract)
        outputs = buildFromFile(inputs);
    end
end