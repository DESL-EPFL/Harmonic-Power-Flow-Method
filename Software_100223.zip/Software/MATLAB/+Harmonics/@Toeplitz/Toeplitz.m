classdef Toeplitz
    methods(Static)
        M = buildSquareMatrix(h,M_h,h_max);
        M = buildRectangularMatrix(h,M_h,h_max_row,h_max_col);
    end
end