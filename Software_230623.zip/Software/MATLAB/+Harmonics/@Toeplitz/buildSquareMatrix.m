function M = buildSquareMatrix(h,M_h,h_max)
% M = buildSquareMatrix(h,M_h,h_max)
%
% INPUT
%   h       Harmonic orders h>=0 (M_{-h} = conj(M_h));
%   M_h     Fourier coefficients of a time-periodic matrix M(t).
%   h_max   Maximum harmonic order of interest.

% warning('migrate to Fourier.');

n_coeffs = 2*h_max+1;
[n_rows,n_cols] = size(M_h(:,:,1));

M = repmat({zeros(n_rows,n_cols)},n_coeffs,n_coeffs);

for i=1:length(h)
    h_i = h(i);
    M_h_i = M_h(:,:,i);
    
    if(h_i<=h_max)
        % Toeplitz matrix: row-col=h
        
        rows = (h_i+1):n_coeffs;
        cols = rows-h_i;
        
        for j=1:length(rows)
            % Below main diagonal: h>0
            M{rows(j),cols(j)} = M_h_i;
            
            % Above main diagonal: h<0
            M{cols(j),rows(j)} = conj(M_h_i);
        end
    else
        break;
    end
end

M = cell2mat(M);

end