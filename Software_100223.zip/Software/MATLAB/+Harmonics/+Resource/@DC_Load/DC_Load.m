classdef DC_Load
    properties(SetAccess=private)
        node;
        index;
    end
    
    properties
        P_reference;
    end
    
    methods
        function obj = DC_Load(node,index,P_reference)
            % obj = DC_Load(node,P_reference)
            import Harmonics.Resource.*;
            
            if(~isa(node,'char'))
                error('node: type.');
            elseif(~isa(index,'numeric'))
                error('index:type.')
            elseif(~isa(P_reference,'numeric'))
                error('P_reference: type.');
            else
            
                obj.node = node;
                obj.index = index;
                obj.P_reference = P_reference;
            end
        end
        
        I_h = calculateResponse(obj,f_1,h_max,V_h,base);
        [Ih,dIh_dVh] = calculateGridResponse(obj,f_1,h_max,V_h,base);
        
        [outSim] = runTimeDomainSimulation(obj,folder,modelName,converterName,variantName,h_max,Ts)
        [] = initializeTimeDomainSimulation(obj,modelName,converterName,variantName);
    end
    
    methods(Static)
        load = buildFromFile(file,number_of_wires,base,f_1);
    end
end

