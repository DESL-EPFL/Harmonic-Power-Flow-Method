function X_h_0 = initializeHarmonicPowerFlow(X_h_0,n_phases,h_set,percentage,h_max)

angles = [0 -2*pi/3 +2*pi/3; 0 +2*pi/3 -2*pi/3; 1 1 1]; %pos,neg,hom seq

% flat start in fundamental component
amplitude = zeros(size(X_h_0));
amplitude(:,2) = 0.5;%rand;
dX_h_0 = amplitude.*repmat(exp(1i*angles(1,:)'),size(X_h_0,1)/n_phases,h_max+1);

for j = 1:3
    % add random positive/negative/homopolar sequences
    phase     = zeros(size(X_h_0));
    amplitude = zeros(size(X_h_0));
    for k = 1:size(X_h_0,1)/n_phases
        for h = h_set
            amplitude((1:n_phases)+(k-1)*n_phases,h+1) = repmat(percentage(h_set==h)/100*0.5*rand(1,1),n_phases,1);
            phase((1:n_phases)+(k-1)*n_phases,h+1) = repmat(exp(1i*2*pi*rand(1,1)),n_phases,1);
        end
    end
    base = repmat(exp(1i*angles(j,:)'),size(X_h_0,1)/n_phases,h_max+1);
    dX_h_0 = dX_h_0 + amplitude .* phase .* base; 
end

X_h_0 = X_h_0 + dX_h_0;

end