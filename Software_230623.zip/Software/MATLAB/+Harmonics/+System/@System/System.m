classdef System
    % SYSTEM Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        subsystems;
        interfacing_converters;
    end
    
    methods
        function obj = System(subsystems,interfacing_converters)
            % obj = System(subsystems,interfacing_converters)
            
            import Harmonics.*;
            import Harmonics.Grid.*;
            import Harmonics.Resource.*;
            import Harmonics.System.*;
            
            if(~isa(subsystems,'Subsystem'))
                error('subsystems: type.');
            elseif(~isa(interfacing_converters,'NIC'))
                error('interfacing_converters: type.');
            else
                obj.subsystems = subsystems;
                obj.interfacing_converters = interfacing_converters;
            end
        end

        function nodes = getInteracingConvertersNode(obj)
            
            import Harmonics.*;
            import Harmonics.Grid.*;
            import Harmonics.System.*;
            
            for j = 1:length(obj.subsystems)
                if isa(obj.subsystems(j),'AC_Subsystem')
                    N_AC = {obj.interfacing_converters.node_AC};
                    [found_AC,nodes{j}] = Node.findByName(obj.subsystems(j).grid.nodes,N_AC);
                    if(~all(found_AC))
                        error('AC_node.');
                    end
                else
                    N_DC = {obj.interfacing_converters.node_DC};
                    [found_DC,nodes{j}] = Node.findByName(obj.subsystems(j).grid.nodes,N_DC);
                    if(~all(found_DC))
                        error('DC_node.');
                    end
                end
            end

        end
        
        % HPF
        [V_h,I_h,n_iter] = solveNewtonRaphson(obj,Ts,f_1,h_max,V_h_0,I_h_0,O_V_h_0,O_I_h_0,base,options);

        % TDS
        [t_exec,t_proc,simOut] = runTimeDomainSimulation(obj,modelName,gridName,h_max,Ts);

    end
end