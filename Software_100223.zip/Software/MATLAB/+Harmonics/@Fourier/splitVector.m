function [h,X_h] = splitVector(X,n_x)
% [h,X_h] = splitVector(X,n_x)
%
% INPUT
%   X       Fourier spectrum (column vector).
%   n_x     Number of state variables (i.e., elements of x(t)).
%
% OUTPUT
%   h       Harmonic orders h>=0 (column vector).
%   X_h     Fourier coefficients (rows=variables, columns=harmonics).

if(~isa(X,'numeric'))
    error('X: type.');
elseif(~isa(n_x,'numeric'))
    error('n_x: type.');
else
    if(size(X,2)~=1)
        error('X: size.');
    elseif(size(n_x)~=1)
        error('n_x: size.');
    else
        n_h = (size(X,1)/n_x-1)/2;
        
        if(mod(n_h,1)~=0)
            error('X: number of variables/harmonics.');
        else
            X_h = reshape(X,n_x,2*n_h+1);
            
            dX_h = X_h - conj(flip(X_h,2));
            
            e_max = abs(max(max(dX_h)));
            if(e_max>1e-10)
                warning(['Fourier spectrum: symmetry violation - ' num2str(e_max) '.']);
            end
            
            % Negative spectrum ignored (assuming conjugate symmetry)
%             warning('Negative spectrum ignored.');
            X_h = X_h(:,n_h+1:end);
        end
        
        h = transpose(0:1:n_h);
    end
end

end