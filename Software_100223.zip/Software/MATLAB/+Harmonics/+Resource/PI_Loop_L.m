classdef PI_Loop_L < Harmonics.Resource.PI_Loop
    % PI_Loop_L represents a control loop for an inductive filter stage.
    
    properties(SetAccess=private)
        R;  % Resistance of the inductor.
        L;  % Inductance of the inductor.
    end
    
    methods
        function obj = PI_Loop_L(R,L,dim_ph,dim_cs,K_FT,K_FB,T_FB)
            % obj = PI_Loop_L(R,L,K_FT,K_FB,T_FB)
            
            obj = obj@Harmonics.Resource.PI_Loop(dim_ph,dim_cs,K_FT,K_FB,T_FB);
            
            % Check type
            if(~isa(R,'numeric'))
                error('R: type.');
            elseif(~isa(L,'numeric'))
                error('L: type.');
            else
                % Check size
                if(length(R)~=1)
                    error('R: size.');
                elseif(length(R)~=1)
                    error('L: size.');
                else
                    % Construct object
                    
                    obj.R = R;
                    obj.L = L;
                end
            end
        end
        
        % Implement abstract methods
        
        function [R,L] = buildHardwareModel(obj,f_1,base)
            % [R,L] = buildHardwareModel(obj)
            %
            % OUTPUT
            %   R/L     Resistance/inductance matrix (ABC coordinates).
            
            Z_base = base.getBaseImpedance();
            
            R = obj.R * eye(obj.dim_ph);% + 2*pi*f_1*obj.L * [0,-1;1,0];
            L = obj.L * eye(obj.dim_ph);
            
            R = R/Z_base;
            L = L/Z_base;
        end
        
        function [K_FT,K_FF,K_FB,T_FB] = buildSoftwareModel(obj,f_1,base)
            % [K_FT,K_FF,K_FB,T_FB] = buildSoftwareModel(obj,f_1)
            %
            % INPUT
            %   f_1             Fundamental frequency.
            %
            % OUTPUT
            %   K_{FT/FF/FB}    Gain matrices (DQ coordinates).
            %   T_FB            Feed-back integration time.
            
            Z_base = base.getBaseImpedance();
                
            K_FT = obj.K_FT * eye(obj.dim_cs);
            K_FF = obj.R * eye(obj.dim_cs);
            if obj.dim_cs == 2
                K_FF = K_FF + 2*pi*f_1*obj.L * [0,-1;1,0];
            end
            K_FB = obj.K_FB * eye(obj.dim_cs);
            T_FB = obj.T_FB;
            
            K_FF = K_FF/Z_base;
            K_FB = K_FB/Z_base;
        end
    end
    
    methods(Static)
        function stage = buildFromFile(file,sheet,base)
            % stage = buildFromFile(file,sheet,base)
            
            import Harmonics.*;
            import Harmonics.Resource.*;
            
            if(~isa(file,'char'))
                error('file: type.');
            elseif(~isa(sheet,'char'))
                error('sheet: type.');
            elseif(~isa(base,'Base'))
                error('base: type.');
            else
                [numeric,text,raw] = xlsread(file,sheet);
                
                Z_base = base.getBaseImpedance();
                
                L = numeric(1);%/Z_base;
                R = numeric(2);%/Z_base;
                K_FB = numeric(3);%/Z_base;
                T_FB = numeric(4);
                K_FT = numeric(5);
                dim_ph = numeric(6);
                dim_cs = numeric(7);
                
                stage = PI_Loop_L(R,L,dim_ph,dim_cs,K_FT,K_FB,T_FB);
            end
        end
    end
end