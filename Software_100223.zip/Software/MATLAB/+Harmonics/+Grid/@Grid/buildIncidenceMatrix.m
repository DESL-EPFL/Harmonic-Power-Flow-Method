function A = buildIncidenceMatrix(obj)
% A = buildIncidenceMatrix(obj)

import Harmonics.Grid.*;

n_nodes = obj.getNumberOfNodes();
n_lines = obj.getNumberOfLines();

A = zeros(n_lines,n_nodes);

[found_from,index_from] = Node.findByName(obj.nodes,{obj.lines.node_from});
[found_to,index_to] = Node.findByName(obj.nodes,{obj.lines.node_to});

if(~all(found_from))
    error('lines: invalid start nodes.');
elseif(~all(found_to))
    error('lines: invalid end nodes.');
else
    for i=1:n_lines
        A(i,index_from(i)) = +1;
        A(i,index_to(i)) = -1;
    end
end

end