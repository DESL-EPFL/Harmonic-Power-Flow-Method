function [e] = errorCalculation(X1,X2,type,tol)
%ERRORCALCULATION Summary of this function goes here
%   Detailed explanation goes here


if strcmp(type,'abs')
    % Factor 2 because of Fourier coefficients (positive/negative spectrum).
    X_abs_1 = 2*abs(X1);
    X_abs_2 = 2*abs(X2);
    [e,ind] = max(abs(X_abs_2-X_abs_1),[],1);
elseif strcmp(type,'arg')
%     tol = 1e-6;%0.001;
    X_arg_1 = angle(X1)*180/pi;
    X_arg_2 = angle(X2)*180/pi;
    e = abs(X_arg_2-X_arg_1);
%     e(abs(X1)<tol) = 0;
%     e(1:2:end) = 0; % small values
    [e,ind] = max(e,[],1);
elseif strcmp(type,'tve')
    TVE = abs(X2-X1)./abs(X1);
    TVE(abs(X2)<tol) = 0;    
    e = max(TVE)*100;
%     e(1:2:end) = 0;
%     e(1:3:end) = 0;
elseif strcmp(type,'abs_perc')
%     tol = 0.005;
    X_abs = (abs(X2)-abs(X1))./abs(X1);
    X_abs(abs(X1)<tol*abs(X1(:,2))) = 0;
    e = abs(X_abs)*100;
%     e(1:2:end) = 0;
%     e(1:3:end) = 0;
end

end

