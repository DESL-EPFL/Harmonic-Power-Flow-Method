classdef I_Source
    %I_SOURCE Summary of this class goes here
    %   Detailed explanation goes here
    
    properties(SetAccess=private)
        node;
        index;
    end
    
    properties
        I_reference;
    end
    
    methods
        function obj = I_Source(node,index,I_reference)
            %I_SOURCE Construct an instance of this class
            %   Detailed explanation goes here
            import Harmonics.Resource.*;
            
            if(~isa(node,'char'))
                error('node: type.');
            elseif(~isa(index,'numeric'))
                error('index:type.')
            elseif(~isa(I_reference,'numeric'))
                error('I_reference: type.');
            else
            
                obj.node = node;
                obj.index = index;
                obj.I_reference = I_reference;
            end
        end
        
        [Ih,dIh_dVh] = calculateGridResponse(obj,f_1,h_max,V_h,base);
        [] = initializeTimeDomainSimulation(obj,modelName,converterName)
    end

    methods(Static)
        load = buildFromFile(file,base,f_1);
    end
end

