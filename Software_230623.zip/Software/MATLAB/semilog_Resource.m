function [h_abs,max_abs,h_arg,max_arg]  = semilog_Resource(X_h_1,X_h_2,idx,h,h_max,quantityStr,phaseStr,subScript,fileStr,fig)

% set color scheme
color_1 = 'k';%'g';%
color_2 = 0.7*[1,1,1];%'b';%
color_e = 0.7*[1,1,1]; % color for error

figure(fig);
clf;
set(groot,'defaultAxesTickLabelInterpreter','latex');  

if strcmp(phaseStr,'A')||strcmp(phaseStr,'DC')
    phase = 1;
elseif strcmp(phaseStr,'B')
    phase = 2;
elseif strcmp(phaseStr,'C')
    phase = 3;
end

x = 0:h_max;

% Magnitude - Absolut Values and Error
% Factor 2 because of Fourier coefficients (positive/negative spectrum).
X_abs_1 = abs(X_h_1(idx,:));
X_abs_1(:,2:end) = 2*X_abs_1(:,2:end);

X_abs_2 = abs(X_h_2(idx,:));
X_abs_2(:,2:end) = 2*X_abs_2(:,2:end);

y_abs = [X_abs_1(phase,:);X_abs_2(phase,:)]; % show one phase only
e_abs = max(abs(X_abs_2-X_abs_1),[],1);
[max_abs,h_abs] = max(e_abs);
h_abs = h_abs-1;

for i = 1:2
    h_plot(i) = subplot(2,2,i);
    
    if i == 1
        h_plot(i).Position = h_plot(i).Position + [-0.03 0.01 0.13 0];
        
        b = bar(x',y_abs','LineWidth',0.01);
        b(1).FaceColor = color_1;
        b(2).FaceColor = color_2;
    else
        h_plot(i).Position = h_plot(i).Position + [0.11 0.01 -0.03 -0.01];
        
        bar(x,e_abs','FaceColor',color_e,'LineWidth',0.01);
    end
    ax = gca;
    grid(gca,'on');
    set(gca, 'YScale', 'log');
    ax.MinorGridAlpha = 0.1;

    xlim([-0.5,h_max+0.5]);
    ylim([1e-18,1e1]);
    set(gca,'XTick',[1:4:h_max]);
    set(gca,'YTick',10.^[-15:5:0]);
    yticklabels({'1E-15','1E-10','1E-5','1E+0'})
    xtickangle(0)

    if i == 1
        legend({'TDS','HPF'},'interpreter','latex','location','southwest');
        if strcmp(phaseStr,'DC')
            title(['$|',quantityStr,'_{',subScript,',h}|$ (p.u.)'],'interpreter','latex');
        else
            title(['$|',quantityStr,'_{',subScript,',',phaseStr,',h}|$ (p.u.)'],'interpreter','latex');
        end
    else
        title(['$e_{\textup{abs}}(',quantityStr,'_{',subScript,',h})$ (p.u.)'],'interpreter','latex');
    end
end   

% Angle - Absolut Values and Error

X_arg_1 = angle(X_h_1(idx,:))*180/pi;
X_arg_2 = angle(X_h_2(idx,:))*180/pi;

y_arg = [X_arg_1(phase,:);X_arg_2(phase,:)]; % show one phase only
y_arg(:,setdiff([0:h_max],h)'+1) = 0;

y_arg = y_arg*pi/180; % convert to rad

e_arg = max(abs(X_arg_2-X_arg_1),[],1);
e_arg(setdiff([0:h_max],h)'+1) = 0;
e_arg(e_arg>180) = 360 - e_arg(e_arg>180);

e_arg = e_arg*pi/180*1e3; % convert to mrad

[max_arg,h_arg] = max(e_arg);
h_arg = h_arg-1;

for i = 1:2
    h_plot(2+i) = subplot(2,2,2+i);
    
    if i == 1
        h_plot(2+i).Position = h_plot(2+i).Position + [-0.03 0.01 0.13 -0.01];
    
        b = bar(x',y_arg','LineWidth',0.01);
        b(1).FaceColor = color_1;
        b(2).FaceColor = color_2;
        axis([-0.5,h_max+0.5,-pi-0.1,pi+0.1]);
        set(gca,'YTick',-pi:pi/2:pi);
        yticklabels({'$-\pi$','$-\frac{\pi}{2}$','$0$','$\frac{\pi}{2}$','$\pi$'})
    else
        h_plot(2+i).Position = h_plot(2+i).Position + [0.11 0.01 -0.03 -0.01];
    
        bar(x,e_arg','FaceColor',color_e,'LineWidth',0.01);
        ax = gca;
        grid(gca,'on');
        set(gca, 'YScale', 'log');
        ax.MinorGridAlpha = 0.1;
        xlim([-0.5,h_max+0.5]);
        ylim([1e-3,3e1]);
        set(gca,'YTick',10.^[-3:1:1]);
        yticklabels({'1E-3','1E-2','1E-1','1E+0','1E+1'})
    end
    set(gca,'XTick',[1:4:h_max]);
    grid(gca,'on');    
    xtickangle(0)
       
    if i == 1
        if strcmp(phaseStr,'DC')
            title(['$\angle ',quantityStr,'_{',subScript,',h}$ (rad)'],'interpreter','latex');
        else
            title(['$\angle ',quantityStr,'_{',subScript,',',phaseStr,',h}$ (rad)'],'interpreter','latex');
        end
    else
        title(['$e_{\textup{arg}}(',quantityStr,'_{',subScript,',h})$ (mrad)'],'interpreter','latex');
    end
    xlabel('Harmonic Order (h)','interpreter','latex');

end   

set(gcf,'PaperUnits','points');
set(gcf,'PaperSize',[350,240]);
set(gcf,'PaperPosition',[0,0,350,240]);

saveas(gcf,fileStr,'pdf');

end