function results = timing(t_HPF,n_HPF,t_TDS_exc,t_TDS_prc,time,f_nominal)

n_period = time.Tend*f_nominal;
t_prd = t_TDS_exc/n_period;

t_TDS_sim = 5*t_prd;
t_TDS = t_TDS_sim + t_TDS_prc;

t_exc = [t_TDS_sim;0];
t_prc = [t_TDS_prc;0];
t_tot = [t_TDS;t_HPF];
n_iter = [0;n_HPF];

data = [["TDS";"HPF"],t_exc,t_prc,t_tot,n_iter];
names = {'model','t_exc','t_prc','t_tot','n_itr'};
results = table(data(:,1),data(:,2),data(:,3),data(:,4),data(:,5),'VariableNames',names);

display(results)

end