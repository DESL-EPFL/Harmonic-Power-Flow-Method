function [h,M_h] = splitMatrix(M,n_y,n_x)
% [h,M_h] = splitMatrix(M,n_x)
%
% INPUT
%   M       Matrix in Fourier spectrum Y = M*X.
%   n_y     Number of output variables (i.e., elements of y(t)).
%   n_x     Number of state variables (i.e., elements of x(t)).
%
% OUTPUT
%   h       Harmonic orders h>=0 (column vector).
%   M_h     Matrix of Fourier coefficients (rows=output-variables,
%           columns=state-variables, 3th and 4th dimesion harmonic
%           couplings).

if(~isa(M,'numeric'))
    error('M: type.');
elseif(~isa(n_y,'numeric'))
    error('n_y: type.');
elseif(~isa(n_x,'numeric'))
    error('n_x: type.');
else
    if(size(n_y)~=1)
        error('n_y: size.');
    elseif(size(n_x)~=1)
        error('n_x: size.');
    else
        n_hy = (size(M,1)/n_y-1)/2;
        n_hx = (size(M,2)/n_x-1)/2;
        
        if(mod(n_hy,1)~=0)
            error('M: number of output-variables/harmonics.');
        elseif(mod(n_hx,1)~=0)
            error('M: number of state-variables/harmonics.');
        else
            M = mat2cell(M,n_y*ones(1,2*n_hy+1),n_x*ones(1,2*n_hx+1));
            
            for i = 1:2*n_hy+1
                for j = 1:2*n_hx+1
                    M_h(:,:,i,j) = M{i,j};
                end
            end

            %warning('This test needs to be redone.');
            dM_h = M_h - conj(flip(M_h));
            
            e_max = abs(max(max(dM_h)));
            if(e_max>1e-10)
                warning(['Fourier spectrum: symmetry violation - ' num2str(e_max) '.']);
            end

            % Negative spectrum ignored (assuming conjugate symmetry)
            M_h = M_h(:,:,n_hy+1:end,n_hx+1:end);
        end
        
        h = 0:1:n_hx;
    end
end

end