classdef One_Wire_Line < Harmonics.Grid.Line.Line
    properties(SetAccess=private)
        R;
        L;
        C;
    end
    
    methods
        function obj = One_Wire_Line(name,node_from,node_to,R,L,C,length)
            % obj = One_Wire_Line(name,node_from,node_to,R,L,C,length)
            import Harmonics.Grid.Line.*;
            
            obj = obj@Harmonics.Grid.Line.Line(name,node_from,node_to,length);

            if(~isa(R,'numeric'))
                error('R: type.');
            elseif(~isa(L,'numeric'))
                error('L: type.');
            elseif(~isa(C,'numeric'))
                error('C: type.');
            else
                obj.R = R;
                obj.L = L;
                obj.C = C;
            end
        end
        
        initializeTimeDomainSimulation(obj,modelName,converterName);
    end
    
    methods(Static)
        [found,indices] = findByName(lines,names);
        [R,L,G,C] = buildPiSectionEquivalent(lines,n_phases,n_lines,base);
    end
end