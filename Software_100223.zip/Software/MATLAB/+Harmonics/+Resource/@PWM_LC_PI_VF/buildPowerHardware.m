function power_hardware = buildPowerHardware(L_stage,C_stage,f_1,base)
% power_hardware = buildPowerHardware(L_stage,C_stage)

import Harmonics.Resource.*;

if(~isa(L_stage,'PI_Loop_L'))
    error('L_stage: type.');
elseif(~isa(C_stage,'PI_Loop_C'))
    error('C_stage: type.');
else
    n_phases = 3;    
    
    [R,L] = L_stage.buildHardwareModel(f_1,base);
    [G,C] = C_stage.buildHardwareModel(f_1,base);
    
    h = 0;
    
    A_h = [-inv(L)*R,-inv(L);inv(C),-inv(C)*G];
    B_h = [inv(L);zeros(n_phases,n_phases)];
    E_h = [zeros(n_phases,n_phases);-inv(C)];
    
    C_h = [eye(2*n_phases);zeros(n_phases,2*n_phases)];
    D_h = zeros(3*n_phases,n_phases);
    F_h = [zeros(2*n_phases,n_phases);eye(n_phases)];
    
    power_hardware = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h);
end

end