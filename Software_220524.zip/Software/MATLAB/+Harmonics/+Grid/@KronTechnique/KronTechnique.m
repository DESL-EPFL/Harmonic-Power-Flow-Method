classdef KronTechnique
    %KRONTECHNIQUE Functionality for (inverse) Kron reduction.
    
    methods(Static)
        Y_kron = reduce(Y,N_kron,n_phases);
        V = reconstruct(Y,N_kron,V_kron,n_phases);
    end
end