function [] = initializeTimeDomainSimulation(obj,modelName,subsystemName)
% [] = initializeTimeDomainSimulation()
%
% INPUT
%   
% OUTPUT
%

import Harmonics.*

n_nodes = obj.grid.getNumberOfNodes;%n_following + n_forming + n_slack;

% Initialize Following resources
for r = 1 : length(obj.resources_following)
    obj.resources_following(r).initializeTimeDomainSimulation(modelName,[subsystemName,'.resources_following(',num2str(r),')'],'CIDER');
end
% Initialize Passive loads
for r = 1 : length(obj.passive_loads)
    obj.passive_loads(r).initializeTimeDomainSimulation(modelName,[subsystemName,'.passive_loads(',num2str(r),')'],'Passive');
end
% Initialize Forming resources
for r = 1 : length(obj.resources_forming)
    obj.resources_forming(r).initializeTimeDomainSimulation(modelName,[subsystemName,'.resources_forming(',num2str(r),')']);
end

% Initialize Lines
for l = 1 : obj.grid.getNumberOfLines
    obj.grid.lines(l).initializeTimeDomainSimulation(modelName,[subsystemName,'.grid.lines(1,',num2str(l),')']);
end

end