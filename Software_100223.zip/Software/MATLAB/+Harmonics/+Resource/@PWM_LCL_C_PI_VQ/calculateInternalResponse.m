function [VAref_h,IA_h,VF_h,IG_h,VD_h] = calculateInternalResponse(obj,Ts,f_1,h,VG_h,IE_h,VAref_h,IA_h,VD_h,base)
% [VA_h,IA_h,VF_h,IG_h] = calculateInternalResponse(obj,f_1,h,VG_h,base)
% 
% INPUT
% - f_1         Fundamental frequency.
% - h           Harmonic orders (w.r.t. the fundamental frequency)
% - VG_h        Fourier coefficients of the grid voltage.
% - base        Per-unit base.
% 
% OUTPUT
% - VA_h        Fourier coefficients of the actuator voltage.
% - IA_h        Fourier coefficients of the actuator current.
% - VF_h        Fourier coefficients of the filter voltage.
% - IG_h        Fourier coefficients of the grid current.

import Harmonics.*;

h_max = max(h);
Vdc_ref = obj.Vdc_reference / base.getBaseVoltage();

%% Input

% init
h_d_AC = h';%1;%
i_d_AC = logical(sum(h==h_d_AC,2));
h_d_DC = h';%0;%
i_d_DC = logical(sum(h==h_d_DC,2));

VAref_d = zeros(size(VAref_h));
IA_d    = zeros(size(IA_h));
VD_d    = zeros(size(VD_h));

VAref_d(:,i_d_AC) = VAref_h(:,i_d_AC);
IA_d(:,i_d_AC)     = IA_h(:,i_d_AC);
VD_d(:,i_d_DC)     = VD_h(:,i_d_DC);

O_P_h = [VAref_d;IA_d;VD_d];

%% Disturbances

W_P_h_1 = VG_h;
W_P_h_2 = IE_h;
W_P_h_3 = VAref_d;

W_P_h = [W_P_h_1;W_P_h_2;W_P_h_3];
W_P = Fourier.buildVector(h,W_P_h);

%% Internal Response

[T_abc2pnz,~] = PNZ_Transform.build();
V1_ABC = VG_h(:,h==1);
V1_PNH = T_abc2pnz*V1_ABC;
theta0 = angle(V1_PNH(1));

[W_K,~] = calculateReference(obj,W_P,theta0,h_max,base);

[G_PP,G_PK,G_KP,G_KK] = obj.calculateInternalGain(O_P_h,theta0,Ts,f_1,h_max,base);

Y_P = G_PP * W_P + G_PK * W_K;
Y_K = G_KP * W_P + G_KK * W_K;

%% Assign Outputs

nK_1 = obj.LA_stage.dim_cs;
nP_1 = obj.LA_stage.dim_ph;
nP_2 = obj.CD_stage.dim_ph;

[~,Y_K_h] = Fourier.splitVector(Y_K,obj.control_software.getNumberOfOutputs);
VAref_h = Y_K_h(1:nK_1,:);

[~,Y_P_h] = Fourier.splitVector(Y_P,obj.power_hardware.getNumberOfOutputs);
IA_h = Y_P_h(1:nP_1,:);
VF_h = Y_P_h((1:nP_1)+nP_1,:);
IG_h = Y_P_h((1:nP_1)+2*nP_1,:);
VD_h = Y_P_h((1:nP_2)+3*nP_1,:);
VG_h = Y_P_h((1:nP_1)+3*nP_1+nP_2,:);
IE_h = Y_P_h((1:nP_2)+4*nP_1+nP_2,:);

end

