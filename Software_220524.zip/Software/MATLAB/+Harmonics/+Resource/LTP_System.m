classdef LTP_System
    % LTP_SYSTEM represents a Linear Time-Periodic (LTP) system
    % (i.e., w.r.t. the fundamental period T), which is described by
    %
    %   dx_dt(t) = A(t)x(t) + B(t)u(t) + E(t)w(t)
    %       y(t) = C(t)x(t) + D(t)u(t) + F(t)w(t)
    %
    % where
    %   x(t)    State vector, with derivative dx_dt(t).
    %   u(t)    Input vector (e.g., controls).
    %   y(t)    Output vector (e.g., measurements).
    %   w(t)    Disturbance vector (e.g., setpoints).
    %   A(t)    System matrix.
    %   B(t)    Input matrix.
    %   C(t)    Output matrix.
    %   D(t)    Feedthrough matrix.
    %   E(t)    Input disturbance matrix.
    %   F(t)    Output disturbance matrix.
    
    properties(SetAccess=private)
        h;      % Harmonic orders h>= 0 of interest (K_{-h}=conj(K_h)).
        A_h;    % Fourier coefficients of A(t) of orders h.
        B_h;    % Fourier coefficients of B(t) of orders h.
        C_h;    % Fourier coefficients of C(t) of orders h.
        D_h;    % Fourier coefficients of D(t) of orders h.
        E_h;    % Fourier coefficients of E(t) of orders h.
        F_h;    % Fourier coefficients of F(t) of orders h.
    end
    
    methods
        function obj = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h)
            % obj = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h)
            
            % Check data type
            if(~isa(h,'numeric'))
                error('h: type.');
            elseif(~isa(A_h,'numeric'))
                error('A_h: type.');
            elseif(~isa(B_h,'numeric'))
                error('B_h: type.');
            elseif(~isa(C_h,'numeric'))
                error('C_h: type.');
            elseif(~isa(D_h,'numeric'))
                error('D_h: type.');
            elseif(~isa(E_h,'numeric'))
                error('E_h: type.');
            elseif(~isa(F_h,'numeric'))
                error('F_h: type.');
            else
                % Check problem size
                
                n_h = size(h,1);
                n_x = size(A_h,1);
                n_u = size(B_h,2);
                n_y = size(C_h,1);
                n_w = size(E_h,2);
                
                if(~all(size(h)==[n_h,1]))
                    error('h: size.');
                elseif(~all([size(A_h,1),size(A_h,2),size(A_h,3)]==[n_x,n_x,n_h]))
                    error('A_h: size.');
                elseif(~all([size(B_h,1),size(B_h,2),size(B_h,3)]==[n_x,n_u,n_h]))
                    error('B_h: size.');
                elseif(~all([size(C_h,1),size(C_h,2),size(C_h,3)]==[n_y,n_x,n_h]))
                    error('C_h: size.');
                elseif(~all([size(D_h,1),size(D_h,2),size(D_h,3)]==[n_y,n_u,n_h]))
                    error('D_h: size.');
                elseif(~all([size(E_h,1),size(E_h,2),size(E_h,3)]==[n_x,n_w,n_h]))
                    error('E_h: size.');
                elseif(~all([size(F_h,1),size(F_h,2),size(F_h,3)]==[n_y,n_w,n_h]))
                    error('F_h: size.');
                else
                    % Construct object
                    
                    obj.h = h;
                    obj.A_h = A_h;
                    obj.B_h = B_h;
                    obj.C_h = C_h;
                    obj.D_h = D_h;
                    obj.E_h = E_h;
                    obj.F_h = F_h;
                end
            end
        end
          
        function [A,B,C,D,E,F,omega] = buildHarmonicModel(obj,f_1,h_max)
            % [A,B,C,D,E,F,omega] = buildHarmonicModel(obj,f_1,h_max)
            %
            % INPUT
            %   f_1     Fundamental frequency.
            %   h_max   Maximum harmonic order of interest.
            % 
            % OUTPUT
            %   A-F     Toeplitz matrices whose elements are the Fourier
            %           coefficients of A(t)-F(t).
            %   omega   Diagonal matrix which represents dx_dt(t)
            %           (i.e., dx_dt(t) ~ omega * X).
            
            import Harmonics.*;
            
            A = Toeplitz.buildSquareMatrix(obj.h,obj.A_h,h_max);
            B = Toeplitz.buildSquareMatrix(obj.h,obj.B_h,h_max);
            C = Toeplitz.buildSquareMatrix(obj.h,obj.C_h,h_max);
            D = Toeplitz.buildSquareMatrix(obj.h,obj.D_h,h_max);
            E = Toeplitz.buildSquareMatrix(obj.h,obj.E_h,h_max);
            F = Toeplitz.buildSquareMatrix(obj.h,obj.F_h,h_max);
            
            n_x = obj.getNumberOfStates();
            omega = 2*pi*f_1 * kron(diag(-h_max:1:h_max),eye(n_x));
        end
        
        function n_x = getNumberOfStates(obj)
            n_x = size(obj.A_h,1);
        end
        
        function n_u = getNumberOfInputs(obj)
            n_u = size(obj.B_h,2);
        end
        
        function n_y = getNumberOfOutputs(obj)
            n_y = size(obj.C_h,1);
        end
        
        function n_w = getNumberOfDisturbances(obj)
            n_w = size(obj.E_h,2);
        end
        
        function n_h = getNumberOfHarmonics(obj)
            n_h = length(obj.h);
        end
    end
end