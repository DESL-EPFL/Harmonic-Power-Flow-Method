function [W_K,dW_KP] = calculateReference(obj,h_max,base)
% ...

import Harmonics.*;

h = 0:1:(h_max+1);
h = h(:);

IR_h = zeros(obj.internal_transform.getSizeOfCodomain(),length(h));
IR_h(:,1) = sqrt(3/2)*obj.Iabs_reference*[cos(obj.Iarg_reference);sin(obj.Iarg_reference)];
IR_h = IR_h/base.getBaseCurrent();

W_K = Fourier.buildVector(h,IR_h);

n_W_K = length(W_K);
n_W_P = obj.internal_transform.getSizeOfDomain()*(2*h_max+1);
dW_KP = zeros(n_W_K,n_W_P);

end