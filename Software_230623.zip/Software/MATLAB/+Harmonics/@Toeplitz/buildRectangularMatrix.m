function M = buildRectangularMatrix(h,M_h,h_max_row,h_max_col)
% M = buildRectangularMatrix(h,M_h,h_max_row,h_max_col)
%
% INPUT
%   h           Harmonic orders h>=0 (M_{-h} = conj(M_h));
%   M_h         Fourier coefficients of a time-periodic matrix M(t).
%   h_max_row   Maximum harmonic order of interest (w.r.t. rows).
%   h_max_col   Maximum harmonic order of interest (w.r.t. columns).

% warning('migrate to Fourier.');

h_max = max(h_max_row,h_max_col);

n_coeffs = 2*h_max+1;
[n_rows,n_cols] = size(M_h(:,:,1));

M = repmat({zeros(n_rows,n_cols)},n_coeffs,n_coeffs);

for i=1:length(h)
    h_i = h(i);
    M_h_i = M_h(:,:,i);
    
    if(h_i<=h_max)
        % Toeplitz matrix: row-col=h
        
        rows = (h_i+1):n_coeffs;
        cols = rows-h_i;
        
        for j=1:length(rows)
            % Below main diagonal: h>0
            M{rows(j),cols(j)} = M_h_i;
            
            % Above main diagonal: h<0
            M{cols(j),rows(j)} = conj(M_h_i);
        end
    else
        break;
    end
end

% build square for h_max

blk_row = (h_max+1) + (-h_max_row:1:h_max_row);
blk_col = (h_max+1) + (-h_max_col:1:h_max_col);

M = M(blk_row,blk_col);

M = cell2mat(M);

end