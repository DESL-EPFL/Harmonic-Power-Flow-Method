function [] = initializeTimeDomainSimulation(obj,modelName,converterName,variantName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

nodeName = obj.node;
nodeName_index = [nodeName,'_',num2str(obj.index)];
blockName = [modelName,'/',nodeName,'/',nodeName_index,'/',variantName];

set_param(blockName,'P_reference',[converterName,'.P_reference']);

end