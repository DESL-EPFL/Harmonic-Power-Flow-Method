classdef DQ_Transform < Harmonics.Resource.LTP_Transform
    % DQ_TRANSFORM is the transform between phase (ABC) coordinates
    % and direct-quadrature (DQ) components.
    % For a given reference phase theta(t), the transform is defined by
    %
    %       T_abc2dq = transpose(T_dq2abc)
    %       T_dq2abc = [
    %                   cos(theta(t))        , -sin(theta(t));
    %                   cos(theta(t)-2*pi/3) , -sin(theta(t)-2*pi/3);
    %                   cos(theta(t)+2*pi/3) , -sin(theta(t)+2*pi/3)
    %                  ]
    %
    % where theta is approximated by theta(t) = 2*pi*f_1 + theta_0
    % (f_1 is the fundamental frequency, theta_0 is a phase offset).
    
    methods
        function obj = DQ_Transform()
            % obj = DQ_Transform()
            
            T_abc2dq = zeros(2,3);
            T_abc2dq(1,1) = 1/2;
            T_abc2dq(1,2) = 1/2*exp(-1i*2*pi/3);
            T_abc2dq(1,3) = 1/2*exp(+1i*2*pi/3);
            T_abc2dq(2,1) = -1/2i;
            T_abc2dq(2,2) = -1/2i*exp(-1i*2*pi/3);
            T_abc2dq(2,3) = -1/2i*exp(+1i*2*pi/3);
            T_abc2dq = sqrt(2/3)*T_abc2dq;
            
            T_dq2abc = transpose(T_abc2dq);
            
            obj@Harmonics.Resource.LTP_Transform(1,T_abc2dq,T_dq2abc);
        end
        
        % Implement abstract methods
        
        function [T_FW,T_BW] = buildHarmonicModel(obj,theta_0,f_1,h_max,n_FW,n_BW)
            % [T_FW,T_BW] = buildHarmonicModel(obj,theta_0,f_1,h_max,n_FW,n_BW,)
            %
            % INPUT
            %   theta_0     Offset of the reference phase theta(t).
            %   f_1         Fundamental frequency.
            %   h_max       Maximum harmonic order of interest.
            %   n_FW        Number of ABC quantities to be transformed.
            %   n_BW        Number of DQ quantities to be transformed.
            %
            % OUTPUT
            %   T_{FW/BW}   Toeplitz matrices whose elements are the
            %               Fourier coefficients of the forward/backward
            %               transformation matrices.
            
            warning('Migrate functionality to CIR');
            
            import Harmonics.*;
            
            T_FW_h = repmat({obj.T_FW_h*exp(1i*theta_0)},n_FW,1);
            T_FW_h = blkdiag(T_FW_h{:});
            T_BW_h = repmat({obj.T_BW_h*exp(1i*theta_0)},n_BW,1);
            T_BW_h = blkdiag(T_BW_h{:});
            
            h = obj.h;
            
            h_ABC = h_max;
            h_DQ = h_max+1;
            T_FW = Toeplitz.buildRectangularMatrix(h,T_FW_h,h_DQ,h_ABC);
            T_BW = Toeplitz.buildRectangularMatrix(h,T_BW_h,h_ABC,h_DQ);
        end
        
        function X_DQ_h = transformForward(obj,h,X_ABC_h)
            % X_DQ_h = transformForward(obj,h,X_ABC_h)
            
            import Harmonics.*;
            import Harmonics.Resource.*;
            
            X_ABC = Fourier.buildVector(h,X_ABC_h);
            
            h_max = max(h);
            T_FW = Toeplitz.buildRectangularMatrix(obj.h,obj.T_FW_h,h_max+1,h_max);
            
            X_DQ = T_FW * X_ABC;
            n_DQ = obj.getSizeOfCodomain();
            [h_trash,X_DQ_h] = Fourier.splitVector(X_DQ,n_DQ);
        end
        
        function X_ABC_h = transformBackward(obj,h,X_DQ_h)
            % [X_ABC_h] = transformBackward(h,X_DQ_h)
            
            import Harmonics.*;
            import Harmonics.Resource.*;
            
            X_DQ = Fourier.buildVector(h,X_DQ_h);
            
            h_max = max(h);
            T_BW = Toeplitz.buildRectangularMatrix(obj.h,obj.T_BW_h,h_max-1,h_max);
            
            X_ABC = T_BW * X_DQ;
            n_ABC = obj.getSizeOfDomain();
            [h_trash,X_ABC_h] = Fourier.splitVector(X_ABC,n_ABC);
        end
    end
    
    methods(Static)
        % Implement abstract methods
        
        function n_ABC = getSizeOfDomain()
            n_ABC = 3;
        end
        
        function n_DQ = getSizeOfCodomain()
            n_DQ = 2;
        end
    end
end