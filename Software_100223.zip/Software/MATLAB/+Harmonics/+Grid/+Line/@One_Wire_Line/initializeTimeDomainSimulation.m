function [] = initializeTimeDomainSimulation(obj,modelName,parameterName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

lineName = obj.name;
blockName = [modelName,filesep(),lineName];

% set_param(blockName,'Li',parameterName);
set_param(blockName,'R',['[',parameterName,'.R',']']);
set_param(blockName,'L',['[',parameterName,'.L',']']); 
set_param(blockName,'C',['[',parameterName,'.C',']']);
set_param(blockName,'len',[parameterName,'.length']);

end