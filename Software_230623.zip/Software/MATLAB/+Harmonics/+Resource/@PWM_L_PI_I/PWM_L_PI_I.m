classdef PWM_L_PI_I < Harmonics.Resource.CIR_I
    %   PWM_LCL_PI_I represents a converter-interfaced resource
    %   which consists of the following components:
    %   -   actuator: pulse-widh modulator (PWM)
    %   -   filter: inductor + capacitor + inductor (LCL)
    %   -   controller: proportional-integral (PI) cascade
    %   -   reference: current angel and magnitude (I)
    
    properties(SetAccess=private)
        L_stage;   % Actuator-side inductive stage.
    end
    
    properties
        Iabs_reference;
        Iarg_reference;
    end
    
    methods
        function obj = PWM_L_PI_I(node,index,L_stage,f_nominal,Iabs_reference,Iarg_reference,base)
            % obj = PWM_L_PI_I(node,L_stage,f_nominal,Iabs_reference,Iarg_reference,base)
            
            import Harmonics.Resource.*;
            
            control_software = PWM_L_PI_I.buildControlSoftware(L_stage,f_nominal,base);
            
            power_hardware = PWM_L_PI_I.buildPowerHardware(L_stage,f_nominal,base);
            
            internal_transform = PWM_L_PI_I.buildInternalTransform();
            external_transform = PWM_L_PI_I.buildExternalTransform();
            
            obj = obj@Harmonics.Resource.CIR_I(node,index,power_hardware,control_software,internal_transform,external_transform);
            
            obj.L_stage = L_stage;
            
            if(~isa(Iabs_reference,'numeric'))
                error('Iabs_reference: type.');
            elseif(~isa(Iarg_reference,'numeric'))
                error('Iarg_reference: type.');
            elseif(~all(size(Iabs_reference)==1))
                error('Iabs_reference: size.');
            elseif(~all(size(Iarg_reference)==1))
                error('Iarg_reference: size.');
            else
                obj.Iabs_reference = Iabs_reference;
                obj.Iarg_reference = Iarg_reference;
            end
        end
        
        function n_stages = getNumberOfStages(obj)
            % n_stages = getNumberOfStages(obj)
            n_stages = 1; % L
        end
        
        function l_operating = getLengthOfOperatingPoint(obj)
            % l_operating = getLengthOfOperatingPoint(obj)
            l_operating = 0;
        end
        
        % Implement abstract methods
        
        [Ih,dIh_dVh,Oh] = calculateGridResponse(obj,Ts,f1,h,Vh,Oh,base);
        [W_K,dW_KP] = calculateReference(obj,h_max,base)
        [G_PP,G_PK,G_KP,G_KK] = calculateInternalGain(obj,theta_0,Ts,f_1,h_max);
        [VA_h,IA_h,VF_h,IG_h] = calculateInternalResponse(obj,Ts,f_1,h,VG_h,base);
        [T_PG,T_GP] = calculateExternalTransform(obj,h_max);
        [T_KP,T_PK] = calculateInternalTransform(obj,theta_0,Ts,f_1,h_max);
        
        [outSim] = runTimeDomainSimulation(obj,folder,modelName,converterName,variantName,h_max,Ts);
        initializeTimeDomainSimulation(obj,modelName,converterName,variantName);
    end
    
    methods(Static)
        % Implement abstract methods;
        
        resource = buildFromFile(file,base,f_nominal)
        power_hardware = buildPowerHardware(L_stage,f_1,base);
        control_software = buildControlSoftware(L_stage,f_1,base);
        
        function transform = buildInternalTransform()
            
            import Harmonics.Resource.*;
            
            transform = DQ_Transform();
        end
        
        function transform = buildExternalTransform()
            
            import Harmonics.Resource.*;
            
            transform = WyeWye_Connection('yes','no');
        end
    end
end
