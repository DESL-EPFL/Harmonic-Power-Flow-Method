classdef Subsystem < matlab.mixin.Heterogeneous
    % Subsystem Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        grid;
    end
    
    methods
        function obj = Subsystem(grid)
            % obj = AC_System(grid,resources_forming,resources_following)
            
            import Harmonics.*;
            import Harmonics.Grid.*;
            import Harmonics.Resource.*;
            
            if(~isa(grid,'Grid'))
                error('grid: type.');
            else
                obj.grid = grid;
            end
        end
    end

    methods(Abstract)
        % HPF
        outputs = calculateResourceQuantities(obj,inputs);
        outputs = getNumberOfResources(obj,inputs);
        outputs = getNodePartition(obj,inputs);
%         outputs = solveNewtonRaphson(obj,inputs);
        
        % TDS
        outputs = initializeTimeDomainSimulation(obj,inputs);
%         outputs = runTimeDomainSimulation(obj,inputs);
    end
end