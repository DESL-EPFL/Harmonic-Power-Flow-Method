clear all;
close all;
clc;

disp('START');

import Harmonics.*;
import Harmonics.Grid.*;
import Harmonics.Resource.*;

% Parameters

f_nominal = 50;
h_max = 25;
P_base = 100e3;
V_base = 230*sqrt(2);
unit_base = Base(P_base,V_base); % HPF in nominal values

h = (0:1:h_max)';

time = struct('Ts_HW',5e-06,'Ts_SW',5e-06,'Tend',2); % in (s)

%%  Prepare

folder = '/Users/johanna/EPFL GDrive/GIT/Software/';

folder_config = [folder filesep() 'Configuration Files'];
folder_results = [folder filesep() 'Results' filesep() 'Resources'];

file_results = 'PWM_L_PI_I_h25';


file = [folder_config filesep() 'PWM_L_PI_I_Pn100k.xlsx'];
converter_following = PWM_L_PI_I.buildFromFile(file,unit_base,f_nominal);

file = [folder_config filesep() 'TE_resource.xlsx']; % needed for TDS
slack = Thevenin.buildFromFile(file);%,unit_base);

%%  Simulate TDS

VG_h = struct();
IG_h = struct();
VA_h = struct();

% Simulation Workspace Parameter
Vdc = 900;
PLL = struct('TsetPLL',0.5,'zeta',0.7);

% Thevenin Equivalent for TDS
TE = struct('h',slack.h,'bin',slack.E_h,'R',slack.R,'L',slack.L,'Name','VTE');
dist = TDSAnalysis.getWaveform(TE,0,time.Tend,f_nominal,time.Ts_HW);
THD = sqrt(sum(abs(2*slack.E_h(1,2:end)).^2))/abs(2*slack.E_h(1,1))*100 % Total harmonic distortion

% ------- Comment in/out for simulating/loading

[simOut] = converter_following.runTimeDomainSimulation(folder,'TDS_PWM_L_PI_I','converter_following','CIDER',h_max+1,time.Ts_HW);

VG_h.TDS = simOut.Y.VG.bin(:,1:h_max+1);
IG_h.TDS = simOut.Y.IG.bin(:,1:h_max+1);
VA_h.TDS = simOut.Y.VA.bin(:,1:h_max+2);

save([folder_results filesep() 'TDS_' file_results '.mat'],'VG_h','IG_h','VA_h')

% ------- 

% load TDS from matfile
load([folder_results filesep() 'TDS_' file_results '.mat'])

% normalize
V_base = unit_base.getBaseVoltage;
I_base = unit_base.getBaseCurrent;
VG_h.TDS = VG_h.TDS / V_base;
IG_h.TDS = IG_h.TDS / I_base;
VA_h.TDS = VA_h.TDS / V_base;


%% Simulate HPF 

[VA_h.HPF,IG_h.HPF] = converter_following.calculateInternalResponse(time.Ts_SW,f_nominal,h,VG_h.TDS,unit_base);

%% Plot

h_set = [1,5,7,11,13,17,19,23,25];

file_location = [folder_results filesep() file_results '_IG'];
[h_abs,max_abs,h_arg,max_arg] = semilog_Resource(IG_h.TDS,IG_h.HPF,(1:3),h_set,h_max,'I','A','\gamma',file_location,1);

%%  Analyze

[T_abc2pnz,~] = PNZ_Transform.build();
V1_ABC = VG_h.TDS(:,h==1);
V1_PNH = T_abc2pnz*V1_ABC;
theta0 = angle(V1_PNH(1));

I_abs = converter_following.Iabs_reference/unit_base.getBaseCurrent/2;
I_arg = converter_following.Iarg_reference+theta0;
I_ref = I_abs*exp(1j*I_arg)*exp(1j*[0;-2*pi/3;2*pi/3]);

S_ref = sum(VG_h.TDS(1:3,2)*2.*conj(I_ref));
S_ref = [real(S_ref),imag(S_ref)]

I_HPF = IG_h.HPF(1:3,2);

S_HPF = sum(VG_h.TDS(1:3,2)*2.*conj(IG_h.HPF(1:3,2)));
S_HPF = [real(S_HPF),imag(S_HPF)]


%%

disp(' ');
disp('##########');
disp(' ');

e_IG = analyseSpectra(h,IG_h.HPF,IG_h.TDS);
d_IG = sum(abs(IG_h.HPF-IG_h.TDS).^2)/sum(abs(IG_h.TDS).^2);

disp('Results: IG_h (HPF vs. TDS)');
disp(' ');
disp(e_IG);
disp(['PSD: ',num2str(d_IG)]);
disp(' ');

e_VA = analyseSpectra([h;h_max+1],VA_h.HPF,VA_h.TDS);
d_VA = sum(abs(VA_h.HPF-VA_h.TDS).^2)/sum(abs(VA_h.TDS).^2);

disp('Results: VA_h (HPF vs. TDS)');
disp(' ');
disp(e_VA);
disp(['PSD: ',num2str(d_VA)]);
disp(' ');

disp('STOP');