function [G_PP,G_PK,G_KP,G_KK] = calculateInternalGain(obj,theta_0,Ts,f_1,h_max)
% [G_PP,G_PK,G_KP,G_KK] = calculateInternalGain(obj,theta_0,f_1,h_max)
% 
% INPUT
% - theta_0     Angle offset of synchronization unit.
% - Ts          Sampling time.
% - f_1         Fundamental frequency.
% - h_max       Maximum harmonic order of interest.
% 
% OUTPUT
% - G_{[P,K]x[P,K]} ...

% Subsystems:
% P = pi ~ power
% K = kappa ~ control

[A_P,B_P,C_P,D_P,E_P,F_P,omega_P] = obj.power_hardware.buildHarmonicModel(f_1,h_max);
[A_K,B_K,C_K,D_K,E_K,F_K,omega_K] = obj.control_software.buildHarmonicModel(f_1,h_max+1);

[T_KP,T_PK] = obj.calculateInternalTransform(theta_0,Ts,f_1,h_max);

% Open-Loop (OL) system

omega = blkdiag(omega_P,omega_K);

A_OL = blkdiag(A_P,A_K);
B_OL = blkdiag(B_P,B_K);
C_OL = blkdiag(C_P,C_K);
D_OL = blkdiag(D_P,D_K);
E_OL = blkdiag(E_P,E_K);
F_OL = blkdiag(F_P,F_K);

T = cell(2,2);
T{1,1} = zeros(size(T_PK,1),size(T_KP,2));
T{1,2} = T_PK;
T{2,1} = T_KP;
T{2,2} = zeros(size(T_KP,1),size(T_PK,2));
T = cell2mat(T);

% Closed-Loop (CL) system

I_1 = speye(size(T,1));
I_2 = speye(size(D_OL,1));

A_CL = A_OL + B_OL*((I_1-T*D_OL)\T)*C_OL;
C_CL = (I_2-D_OL*T)\C_OL;
E_CL = E_OL + B_OL*((I_1-T*D_OL)\T)*F_OL;
F_CL = (I_2-D_OL*T)\F_OL;

G_CL = C_CL*((1i*omega-A_CL)\E_CL) + F_CL;

% Blocks

n_w_p = obj.power_hardware.getNumberOfDisturbances();
n_w_k = obj.control_software.getNumberOfDisturbances();
n_y_p = obj.power_hardware.getNumberOfOutputs();
n_y_k = obj.control_software.getNumberOfOutputs();

idx_y_p = 1:n_y_p*(2*h_max+1);
idx_y_k = (1:n_y_k*(2*(h_max+1)+1)) + max(idx_y_p);
idx_w_p = 1:n_w_p*(2*h_max+1);
idx_w_k = (1:n_w_k*(2*(h_max+1)+1)) + max(idx_w_p);

G_PP = G_CL(idx_y_p,idx_w_p);
G_PK = G_CL(idx_y_p,idx_w_k);
G_KP = G_CL(idx_y_k,idx_w_p);
G_KK = G_CL(idx_y_k,idx_w_k);

end