function thevenin = buildFromFile(file)
% grid = buildFromFile(file,base)

import Harmonics.*;
import Harmonics.Grid.*;

if(~isa(file,'char'))
    error('file: type.');
else
    
    
    %% Read
    
    % Node
    
    [numeric,text,raw] = xlsread(file,'Node');
    node = text{2,1};
    
    % Voltage source
    
    [numeric,text,raw] = xlsread(file,'Source');
    
    h = numeric(:,1);
    enable = numeric(:,3);
    E_h_abs = numeric(:,4);
    E_h_arg = numeric(:,5);
    
    h = h(enable==true);
    E_h_abs = E_h_abs(enable==true);
    E_h_arg = E_h_arg(enable==true);
    
    % Output impedance
    
    [numeric,text,raw] = xlsread(file,'Impedance');
    
    R = numeric(1,1);
    L = numeric(1,2);
    
    %% Build
    
    E_h = zeros(3,length(h));
    for i=1:length(h)
        E_h(:,i) = 1/2 * E_h_abs(i) * exp(1i*h(i)*(E_h_arg(i)+2*pi/3*[0;-1;1]));
    end
    
    thevenin = Thevenin(node,h,E_h,R,L);
end

end