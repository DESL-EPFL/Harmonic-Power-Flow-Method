function [Vh,dVh_dIh,Oh] = calculateGridResponse(obj,Ts,f_1,h,Ih,Oh,base)
% [Vh,dVh_dIh] = calculateGridResponse(obj,f1,h,Ih,base)
%
% INPUT
% - Ts          Sampling time.
% - f_1         Fundamental frequency.
% - h           Harmonic orders (w.r.t. the fundamental frequency)
% - Ih          Fourier coefficients of the grid current.
% - Oh          Fourier coefficients of the operating point (empty).
% - base        Per-unit base.
%
% OUTPUT
% - Vh          Fourier coefficients of the grid voltage.
% - dVh_dIh     Fourier coefficients of the Jacobian matrix
%               of the grid voltage w.r.t. the grid current.
% - Oh          Fourier coefficients of the new operating point (empty).

import Harmonics.*;

h_max = max(h);

%% Input

W_G = Fourier.buildVector(h,Ih);

%% External Transform

[T_PG,T_GP] = obj.calculateExternalTransform(h_max);

%% Internal Response

W_P = T_PG * W_G;
[W_K,dW_KP] = calculateReference(obj,h_max,base);

[G_PP,G_PK,G_KP,G_KK] = obj.calculateInternalGain(Ts,f_1,h_max);

Y_P = G_PP * W_P + G_PK * W_K;
%Y_K = G_KP * W_P + G_KK * W_K;

dY_PP = G_PP + G_PK * dW_KP;

%% External Response

Y_G = T_GP * Y_P;
dY_GG = T_GP * dY_PP * T_PG;

n_W_G = obj.external_transform.getSizeOfCodomain();
n_Y_G = n_W_G;

[~,Vh] = Fourier.splitVector(Y_G,n_Y_G);
[~,dVh_dIh] = Fourier.splitMatrix(dY_GG,n_Y_G,n_W_G);

end