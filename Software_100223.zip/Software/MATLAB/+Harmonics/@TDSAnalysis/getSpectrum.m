function FT = getSpectrum(signal,f_1,Ts,h_max)
            
x = signal.Data;
L = length(signal.Time);

y = fft(x,L,1)/L;

df = 1/(L*Ts);

fp = df*(0:(L/2)-1);
%fm = -flip(obj.f_sampling*(1:(L/2))/L);
f = fp;%[fp,fm];

% reduce to harmonics
L_f = length(f);
bin = find(f==f_1);
int = (1:bin-1:L_f);

FT.f = f(int)';
FT.h = FT.f/f_1;
FT.bin = y(int,:);

FT.f = FT.f([1:h_max+1]);%,end-(h_max+1)+1:end]);
FT.h = FT.h([1:h_max+1]);%,end-(h_max+1)+1:end]);
FT.bin = transpose(FT.bin([1:h_max+1],:));%,end-(h_max+1)+1:end],:)';
FT.Name = signal.Name;

end