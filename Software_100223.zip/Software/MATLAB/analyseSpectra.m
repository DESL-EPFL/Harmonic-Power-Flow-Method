function results = analyseSpectra(h,X_HPF_h,X_TDS_h)

if(~all(size(X_HPF_h)==size(X_TDS_h)))
    error('Spectra.');
elseif(~all([]==length(h)))
    dips('Harmonics.');
else
    tol_ignore = 1e-3;
    idx_ignore = find(max(abs(X_HPF_h),[],1)<tol_ignore);
    h(idx_ignore) = [];
    X_HPF_h(:,idx_ignore) = [];
    X_TDS_h(:,idx_ignore) = [];
    
    e_abs = (abs(X_HPF_h)-abs(X_TDS_h))./abs(X_TDS_h)*100;
    e_arg = (angle(X_HPF_h)-angle(X_TDS_h))/pi*180;
    e_arg(e_arg>180) = 360 - e_arg(e_arg>180);
    
    e_abs_max = max(e_abs,[],1);
    e_arg_max = max(abs(e_arg),[],1);
    
    data = [h(:),e_abs_max(:),e_arg_max(:)];
    names = {'h','e_abs_pct','e_arg_deg'};
    results = table(data(:,1),data(:,2),data(:,3),'VariableNames',names);
end


end