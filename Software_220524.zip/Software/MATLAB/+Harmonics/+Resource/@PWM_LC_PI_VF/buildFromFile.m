function resource = buildFromFile(file,base)
% resource = buildFromFile(file,base)

import Harmonics.*
import Harmonics.Resource.*;

if(~isa(file,'char'))
    error('file: type.');
elseif(~isa(base,'Base'))
    error('base: type.')
elseif(~all(size(base)==1))
    error('base: size.');
else
    [numeric,text,raw] = xlsread(file,'Node');
    node = raw{2,1};
    index = raw{2,2};
    
    [numeric,text,raw] = xlsread(file,'Reference');
    V_reference = numeric(1)*sqrt(2);%/base.getBaseVoltage();
    f_reference = numeric(2);
    
    L_stage = PI_Loop_L.buildFromFile(file,'L_stage',base);
    C_stage = PI_Loop_C.buildFromFile(file,'C_stage',base);
    
    resource = PWM_LC_PI_VF(node,index,L_stage,C_stage,V_reference,f_reference,base);
end

end