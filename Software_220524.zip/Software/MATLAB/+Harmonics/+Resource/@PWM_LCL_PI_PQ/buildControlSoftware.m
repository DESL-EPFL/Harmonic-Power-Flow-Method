function control_software = buildControlSoftware(LA_stage,C_stage,LG_stage,f_1,base)
% control_software = buildControlSoftware(LA_stage,C_stage,LG_stage,f_1)

import Harmonics.Resource.*;

if(~isa(LA_stage,'PI_Loop_L'))
    error('LA_stage: type.'),
elseif(~isa(C_stage,'PI_Loop_C'))
    error('C_stage: type.');
elseif(~isa(LG_stage,'PI_Loop_L'))
    error('LG_stage: type.');
elseif(~isa(f_1,'numeric'))
    error('f_1: type.');
else
    h = 0;
    
    [KA_FT,KA_FF,KA_FB,TA_FB] = LA_stage.buildSoftwareModel(f_1,base);
    [KF_FT,KF_FF,KF_FB,TF_FB] = C_stage.buildSoftwareModel(f_1,base);
    [KG_FT,KG_FF,KG_FB,TG_FB] = LG_stage.buildSoftwareModel(f_1,base);
    
    Z = zeros(2,2); % Zero matrix (w.r.t. DQ frame).
    I = eye(2); % Identity matrix (w.r.t. DQ frame).
    
    A_h = [Z,KF_FB/TF_FB,(KF_FF+KF_FB)*KG_FB/TG_FB;...
           Z,Z,KG_FB/TG_FB;...
           Z,Z,Z];
    B_h = [-I,-KF_FB,KF_FT-(KF_FF+KF_FB)*KG_FB,(KF_FF+KF_FB)*KG_FT;...
           Z,-I,-KG_FB,KG_FT;...
           Z,Z,-I,Z];
    E_h = [(KF_FF+KF_FB)*(KG_FF+KG_FB);KG_FF+KG_FB;I];
    
    C_h = [KA_FB/TA_FB,...
           (KA_FF+KA_FB)*KF_FB/TF_FB,...
           (KA_FF+KA_FB)*(KF_FF+KF_FB)*KG_FB/TG_FB];
    D_h = [-KA_FB,...
           KA_FT-(KA_FF+KA_FB)*KF_FB,...
           (KA_FF+KA_FB)*(KF_FT-(KF_FF+KF_FB)*KG_FB),...
           (KA_FF+KA_FB)*(KF_FF+KF_FB)*KG_FT];
    F_h = (KA_FF+KA_FB)*(KF_FF+KF_FB)*(KG_FF+KG_FB);
    
    control_software = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h);
end

end