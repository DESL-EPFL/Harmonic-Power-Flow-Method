classdef WyeWye_Connection < Harmonics.Resource.LTP_Transform
    % WYEWYE_IDEALTRANSFORMER represents a circuit connection which is
    % wye-connected on both sides (i.e., primary and secondary side).
    % Note that, unless both sides are equipped with a neutral conductor,
    % homopolar sequences cannot propagate.
    
    properties(SetAccess=private)
        neutral_primary;
        neutral_secondary;
    end
    
    methods
        function obj = WyeWye_Connection(neutral_primary,neutral_secondary)
            % obj = WyeWye_Connection(neutral_primary,neutral_secondary)
            
            % Check
            if(~isa(neutral_primary,'char'))
                error('neutral_primary: type.');
            elseif(~isa(neutral_secondary,'char'))
                error('neutral_secondary: type.');
            elseif(~ismember(neutral_primary,{'yes','no'}))
                error('neutral_primary: value.')
            elseif(~ismember(neutral_primary,{'yes','no'}))
                error('neutral_secondary: value.');
            end
            
            % Superclass
            
            h = 0;
            
            if(all(strcmp({neutral_primary,neutral_secondary},'yes')))
                T_FW_h = eye(3);
                T_BW_h = eye(3);
            else
                T_FW_h = eye(3) - 1/3 * ones(3,3);
                T_BW_h = eye(3) - 1/3 * ones(3,3);
            end
            
            obj@Harmonics.Resource.LTP_Transform(h,T_FW_h,T_BW_h);
            
            % Class
            
            obj.neutral_primary = neutral_primary;
            obj.neutral_primary = neutral_secondary;
        end
        
        % Implement abstract methods
        
        function [T_FW,T_BW] = buildHarmonicModel(obj,h_max,n_FW,n_BW)
            % [T_FW,T_BW] = buildHarmonicModel(obj,h_max,n_FW,n_BW)
            %
            % INPUT
            %   h_max       Maximum harmonic order of interest.
            %   n_FW        Number of primary tuples to be transformed.
            %   n_BW        Number of secondary tuples to be transformed.
            %
            % OUTPUT
            %   T_{FW/BW}   Toeplitz matrices whose elements are the
            %               Fourier coefficients of the forward/backward
            %               transformation matrices.
            
            import Harmonics.*;
            
            h = obj.h;
            
            T_FW_h = repmat({obj.T_FW_h},n_FW,1);
            T_FW_h = blkdiag(T_FW_h{:});
            T_FW = Toeplitz.buildSquareMatrix(h,T_FW_h,h_max);
            
            T_BW_h = repmat({obj.T_BW_h},n_BW,1);
            T_BW_h = blkdiag(T_BW_h{:});
            T_BW = Toeplitz.buildSquareMatrix(h,T_BW_h,h_max);
        end
        
        function X_2_h = transformForward(obj,h,X_1_h)
            % X_delta_h = transformForward(obj,h,X_wye_h)
            
            import Harmonics.*;
            import Harmonics.Resource.*;
            
            X_1 = Fourier.buildVector(h,X_1_h);
            
            h_max = max(h);
            T_FW = Toeplitz.buildSquareMatrix(obj.h,obj.T_FW_h,h_max);
            
            X_2 = T_FW * X_1;
            n_2 = obj.getSizeOfCodomain();
            [h_trash,X_2_h] = Fourier.splitVector(X_2,n_2);
        end
        
        function X_1_h = transformBackward(obj,h,X_2_h)
            % X_1_h = transformBackward(obj,h,X_2_h)
            
            import Harmonics.*;
            import Harmonics.Resource.*;
            
            X_2 = Fourier.buildVector(h,X_2_h);
            
            h_max = max(h);
            T_BW = Toeplitz.buildSquareMatrix(obj.h,obj.T_BW_h,h_max);
            
            X_1 = T_BW * X_2;
            n_1 = obj.getSizeOfDomain();
            [h_trash,X_1_h] = Fourier.splitVector(X_1,n_1);
        end
    end
    methods(Static)
        % Implement abstract methods
        
        function n_wye = getSizeOfDomain()
            n_wye = 3;
        end
        
        function n_wye = getSizeOfCodomain()
            n_wye = 3;
        end
    end
end