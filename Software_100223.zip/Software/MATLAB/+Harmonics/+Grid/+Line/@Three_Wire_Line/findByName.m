function [found,indices] = findByName(lines,names)
% [found,indices] = findByName(lines,names)

import Harmonics.Grid.*;

if(~isa(lines,'Line'))
    error('lines: type.');
elseif(~isa(names,'cell'))
    error('names: type.');
else
    [found,indices] = ismember(names,{lines.name});
end

end