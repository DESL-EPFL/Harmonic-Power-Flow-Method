function semilog_Error(V_h,I_h,idx_1,idx_2,h,h_max,legendStr,fileStr,fig)

color_1 = 0.7*[1,1,1];
color_2 = 'k';

tolerance = 1e-3;

set(groot,'defaultAxesTickLabelInterpreter','latex');  

figure(fig);
clf;

x = 0:h_max;

X_h = [V_h;I_h];
quantityStr = {'V','I'};

for i = 1:2
    % Magnitude
    e_abs_1 = errorCalculation(X_h(i).TDS(idx_1,:),X_h(i).HPF(idx_1,:),'abs',tolerance);
    e_abs_2 = errorCalculation(X_h(i).TDS(idx_2,:),X_h(i).HPF(idx_2,:),'abs',tolerance);
    e_abs = [e_abs_1;e_abs_2];
%     e_abs(:,setdiff(0:h_max,h)'+1) = 0;   
          
    h_plot(i) = subplot(2,2,i);
    if i == 1
        h_plot(i).Position = h_plot(i).Position + [-0.030 0.01 0.09 -0.01];
    else
        h_plot(i).Position = h_plot(i).Position + [-0.005 0.01 0.09 -0.01];
    end
    
    b(i,:) = bar(x',e_abs','LineWidth',0.01);
    b(i,1).FaceColor = color_1;
    b(i,2).FaceColor = color_2;
    
    ax = gca;
    grid(gca,'on');
    set(gca, 'YScale', 'log');
    ax.MinorGridAlpha = 0.1;
    xlim([-0.5,h_max+0.5]);
    ylim([1e-13,1]);
    set(gca,'XTick',[1:4:h_max]);
    set(gca,'YTick',10.^[-12:4:0]);
    if i == 1
        yticklabels({'1E-12','1E-8','1E-4','1E+0'})
    else
        yticklabels({})
    end
    
    if i == 1
%         legend({'PQ','Z'},'Location','NorthWest','Orientation','Horizontal','interpreter','latex');
        legend(legendStr,'Location','NorthWest','Orientation','Horizontal','interpreter','latex');
    end
    title(['$e_{\textup{abs}}(',quantityStr{i},'_{\gamma,h})$ (p.u.)'],'interpreter','latex');

    % Angle
    e_arg_1 = errorCalculation(X_h(i).TDS(idx_1,:),X_h(i).HPF(idx_1,:),'arg',tolerance);
    e_arg_2 = errorCalculation(X_h(i).TDS(idx_2,:),X_h(i).HPF(idx_2,:),'arg',tolerance);
    e_arg = [e_arg_1;e_arg_2];
    e_arg(:,setdiff(0:h_max,h)'+1) = 0;    
    e_arg(e_arg>180) = 360 - e_arg(e_arg>180);

    e_arg = e_arg*pi/180*1e3; % convert to mrad
       
    h_plot(i+2) = subplot(2,2,i+2);
    if i == 1
        h_plot(i+2).Position = h_plot(i+2).Position + [-0.030 0.01 0.09 -0.01];
    else
        h_plot(i+2).Position = h_plot(i+2).Position + [-0.005 0.01 0.09 -0.01];
    end
    
    b(i+2,:) = bar(x',e_arg','LineWidth',0.01);
    b(i+2,1).FaceColor = color_1;
    b(i+2,2).FaceColor = color_2;
    
    ax = gca;
    grid(gca,'on');
    set(gca, 'YScale', 'log');
    ax.MinorGridAlpha = 0.1;
    xlim([-0.5,h_max+0.5]);
    ylim([1e-3,3e2]);
    set(gca,'YTick',10.^[-3:1:2]);
    set(gca,'XTick',[1:4:h_max]);
    if i == 1
        yticklabels({'1E-3','1E-2','1E-1','1E+0','1E+1','1E+2'})
    else
        yticklabels({})
    end
    
    title(['$e_{\textup{arg}}(',quantityStr{i},'_{\gamma,h})$ (mrad)'],'interpreter','latex');
    xlabel('Harmonic Order (h)','interpreter','latex');
end
  
set(gcf,'PaperUnits','points');
set(gcf,'PaperSize',[350,240]);
set(gcf,'PaperPosition',[0,0,350,240]);

saveas(gcf,fileStr,'pdf');

end