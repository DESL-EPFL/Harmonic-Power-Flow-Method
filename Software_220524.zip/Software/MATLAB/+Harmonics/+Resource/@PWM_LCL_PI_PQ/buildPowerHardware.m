function power_hardware = buildPowerHardware(LA_stage,C_stage,LG_stage,f_1,base)
% power_hardware = buildPowerHardware(LA_stage,C_stage,LG_stage)

import Harmonics.Resource.*;

if(~isa(LA_stage,'PI_Loop_L'))
    error('LA_stage: type.');
elseif(~isa(C_stage,'PI_Loop_C'))
    error('C_stage: type.');
elseif(~isa(LG_stage,'PI_Loop_L'))
    error('LG_stage: type.');
else
    n_phases = 3;
    
    [RA,LA] = LA_stage.buildHardwareModel(f_1,base);
    [G,C]   = C_stage.buildHardwareModel(f_1,base);
    [RG,LG] = LG_stage.buildHardwareModel(f_1,base);
    
    h = 0;
    
    A_h = [-inv(LA)*RA,-inv(LA),zeros(n_phases,n_phases);...
           inv(C),-inv(C)*G,-inv(C);...
           zeros(n_phases,n_phases),inv(LG),-inv(LG)*RG];
    B_h = [inv(LA);zeros(n_phases,n_phases);zeros(n_phases,n_phases)];
    E_h = [zeros(n_phases,n_phases);zeros(n_phases,n_phases);-inv(LG)];
    
    C_h = [eye(3*n_phases);zeros(n_phases,3*n_phases)];
    D_h = zeros(4*n_phases,n_phases);
    F_h = [zeros(3*n_phases,n_phases);eye(n_phases)];
    
    power_hardware = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h);
end

end