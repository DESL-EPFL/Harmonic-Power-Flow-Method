clear all;
close all;
clc;

disp('START');

import Harmonics.*
import Harmonics.Grid.*;
import Harmonics.Resource.*;
import Harmonics.System.*;

% Parameters

f_nominal = 50;
h_max = 25;
P_base = 50e3;
V_base = 230*sqrt(2);
unit_base = Base(P_base,V_base);

h = transpose(0:1:h_max);

Vdc = 900;
time = struct('Ts_HW',1e-06,'Ts_SW',1e-06,'Tend',1); % in (s)

%% Build

folder = '/Users/johanna/EPFL GDrive/GIT/Software/';

folder_config = [folder filesep() 'Configuration Files/ACDC_Microgrid'];
folder_results = [folder filesep() 'Results' filesep() 'Systems'];

file_results = 'ACDC_Microgrid_h25';

% --- AC Subsystem
n_phases = 3;
% Grid
file = [folder_config filesep() 'AC_Subsystem' filesep() 'Subsystem_AC_param.xlsx'];
power_grid_AC = Grid.buildFromFile(file,n_phases,unit_base); 

% Slack
file = [folder_config filesep() 'AC_Subsystem' filesep() 'TE.xlsx'];
slack = Thevenin.buildFromFile(file); 

% Resources
converter_forming = [];

for r = 1 : 7
    file = [folder_config filesep() 'AC_Subsystem' filesep() 'PWM_LCL_C_PI_VQ_P_' num2str(r) '_Pn60k.xlsx'];
    converter_following(r) = PWM_LCL_C_PI_VQ_I.buildFromFile(file,unit_base,f_nominal); 
end

for r = 1:2
   file = [folder_config filesep() 'AC_Subsystem' filesep() 'RLC_S_Load_' num2str(r) '_Pn60k.xlsx'];
   passive_loads(r) = RLC_S_Load.buildFromFile(file,n_phases,unit_base,f_nominal);
end

subsystem(1) = AC_Subsystem(power_grid_AC,slack,converter_forming,converter_following,passive_loads);

% --- DC Subsystem
n_wires = 1;
% Grid
file = [folder_config filesep() 'DC_Subsystem' filesep() 'Subsystem_DC_param.xlsx'];
power_grid_DC = Grid.buildFromFile(file,n_wires,unit_base); 

% Resources
generator_forming = [];

file = [folder_config filesep() 'DC_Subsystem' filesep() 'I_Source_1_Pn5k.xlsx'];
generator_following(1) = I_Source.buildFromFile(file,unit_base,f_nominal); 
file = [folder_config filesep() 'DC_Subsystem' filesep() 'I_Source_2_Pn10k.xlsx'];
generator_following(2) = I_Source.buildFromFile(file,unit_base,f_nominal); 
file = [folder_config filesep() 'DC_Subsystem' filesep() 'I_Source_3_Pn5k.xlsx'];
generator_following(3) = I_Source.buildFromFile(file,unit_base,f_nominal); 

file = [folder_config filesep() 'DC_Subsystem' filesep() 'RLC_S_Load_1_Pn8k.xlsx'];
passive_DC_loads(1) = DC_Load.buildFromFile(file,n_wires,unit_base,f_nominal); 

subsystem(2) = DC_Subsystem(power_grid_DC,generator_forming,generator_following,passive_DC_loads);

% Interfacing Converters
file = [folder_config filesep() 'PWM_LCL_C_PI_VQ_1_Pn60k.xlsx'];
interfacing_converters(1) = PWM_LCL_C_PI_VQ.buildFromFile(file,unit_base,f_nominal); 

for r = 2:4
    file = [folder_config filesep() 'PWM_LCL_C_PI_PQ_' num2str(r) '_Pn60k.xlsx'];
    interfacing_converters(r) = PWM_LCL_C_PI_PQ.buildFromFile(file,unit_base,f_nominal); 
end

% --- Entire AC/DC system 
system = System(subsystem,interfacing_converters);

%%  Simulate TDS

V_h = struct();
I_h = struct(); 

% Simulation Workspace Parameter
PLL = struct('TsetPLL',0.5,'zeta',0.7);

% Thevenin Equivalent for TDS
TE = struct('h',slack.h,'bin',slack.E_h,'R',slack.R,'L',slack.L,'Name','VTE');
dist = TDSAnalysis.getWaveform(TE,0,time.Tend,f_nominal,time.Ts_HW);
spectrum = TDSAnalysis.getSpectrum(dist,50,time.Ts_HW,h_max);
THD = sqrt(sum(abs(2*slack.E_h(1,2:end)).^2))/abs(2*slack.E_h(1,1))*100; % Total harmonic distortion

% Switching Times 
T1_start = 0.03; % All CIDERs
T2_start = 0.2; % AC/DC converters between the two grids

% ------- Comment in/out for simulating/loading

[t_TDS_exc,t_TDS_prc,simOut] = system.runTimeDomainSimulation('TDS_ACDC_Microgrid','system',h_max,time.Ts_HW);

for n = 1: length(simOut{1})
    V_h_TDS{n,1} = simOut{1}(n).Y.VG.bin;
    I_h_TDS{n,1} = simOut{1}(n).Y.IG.bin;
end
V_h.TDS = cell2mat(V_h_TDS);
I_h.TDS = cell2mat(I_h_TDS);

for n = 1: length(simOut{2})
    Yo_h{n,1}.VAref = simOut{2}(n).Yo.VAref.bin;
    Yo_h{n,1}.IA    = simOut{2}(n).Yo.IA.bin;
    Yo_h{n,1}.VD    = simOut{2}(n).Yo.VD.bin;
end

save([folder_results filesep() 'TDS_' file_results '.mat'],'V_h','I_h','Yo_h','t_TDS_exc','t_TDS_prc')

% ------- 

load([folder_results filesep() 'TDS_' file_results '.mat'],'V_h','I_h','Yo_h','t_TDS_exc','t_TDS_prc');

% normalize
V_base = unit_base.getBaseVoltage;
I_base = unit_base.getBaseCurrent;

V_h.TDS = V_h.TDS(:,1:h_max+1) / V_base; 
I_h.TDS = I_h.TDS(:,1:h_max+1) / I_base; 

for n = 1: length(Yo_h)
    Yo_h{n,1}.VAref = Yo_h{n,1}.VAref(:,1:h_max+1) / V_base;
    Yo_h{n,1}.IA    = Yo_h{n,1}.IA(:,1:h_max+1) / I_base;
    Yo_h{n,1}.VD    = Yo_h{n,1}.VD(:,1:h_max+1) / V_base;
end

%% Simulate HPF

n_interfacing = length(system.interfacing_converters);

n_nodes_AC = length(system.subsystems(1).grid.nodes);
n_AC = system.subsystems(1).getNumberOfResources();
n_wires_AC = system.subsystems(1).grid.getNumberOfWires();

n_nodes_DC = length(system.subsystems(2).grid.nodes);
n_DC = system.subsystems(2).getNumberOfResources();
n_wires_DC = system.subsystems(2).grid.getNumberOfWires();

% Init
V_h.TDS(1:n_phases*n_nodes_AC,1) = 0;
V_h_0 = zeros(n_nodes_AC*n_wires_AC+n_nodes_DC*n_wires_DC,h_max+1);
I_h_0 = zeros(size(V_h_0));
O_V_h_0 = cell(n_AC.form,1);
O_I_h_0 = cell(n_AC.follow+n_interfacing,1);

V_h_0(1:n_nodes_AC*n_wires_AC,:) = initializeHarmonicPowerFlow(V_h_0(1:n_nodes_AC*n_wires_AC,:),n_phases,[1],0,h_max);
V_h_0(n_nodes_AC*n_wires_AC+1:end,1) = Vdc / V_base * ones(n_nodes_DC*n_wires_DC,1);

% V_h_0 = V_h.TDS;%
% I_h_0 = I_h.TDS;%


% Operating point of grid-following CIDERs - init (ordered w.r.t. CIDERs)
for k = 1:length(O_I_h_0)
    VAref_d = zeros(n_phases,h_max+1);
    IA_d    = zeros(n_phases,h_max+1);
    VD_d    = zeros(1,h_max+1);

    VAref_d = initializeHarmonicPowerFlow(VAref_d,n_phases,[1],0,h_max);
    IA_d    = initializeHarmonicPowerFlow(IA_d,n_phases,[1],0,h_max); % 1 pu for currents
    VD_d(:,h==0) = Vdc / V_base;

    O_I_h_0{k} = [VAref_d;IA_d;VD_d];
%     O_I_h_0{k} = cell2mat(struct2cell(Yo_h{k}));%
end

% Method
options = struct('maxIteration',100, ...
                 'tolerance',1e-8, ...
                 'alpha',1, ...
                 'kronReduction',1, ...
                 'slackMode','forming');
[V_f_HPF,I_f_HPF,n_HPF] = ...
            system.solveNewtonRaphson(time.Ts_SW,f_nominal,h_max, ...
                                      V_h_0,I_h_0,O_V_h_0,O_I_h_0, ...
                                      unit_base,options);
% results.time = timing(t_HPF,n_HPF,t_TDS_exc,t_TDS_prc,time,f_nominal);

V_h.HPF = V_f_HPF(:,:,end);
I_h.HPF = I_f_HPF(:,:,end);

disp('STOP');

% V_h.HPF(find(abs(V_h.HPF)<options.tolerance*1e2))=abs(V_h.HPF(find(abs(V_h.HPF)<options.tolerance*1e2)));
% I_h.HPF(find(abs(I_h.HPF)<options.tolerance*1e2))=abs(I_h.HPF(find(abs(I_h.HPF)<options.tolerance*1e2)));
% V_h.TDS(find(abs(V_h.TDS)<options.tolerance*1e2))=abs(V_h.TDS(find(abs(V_h.TDS)<options.tolerance*1e2)));
% I_h.TDS(find(abs(I_h.TDS)<options.tolerance*1e2))=abs(I_h.TDS(find(abs(I_h.TDS)<options.tolerance*1e2)));

%% Plot - AC
% copy plots after each run

figNr = 400;

idx_slack = 1:3;
n_follow = [5,9,11,13];
idx_follow = reshape((n_follow-1)*n_phases+[1:n_phases]',1,[]);
n_unbal = [3,14];
idx_unbal = reshape((n_unbal-1)*n_phases+[1:n_phases]',1,[]);
idx_form = [];
n_NIC = [15:18];
idx_NIC = reshape((n_NIC-1)*n_phases+[1:n_phases]',1,[]);

h_set = [1,5,7,11,13,17,19,23,25];

% Voltage and Current Errors of all grid-following resources
file_location = [folder_results filesep() file_results '_AC_error'];
semilog_Error(V_h,I_h,idx_follow,idx_NIC,h_set,h_max,{'$\mathcal{R}^{AC}_{1}$','$\mathcal{R}^{AC}_{2}$'},file_location,figNr+1);

[results.AC.errorV,results.AC.errorI] = accuracy(V_h,I_h,idx_follow,idx_NIC,h_set,h_max);

%% Plot nodes - AC
% copy plots after each run

h_set = [1,5,7,11,13,17,19,23,25];

% single nodes
for i = 5%[5,9,11,13]
%     file_location = [folder_results filesep() file_results '_IG_N',num2str(i)];
%     semilog_Resource(I_h.TDS,I_h.HPF,(1:n_phases)+(i-1)*n_phases,h_set,h_max,'I','A','\gamma',file_location,i+100);
end
for i = [3,14]
%     file_location = [folder_results filesep() file_results '_IG_N',num2str(i)];
%     semilog_Resource(I_h.TDS,I_h.HPF,(1:n_phases)+(i-1)*n_phases,h_set,h_max,'I','A','\gamma',file_location,i+100);
end
for i = 15%[15:18]
%     file_location = [folder_results filesep() file_results '_IG_N',num2str(i)];
%     semilog_Resource(I_h.TDS,I_h.HPF,(1:n_phases)+(i-1)*n_phases,h_set,h_max,'I','A','\gamma',file_location,i+100);
end

%% Plot -  DC side
% copy plots after each run

figNr = 500;

n_follow = [23,24,25,26];
idx_follow = n_nodes_AC*n_phases-n_nodes_AC+n_follow;
n_form = [19,20,21,22];
idx_form = n_nodes_AC*n_phases-n_nodes_AC+n_form;

h_set = [1,7,13,19,25]-1;


% Voltage and Current Errors
file_location = [folder_results filesep() file_results '_DC_error'];
semilog_Error(V_h,I_h,idx_follow,idx_form,h_set,h_max,{'$\mathcal{R}^{DC}_{1}$','$\mathcal{S}^{DC}_{2}$'},file_location,figNr+1);

[results.DC.errorV,results.DC.errorI] = accuracy(V_h,I_h,idx_follow,idx_form,h_set,h_max);

%% Plot nodes - DC
% copy plots after each run

h_set = [1,7,13,19,25]-1;

for i = 23%[23,24,25,26]
%     semilog_Resource(I_h.TDS,I_h.HPF,idx,h_set,h_max,'I','DC','\epsilon',['ACDC_System_I_N',num2str(i)],i+100);
end
for i = 19%[19,20,21,22]
%     semilog_Resource(V_h.TDS,V_h.HPF,idx,h_set,h_max,'V','DC','\delta',['ACDC_System_NICs_V_N',num2str(i)],i+100);
end
