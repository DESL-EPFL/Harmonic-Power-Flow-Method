function [W_K,dW_KP] = calculateReference(obj,W_P,theta_0,h_max,base)
% ...

import Harmonics.*;

%% Preparation

n_P = obj.LG_stage.dim_ph;%obj.power_hardware.getNumberOfDisturbances();
n_K = obj.LG_stage.dim_cs;%obj.control_software.getNumberOfDisturbances();

T_RP_h = [{obj.internal_transform.T_FW_h*exp(1i*theta_0)}]; 
T_RP_h = cell2mat(T_RP_h);
T_RP = Toeplitz.buildRectangularMatrix(obj.internal_transform.h,T_RP_h,h_max+1,h_max);

[h_P,W_P_h] = Fourier.splitVector(W_P,2*n_P+1);
W_R = T_RP * Fourier.buildVector(h_P,W_P_h(1:n_P,:));

%% Function value

% Grid current
% Step 1: Taylor approximation of 1/v_D(t)

VG_DQ = W_R;
[h_K,VG_DQ_h] = Fourier.splitVector(VG_DQ,n_K);
n_h = length(h_K)-1;

VG_D_h = VG_DQ_h;
VG_D_h(2,:) = VG_D_h(1,:); % Replace Q-components by D-components.
VG_D_0 = VG_D_h(:,1);

xi_h = diag(1./VG_D_0) * VG_D_h(:,2:end);
xi = Fourier.buildVector((1:n_h)',xi_h);

diag_xi_h = zeros(n_K,n_K,n_h);
for k=1:n_h
    diag_xi_h(:,:,k) = diag(xi_h(:,k));
end
diag_xi = Toeplitz.buildSquareMatrix((1:n_h)',diag_xi_h,n_h);

id = Fourier.buildVector([0;n_h],[ones(n_K,1),zeros(n_K,1)]);

% Taylor series (2nd order)
inv_VG_D = diag(1./repmat(VG_D_0,2*n_h+1,1)) * (id - xi + diag_xi * xi);

% Step 2: Calculation of IR_DQ = [P;Q] * 1/v_D

S_DQ = [obj.P_reference;-obj.Q_reference] / base.getBasePower();
S_DQ = repmat(S_DQ,2*n_h+1,1);

IG_DQ = S_DQ .* inv_VG_D;
[h_K,IG_DQ_h] = Fourier.splitVector(IG_DQ,n_K);

% Choose only Q component
% warning('Inefficient computation. I_D_ref not needed.')
IG_Q_ref_h = IG_DQ_h(2,:);

% DC voltage reference
VD_ref_h = zeros(size(IG_Q_ref_h));
VD_ref_h(:,h_K==0) = obj.Vdc_reference/base.getBaseVoltage();

W_K_h = [IG_Q_ref_h;VD_ref_h];
W_K = Fourier.buildVector((0:n_h)',W_K_h);

%% Jacobian matrix

S_DQ = [obj.P_reference*0;-obj.Q_reference] / base.getBasePower();

% Extract V_d components
idx_D = 1:n_K:length(VG_DQ);
VG_D_h = VG_DQ(idx_D);
T_D_h = T_RP(idx_D,:);

idx_D_0 = n_h+1;
VG_D_0 = VG_D_h(idx_D_0);
T_D_0 = T_D_h(idx_D_0,:);

dIGdq_dVGabc = zeros(size(T_RP,1)/2,size(T_RP,2));

j = 1:2;
for k = 1:length(idx_D)
    if k == idx_D_0
        dIGdq_dVGabc(j,:) = -S_DQ/(VG_D_0^2) * T_D_0;
    else    
        dIGdq_dVGabc(j,:) = -S_DQ/(VG_D_0^2) * (T_D_h(k,:)-2*VG_D_h(k)/VG_D_0 * T_D_0);
    end
    j = j+2;
end

[~,dIGdq_dVG_h] = Fourier.splitMatrix(dIGdq_dVGabc,n_K,n_P);

dIGq_dVG_h = dIGdq_dVG_h(2,:,:,:);
dVD_dVG_h = zeros(size(dIGq_dVG_h));

dIGq_dIE_h = zeros([size(dIGq_dVG_h,1),1,size(dIGq_dVG_h,[3,4])]);
dVD_dIE_h = zeros(size(dIGq_dIE_h));

dIGq_dVAref_h = zeros(size(dIGq_dVG_h));
dVD_dVAref_h = zeros(size(dIGq_dVG_h));

dW_KP_h = [dIGq_dVG_h,dIGq_dIE_h,dIGq_dVAref_h;...
           dVD_dVG_h,dVD_dIE_h,dVD_dVAref_h];

dW_KP = Fourier.buildMatrix(dW_KP_h,2,7);

end