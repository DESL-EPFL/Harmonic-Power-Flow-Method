classdef Node
    properties(SetAccess=private)
        name;
    end
    
    methods
        function obj = Node(name)
            % obj = Node(name)
            
            if(~isa(name,'char'))
                error('name: type');
            else
                obj.name = name;
            end
        end
    end
    
    methods(Static)
        nodes = buildFromFile(folder,file);
        [found,index] = findByName(nodes,name);
    end
end