function nodes = buildFromFile(folder,file)
% nodes = buildFromFile(folder,file)

import Harmonics.Grid.*;

error('Function is deprecated.');

if(~isa(folder,'char'))
    error('folder: type.');
elseif(~isa(file,'char'))
    error('file: type.');
else
    % read
    
    [numeric,text,raw] = xlsread([folder filesep() file],'Nodes');
    
    names = raw(2:end,1);
    
    % build
    
    nodes = cell(length(names),1);
    
    for i=1:length(nodes)
        nodes{i} = Node(names{i});
    end
    
    nodes = [nodes{:}];
end

end