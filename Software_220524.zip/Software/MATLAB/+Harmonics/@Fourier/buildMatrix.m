function M = buildMatrix(M_h,n_y,n_x)
% [h,M_h] = splitMwatrix(M,n_x)
%
% INPUT
%   M       Matrix in Fourier spectrum Y = M*X.
%   n_y     Number of output variables (i.e., elements of y(t)).
%   n_x     Number of state variables (i.e., elements of x(t)).
%
% OUTPUT
%   h       Harmonic orders h>=0 (column vector).
%   M_h     Matrix of Fourier coefficients (rows=output-variables,
%           columns=state-variables, 3th and 4th dimesion harmonic
%           couplings).

if(~isa(M_h,'numeric'))
    error('M: type.');
% elseif(~isa(n_y,'numeric'))
%     error('n_y: type.');
% elseif(~isa(n_x,'numeric'))
%     error('n_x: type.');
else
%     if(size(n_y)~=1)
%         error('n_y: size.');
%     elseif(size(n_x)~=1)
%         error('n_x: size.');
%     else
    hy_max = size(M_h,3)-1;
    hx_max = size(M_h,4)-1;

    if(mod(hy_max,1)~=0)
        error('M: number of output-variables/harmonics.');
    elseif(mod(hx_max,1)~=0)
        error('M: number of state-variables/harmonics.');
    else
        % Negative spectrum added (assuming conjugate symmetry)
        hy = 0:hy_max;
        hx = 0:hx_max;
        h_y0 = hy_max+1;
        h_x0 = hx_max+1;
        
        M = repmat({zeros(n_y,n_x)},2*hy_max+1,2*hx_max+1);
        
        for i = 1:hy_max+1
            h_i = hy(i);
            
            for j = 1:hx_max+1
                h_j = hx(j);
                
                if (h_i == 0) && (h_j == 0)
                    M{h_y0,h_x0} = M_h(:,:,i,j);
                else
                    M{h_y0+h_i,h_x0+h_j} = M_h(:,:,i,j);
                    M{h_y0-h_i,h_x0-h_j} = conj(M_h(:,:,i,j));
                end
            end
        end
        
        M = cell2mat(M);
    end
        
%     end
end

end