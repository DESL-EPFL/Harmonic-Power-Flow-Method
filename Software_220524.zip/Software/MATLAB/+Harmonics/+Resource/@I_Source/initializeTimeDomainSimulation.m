function [] = initializeTimeDomainSimulation(obj,modelName,converterName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

nodeName = obj.node;
nodeName_index = [nodeName,'_',num2str(obj.index)];
blockName = [modelName,'/',nodeName,'/',nodeName_index,'/','I_Source'];

set_param(blockName,'I_reference',[converterName,'.I_reference']);

end