function semilog_Resource_3Nodes(X_h,idx,h,h_max,quantityStr,phaseStr,titleStr,fileStr,fig)

% set color scheme
color_1 = 'b';%'k';
color_2 = 'r';%0.7*[1,1,1];

figure(fig);
clf;
set(groot,'defaultAxesTickLabelInterpreter','latex');  

if strcmp(phaseStr,'A')
    phase = 1;
elseif strcmp(phaseStr,'B')
    phase = 2;
else
    phase = 3;
end

x = 0:h_max;

% Magnitude - Absolut Values

for i = 1:3
    % Factor 2 because of Fourier coefficients (positive/negative spectrum).
    X_abs_1 = 2*abs(X_h.HPF_DC(idx{i},:));
    X_abs_2 = 2*abs(X_h.HPF(idx{i},:));
    y_abs = [X_abs_1(phase,:);X_abs_2(phase,:)]; % show one phase only
    
    h_plot(i) = subplot(2,3,i);
    
    if i == 1
        h_plot(i).Position = h_plot(i).Position + [-0.05 0.01 0.07 -0.01];
    elseif i == 2
        h_plot(i).Position = h_plot(i).Position + [-0.02 0.01 0.07 -0.01];
    elseif i == 3
        h_plot(i).Position = h_plot(i).Position + [+0.01 0.01 0.07 -0.01];
    end

%     b = bar(x',y_abs','LineWidth',0.01);
    b = bar(x(:,2:2:end)',y_abs(:,2:2:end)','LineWidth',0.01);
    b(1).FaceColor = color_1;
    b(2).FaceColor = color_2;
    ax = gca;
    grid(gca,'on');
    set(gca, 'YScale', 'log');
    ax.MinorGridAlpha = 0.1;
    xlim([-0.5,h_max+0.5]);
    ylim([1e-7,1.5e0]);
    set(gca,'XTick',[1:6:h_max]);
    set(gca,'YTick',10.^[-6:2:0]);
    if i == 1
        legend({'HPF-DC','HPF'},'interpreter','latex','location','southwest');
        yticklabels({'1E-6','1E-4','1E-2','1E+0'})
    else
        yticklabels({})
    end
    title([titleStr{i},': $|',quantityStr,'_{h,',phaseStr,'}|$ (p.u.)'],'interpreter','latex');
end   

% Angle - Absolut Values


for i = 1:3
    X_arg_1 = angle(X_h.HPF_DC(idx{i},:))*180/pi;
    X_arg_2 = angle(X_h.HPF(idx{i},:))*180/pi;
    y_arg = [X_arg_1(phase,:);X_arg_2(phase,:)]; % show one phase only
    y_arg(:,setdiff([0:h_max],h)'+1) = 0;
    y_arg(find(y_arg>179)) = y_arg(find(y_arg>179))-2*180;

    y_arg = y_arg*pi/180; % convert to rad
    
    h_plot(2+i) = subplot(2,3,3+i);
    
    if i == 1
        h_plot(2+i).Position = h_plot(2+i).Position + [-0.05 0.01 0.07 -0.01];
    elseif i == 2
        h_plot(2+i).Position = h_plot(2+i).Position + [-0.02 0.01 0.07 -0.01];
    elseif i == 3
        h_plot(2+i).Position = h_plot(2+i).Position + [+0.01 0.01 0.07 -0.01];
    end

%     b = bar(x',y_arg','LineWidth',0.01);
    b = bar(x(:,2:2:end)',y_arg(:,2:2:end)','LineWidth',0.01);
    b(1).FaceColor = color_1;
    b(2).FaceColor = color_2;
%     axis([-0.5,h_max+0.5,-200,200]);
%     set(gca,'YTick',-180:90:180);
    axis([-0.5,h_max+0.5,-pi-0.1,pi+0.1]);
    set(gca,'YTick',-pi:pi/2:pi);
    set(gca,'XTick',[1:6:h_max]);
    grid(gca,'on');
    if i == 1
%         yticklabels({'-180','-90','0','90','180'})
        yticklabels({'$-\pi$','$-\frac{\pi}{2}$','$0$','$\frac{\pi}{2}$','$\pi$'})
    else
        yticklabels({})
    end
       
    title([titleStr{i},': $\angle ',quantityStr,'_{h,A}$ (rad)'],'interpreter','latex');
    xlabel('Harmonic Order (h)','interpreter','latex');

end   

set(gcf,'PaperUnits','points');
set(gcf,'PaperSize',[350,240]);
set(gcf,'PaperPosition',[0,0,350,240]);

saveas(gcf,fileStr,'pdf');

end