classdef CIR_V < Harmonics.Resource.CIR
    % CIR_V is a grid-forming Converter-Interfaced Resource (CIR).
    
    properties
        %
    end
    
    methods
        function obj = CIR_V(node,index,power_hardware,control_software,internal_transform,external_transform)
            % obj = CIR(node,power_hardware,control_software,transform)
            
            import Harmonics.Resource.*;
            
            obj = obj@Harmonics.Resource.CIR(node,index,power_hardware,control_software,internal_transform,external_transform);
            
        end
    end
    
    methods(Abstract)
        %
    end
    
    methods(Abstract,Static)
        %
    end
end