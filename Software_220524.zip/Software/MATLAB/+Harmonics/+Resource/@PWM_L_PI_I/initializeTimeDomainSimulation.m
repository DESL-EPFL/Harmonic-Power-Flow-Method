function [] = initializeTimeDomainSimulation(obj,modelName,converterName,variantName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

nodeName = obj.node;
nodeName_index = [nodeName,'_',num2str(obj.index)];
blockName = [modelName,'/',nodeName,'/',nodeName_index,'/',variantName];

if strcmp(variantName,"CIDER")
    set_param(blockName,'L_Stage',[converterName,'.L_stage']);
    set_param(blockName,'Iabs_reference',[converterName,'.Iabs_reference']);
    set_param(blockName,'Iarg_reference',[converterName,'.Iarg_reference']);
else
    set_param(blockName,'Iabs_reference',[converterName,'.Iabs_reference']);
    set_param(blockName,'Iarg_reference',[converterName,'.Iarg_reference']);
end

end