classdef Line
    properties(SetAccess=private)
        name;
        node_from;
        node_to;
        length;
    end
    
    methods
        function obj = Line(name,node_from,node_to,length)
            % obj = Line(name,node_from,node_tolength)
            import Harmonics.Grid.*;
            
            if(~isa(name,'char'))
                error('name: type.');
            elseif(~isa(node_from,'char'))
                error('node_from: type.');
            elseif(~isa(node_to,'char'))
                error('node_to: type.');
            elseif(~isa(length,'numeric'))
                error('length: type.');
            else
                obj.name = name;
                obj.node_from = node_from;
                obj.node_to = node_to;
                obj.length = length;
            end
        end
        
    end
    methods(Abstract)
        initializeTimeDomainSimulation(obj,inputs);
    end
    
    methods(Abstract,Static)
        [outputs] = findByName(inputs);
        [outputs] = buildPiSectionEquivalent(inputs);
    end
end