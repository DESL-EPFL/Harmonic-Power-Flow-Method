function [] = initializeTimeDomainSimulation(obj,modelName,gridName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

for l = 1:obj.getNumberOfLines
    set_param([modelName,filesep(),'L',num2str(l)],'Li',[gridName,'.lines(1,',num2str(l),')']);
end

end