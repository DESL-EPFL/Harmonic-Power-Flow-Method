function [R,L,G,C] = buildPiSectionEquivalent(lines,n_phases,n_lines,base)
% grid = buildFromFile(file,base)

import Harmonics.*;
import Harmonics.Grid.*;

% if(~isa(file,'char'))
%     error('file: type.');
% elseif(~isa(base,'Base'))
%     error('base: type.');
% else

    Z_base = base.getBaseImpedance();
    Y_base = base.getBaseAdmittance();
    
    R = repmat({zeros(n_phases,n_phases)},n_lines,n_lines);
    L = repmat({zeros(n_phases,n_phases)},n_lines,n_lines);
    G = repmat({zeros(n_phases,n_phases)},n_lines,n_lines);
    C = repmat({zeros(n_phases,n_phases)},n_lines,n_lines);

    for l = 1:length(lines)
        
        R_pn = lines(l).R_pn .* lines(l).length / Z_base;
        R_0  = lines(l).R_0 .* lines(l).length / Z_base;
        L_pn = lines(l).L_pn .* lines(l).length / Z_base;
        L_0  = lines(l).L_0 .* lines(l).length / Z_base;
        C_pn = lines(l).C_pn .* lines(l).length / Y_base;
        C_0  = lines(l).C_0 .* lines(l).length / Y_base;

        % Lines

        R_s = 1/3 * (R_0 + 2*R_pn);
        R_m = 1/3 * (R_0 - R_pn);
        L_s = 1/3 * (L_0 + 2*L_pn);
        L_m = 1/3 * (L_0 - L_pn);
        G_s = zeros(3,3);
        G_m = zeros(3,3);
        C_s = 1/3 * (C_0 + 2*C_pn);
        C_m = 1/3 * (C_0 - C_pn);
   
        R{l,l} = R_s * eye(3) + R_m * (ones(3,3)-eye(3));
        L{l,l} = L_s * eye(3) + L_m * (ones(3,3)-eye(3));
        G{l,l} = G_s * eye(3) + G_m * (ones(3,3)-eye(3));
        C{l,l} = C_s * eye(3) + C_m * (ones(3,3)-eye(3));
    end
    
% end

end