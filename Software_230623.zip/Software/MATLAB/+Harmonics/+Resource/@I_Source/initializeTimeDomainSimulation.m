function [] = initializeTimeDomainSimulation(obj,modelName,converterName)
% [] = initializeTimeDomainSimulation(obj,modelName,subSysName)
%
% INPUT
%   
% OUTPUT
%

nodeName = obj.node;
nodeName_index = [nodeName,'_',num2str(obj.index)];
blockName = [modelName,filesep(),nodeName,filesep(),nodeName_index,filesep(),'I_Source'];

set_param(blockName,'I_reference',[converterName,'.I_reference']);

    
% set_param([modelName,filesep(),'y_',nodeName],'VariableName',['y_',nodeName]);

end