clear all;
close all;
clc;

disp('START');

import Harmonics.*;
import Harmonics.Grid.*;
import Harmonics.Resource.*;

% Parameters

f_nominal = 50;
h_max = 25;
P_base = 100e3;
V_base = 230*sqrt(2);
unit_base = Base(P_base,V_base); % HPF in nominal values

h = (0:1:h_max)';
time = struct('Ts_HW',5e-06,'Ts_SW',5e-06,'Tend',2); % in (s)

%%  Prepare

folder = '/Users/johanna/EPFL GDrive/GIT/Software/';

folder_config = [folder filesep() 'Configuration Files'];
folder_results = [folder filesep() 'Results' filesep() 'Resources'];

file_results = 'RLC_P_Load_h25';


file = [folder_config filesep() 'RLC_P_Load.xlsx'];
passive_load = RLC_P_Load.buildFromFile(file,unit_base,f_nominal);

file = [folder_config filesep() 'TE_resource.xlsx']; % needed for TDS
slack = Thevenin.buildFromFile(file);

%%  Simulate TDS

VG_h = struct();
IG_h = struct();
VA_h = struct();

% Simulation Workspace Parameter

% Thevenin Equivalent for TDS
TE = struct('h',slack.h,'bin',slack.E_h,'R',slack.R,'L',slack.L,'Name','VTE');
dist = TDSAnalysis.getWaveform(TE,0,time.Tend,f_nominal,time.Ts_HW);
THD = sqrt(sum(abs(2*slack.E_h(1,2:end)).^2))/abs(2*slack.E_h(1,1))*100 % Total harmonic distortion

% ------- Comment in/out for simulating/loading
 
[simOut] = passive_load.runTimeDomainSimulation(folder,'TDS_RLC_P_Load','passive_load','Passive',h_max+1,time.Ts_HW);

VG_h.TDS = simOut.Y.VG.bin(:,1:h_max+1);
IG_h.TDS = simOut.Y.IG.bin(:,1:h_max+1);

save([folder_results filesep() 'TDS_' file_results '.mat'],'VG_h','IG_h')

% ------- 

% load TDS from matfile
load([folder_results filesep() 'TDS_' file_results '.mat'])

% normalize
V_base = unit_base.getBaseVoltage;
I_base = unit_base.getBaseCurrent;
VG_h.TDS = VG_h.TDS / V_base;
IG_h.TDS = IG_h.TDS / I_base;

%% Simulate HPF 

[IG_h.HPF] = passive_load.calculateGridResponse(f_nominal,h_max,VG_h.TDS,unit_base);

%% Check - Power Setpoints

Pref = passive_load.P_reference / P_base;
Qref = passive_load.Q_reference / P_base;

S_TDS = 2*VG_h.TDS(:,2)/sqrt(2) .* conj(2*IG_h.TDS(:,2)/sqrt(2));
P_TDS = sum(real(S_TDS));
Q_TDS = sum(imag(S_TDS));

S_HPF = 2*VG_h.TDS(:,2)/sqrt(2) .* conj(2*IG_h.HPF(:,2)/sqrt(2));
P_HPF = sum(real(S_HPF));
Q_HPF = sum(imag(S_HPF));

ref = [Pref,Qref,0,0];
TDS = [P_TDS,Q_TDS,Pref-P_TDS,Qref-Q_TDS];
HPF = [P_HPF,Q_HPF,Pref-P_HPF,Qref-Q_HPF];
data = [ref(:),TDS(:),HPF(:)];
names = {'Ref','TDS','HPF'};
rowNames = {'P','Q','dP','dQ'};
powers = table(data(:,1),data(:,2),data(:,3),'VariableNames',names,'RowNames',rowNames)

%% Plot

h_set = [1,5,7,11,13,17,19,23,25];

file_location = [folder_results filesep() file_results '_IG'];
[h_abs,max_abs,h_arg,max_arg] = semilog_Resource(IG_h.TDS,IG_h.HPF,(1:3),h_set,h_max,'I','A','\gamma',file_location,1);

%%  Analyze

disp(' ');
disp('##########');
disp(' ');

e_IG = analyseSpectra(h,IG_h.HPF,IG_h.TDS);
d_IG = sum(abs(IG_h.HPF-IG_h.TDS).^2)/sum(abs(IG_h.TDS).^2);

disp('Results: IG_h (HPF vs. TDS)');
disp(' ');
disp(e_IG);
disp(['PSD: ',num2str(d_IG)]);
disp(' ');

