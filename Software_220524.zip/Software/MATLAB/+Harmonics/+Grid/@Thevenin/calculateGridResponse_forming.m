function [V_h,dVh_dIh] = calculateGridResponse_forming(obj,f_1,h,I_h,base)

import Harmonics.*;

% if(max(obj.h)>max(h))
%     error('h: range of harmonics is incompatible.');
% else
    h_max = max(h);%max(max(obj.h),max(h));
    
    % Base Values
    V_base = base.getBaseVoltage();
    Z_base = base.getBaseImpedance();
    
    E_h = obj.E_h / V_base;
    E_h = Fourier.complete(obj.h,E_h,h_max);
    I_h = Fourier.complete(h,I_h,h_max);
    
    R = obj.R * eye(3) / Z_base;
    L = obj.L * eye(3) / Z_base;
    
    Z_h = zeros(3,3,h_max+1,h_max+1);
    for k=1:h_max+1
        Z_h(:,:,k,k) = R + 1i*2*pi*f_1*(k-1)*L;
    end
    
    V_h = zeros(3,h_max+1);
    for k=1:(h_max+1) % no coupling between harmonics
        V_h(:,k) = -Z_h(:,:,k,k) * I_h(:,k) + E_h(:,k);
    end

    dVh_dIh = -Z_h;
% end

end