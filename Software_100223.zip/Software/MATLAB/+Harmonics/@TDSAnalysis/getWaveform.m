function signal = getWaveform(FT,Tstart,Tend,f_1,Ts)

t = Tstart : Ts : Tend;
t = t(1:end-1);

wave = zeros(size(FT.bin,1),length(t));
   
for i = 1:length(FT.h)
    h = FT.h(i);
    amp = abs(FT.bin(:,i));
    arg = angle(FT.bin(:,i));
    if h == 0
        wave = wave + amp .* cos(2*pi*f_1*h * repmat(t,size(FT.bin,1),1) + arg);  
    else
        wave = wave + 2 * amp .* cos(2*pi*f_1*h * repmat(t,size(FT.bin,1),1) + arg); 
    end
end

signal = timeseries(wave',t,'Name',FT.Name);     

end