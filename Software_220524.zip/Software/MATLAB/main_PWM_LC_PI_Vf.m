clear all;
% close all;
clc;

disp('START');

import Harmonics.*;
import Harmonics.Grid.*;
import Harmonics.Resource.*;

% Parameters

f_nominal = 50;
h_max = 25;
P_base = 100e3;
V_base = 230*sqrt(2);
unit_base = Base(P_base,V_base); % HPF in nominal values

h = (0:1:h_max)';

time = struct('Ts_HW',1e-06,'Ts_SW',1e-06,'Tend',2); % in (s)

%%  Prepare

folder = '/Users/johanna/EPFL GDrive/GIT/Software/';

folder_config = [folder filesep() 'Configuration Files'];
folder_results = [folder filesep() 'Results' filesep() 'Resources'];

file_results = 'PWM_LC_PI_VF_h25';


file = [folder_config filesep() 'PWM_LC_PI_VF_Pn40k.xlsx'];
converter_forming = PWM_LC_PI_VF.buildFromFile(file,unit_base);

file = [folder_config filesep() 'TE_resource.xlsx']; % needed for TDS
slack = Thevenin.buildFromFile(file);

%%  Simulate TDS

IG_h = struct();
VG_h = struct();
IA_h = struct();
VA_h = struct();

% Simulation Workspace Parameter
Vdc = 900;

% Thevenin Equivalent for TDS
TE = struct('h',slack.h,'bin',slack.E_h,'R',slack.R,'L',slack.L,'Name','VTE');
dist = TDSAnalysis.getWaveform(TE,0,time.Tend,f_nominal,time.Ts_HW);
THD = sqrt(sum(abs(2*slack.E_h(1,2:end)).^2))/abs(2*slack.E_h(1,1))*100 % Total harmonic distortion

% ------- Comment in/out for simulating/loading

[simOut] = converter_forming.runTimeDomainSimulation(folder,'TDS_PWM_LC_PI_Vf','converter_forming',h_max+1,time.Ts_HW);

IG_h.TDS = simOut.Y.IG.bin(:,1:h_max+1);
VG_h.TDS = simOut.Y.VG.bin(:,1:h_max+1);
IA_h.TDS = simOut.Y.IA.bin(:,1:h_max+1);
VA_h.TDS = simOut.Y.VA.bin(:,1:h_max+2);

save([folder_results filesep() 'TDS_' file_results '.mat'],'VG_h','IG_h','IA_h','VA_h')

% ------- 

% load TDS from matfile
load([folder_results filesep() 'TDS_' file_results '.mat'])

% normalize
V_base = unit_base.getBaseVoltage;
I_base = unit_base.getBaseCurrent;
IG_h.TDS = IG_h.TDS / I_base;
VG_h.TDS = VG_h.TDS / V_base;
IA_h.TDS = IA_h.TDS / I_base;
VA_h.TDS = VA_h.TDS / V_base;

%% Simulate HPF 

V_ref = converter_forming.V_reference;
VR_h = V_ref * 1/2 * exp(1i*[0;-2*pi/3;+2*pi/3]);
VR_h = [zeros(3,1),VR_h,zeros(3,h_max-1)];

[VA_h.HPF,IA_h.HPF,VG_h.HPF] = converter_forming.calculateInternalResponse(time.Ts_SW,f_nominal,h,IG_h.TDS,unit_base);

%% Plot

h_set = [1,5,7,11,13,17,19,23];

file_location = [folder_results filesep() file_results '_VG'];
[h_abs,max_abs,h_arg,max_arg] = semilog_Resource(VG_h.TDS,VG_h.HPF,(1:3),h_set,h_max,'V','A','\gamma',file_location,1);

%%  Analyze

disp(' ');
disp('##########');
disp(' ');

e_VG = analyseSpectra(h,VG_h.HPF,VG_h.TDS);
d_VG = sum(abs(VG_h.HPF-VG_h.TDS).^2)/sum(abs(VG_h.TDS).^2);

disp('Results: VG_h (HPF vs. TDS)');
disp(' ');
disp(e_VG);
disp(['PSD: ',num2str(d_VG)]);
disp(' ');

e_IA = analyseSpectra(h,IA_h.HPF,IA_h.TDS);
d_IA = sum(abs(IA_h.HPF-IA_h.TDS).^2)/sum(abs(IA_h.TDS).^2);

disp('Results: IA_h (HPF vs. TDS)');
disp(' ');
disp(e_IA);
disp(['PSD: ',num2str(d_IA)]);
disp(' ');

e_VA = analyseSpectra([h;h_max+1],VA_h.HPF,VA_h.TDS);
d_VA = sum(abs(VA_h.HPF-VA_h.TDS).^2)/sum(abs(VA_h.TDS).^2);

disp('Results: VA_h (HPF vs. TDS)');
disp(' ');
disp(e_VA);
disp(['PSD: ',num2str(d_VA)]);
disp(' ');

disp('STOP');