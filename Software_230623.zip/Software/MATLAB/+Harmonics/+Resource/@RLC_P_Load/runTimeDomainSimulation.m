function [simOut] = runTimeDomainSimulation(obj,folder,modelName,converterName,variantName,h_max,Ts)
% [] = runTimeDomainSimulation()
%
% INPUT
%   
% OUTPUT
%

import Harmonics.*

open_system([folder,'/MATLAB/Simulink/Resources/',modelName]);

% Initialize
obj.initializeTimeDomainSimulation(modelName,converterName,variantName);

% Simulate
% sim( mymodel, 'SrcWorkspace', 'current')
simOut = sim(modelName,'ReturnWorkspaceOutputs','on');
y = simOut.y;
    
% Fourier analysis
N_periods = 5;
f_nominal = 50;
window = N_periods*1/f_nominal;
%s 5 periods

y.vG = TDSAnalysis.windowingFcn(y.vG,Ts,window);
y.iG = TDSAnalysis.windowingFcn(y.iG,Ts,window); % what about other windowing fcn
y.vF = TDSAnalysis.windowingFcn(y.vF,Ts,window);
y.iA = TDSAnalysis.windowingFcn(y.iA,Ts,window);
y.vA = TDSAnalysis.windowingFcn(y.vA,Ts,window);

Y.VG = TDSAnalysis.getSpectrum(y.vG,f_nominal,Ts,h_max);
Y.IG = TDSAnalysis.getSpectrum(y.iG,f_nominal,Ts,h_max);
Y.VF = TDSAnalysis.getSpectrum(y.vF,f_nominal,Ts,h_max);
Y.IA = TDSAnalysis.getSpectrum(y.iA,f_nominal,Ts,h_max);
Y.VA = TDSAnalysis.getSpectrum(y.vA,f_nominal,Ts,h_max);

simOut = struct('y',y,'Y',Y);

end