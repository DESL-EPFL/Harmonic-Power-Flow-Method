classdef Thevenin
    properties(SetAccess=private)
        node;
        h;
        E_h;
        R;
        L;
    end
    
    methods
        function obj = Thevenin(node,h,E_h,R,L)
            % obj = Thevenin(node,h,E_h,R,L)
            import Harmonics.Resource.*;
            
            if(~isa(node,'char'))
                error('node: type.');
            elseif(~isa(h,'numeric'))
                error('h: type.');
            elseif(~isa(E_h,'numeric'))
                error('E_h: type.');
            elseif(~isa(R,'numeric'))
                error('R: type.');
            elseif(~isa(L,'numeric'))
                error('L: type.');
            elseif(~all(size(E_h)==[3,length(h)]))
                error('E_h: size.');
%             elseif(~all(size(R)==3))
%                 error('R: size.');
%             elseif(~all(size(L)==3))
%                 error('L: size.')
            else
            
                obj.node = node;
                obj.h = h;
                obj.E_h = E_h;
                obj.R = R;
                obj.L = L;
                
            end
        end
        
        I_h = calculateResponse(obj,f_1,h,V_h,base);
        [Ih,dIh_dVh] = calculateGridResponse(obj,f_1,h,V_h,base);
        [Vh,dVh_dIh] = calculateGridResponse_forming(obj,f_1,h,I_h,base);
    end
    
    methods(Static)
        thevenin = buildFromFile(E_h,R,L);
    end
end

