function [V_h,I_h,n_iter,t_exec] = solveNewtonRaphson(obj,Ts,f_1,h_max,V_h_0,I_h_0,O_V_h_0,O_I_h_0,base,options)
%SOLVENEWTONRAPHSON Summary of this function goes here
%   Detailed explanation goes here

import Harmonics.*;
import Harmonics.Grid.*;
import Harmonics.Resource.*;
import Harmonics.System.*;

timer = tic();

disp('HPF (Newton-Raphson): start.');
disp(' ');

h = transpose(0:1:h_max);
f = f_1 * h;

%% Kron Reduction & Hybrid Parameters

n_phases = obj.grid.getNumberOfWires();
n_nodes = length(obj.grid.nodes);

% Sets of grid-forming and grid-following nodes
n     = obj.getNumberOfResources();
nodes = obj.getNodePartition();

% slack
if strcmp(options.slackMode,'forming')
    nodes_1 = [nodes.slack,nodes.form];
    nodes_2 = unique([nodes.follow,nodes.passive]);
else
    nodes_1 = [nodes.form];
    nodes_2 = unique([nodes.slack,nodes.follow,nodes.passive]);
end

% Admittance Matrix
Y_h_full = obj.grid.buildAdmittanceMatrix(f,base);

% Reduction
if options.kronReduction == 1 %strcmp('Reduced',options.unRed)
    nodes_3 = [];

    n_nodes_kron = length([nodes_1,nodes_2]);
    Y_h_kron = KronTechnique.reduce(Y_h_full,[nodes_1,nodes_2]',n_phases);
    
    nodes_1_kron = 1:length(nodes_1);
    nodes_2_kron = length(nodes_1)+(1:length(nodes_2));
    nodes_3_kron = [];
    
else
    nodes_3 = nodes.internal;

    n_nodes_kron = length([nodes_1,nodes_2,nodes_3]);
    Y_h_kron = Y_h_full;
    
    nodes_1_kron = nodes_1;
    nodes_2_kron = nodes_2;
    nodes_3_kron = nodes_3;
    
end

nodes.S = nodes_1;
nodes.R = [nodes_2,nodes_3];

nodes_red.S = [nodes_1_kron];
nodes_red.R = [nodes_2_kron,nodes_3_kron];

% Hybrid matrix
[H_h.SS,H_h.SR,H_h.RS,H_h.RR] = obj.grid.buildHybridMatrix(Y_h_kron,nodes_red.S,nodes_red.R,f); % opposite to fixed-point

%% Initialization

itr_max = options.maxIteration;

% Init (i = 1)
% Nodal quantities
ISh = zeros(n_phases*length(nodes_red.S),h_max+1,itr_max+1);
VRh = zeros(n_phases*length(nodes_red.R),h_max+1,itr_max+1);

VSh_res = ISh;
IRh_res = VRh;
VSh_grd = VSh_res;
IRh_grd = IRh_res;

Ih_0 = mat2cell(I_h_0,n_phases*ones(n_nodes,1),h_max+1);
Vh_0 = mat2cell(V_h_0,n_phases*ones(n_nodes,1),h_max+1);

ISh(:,:,1) = cell2mat(Ih_0(nodes.S));
VSh(:,:,1) = cell2mat(Vh_0(nodes.S));
IRh(:,:,1) = cell2mat(Ih_0(nodes.R));
VRh(:,:,1) = cell2mat(Vh_0(nodes.R));

% Operating point
if isa(obj,'AC_Subsystem')
    O_V_h = O_V_h_0;
    O_I_h = O_I_h_0;
else
    O_V_h = [];
    O_I_h = [];
end

dx_max = zeros(itr_max+1,1);
df_max = zeros(itr_max+1,1);
% cond_df_dx = zeros(itr_max+1,1);

dx_met = 0;
df_met = 0;

%% Newton Raphson

for i=(1:itr_max)+1
    disp('***');
    disp(['Newton-Raphson method: iteration ' int2str(i-1)]);
    
    %% Resources
   

    [VS_h,IR_h,dVSh_dISh,dIRh_dVRh,O_V_h,O_I_h] = ...
        obj.calculateResourceQuantities(Ts,f_1,h_max,...
            ISh(:,:,i-1),VRh(:,:,i-1),O_V_h,O_I_h,nodes,base,options);
    
    VSh_res(:,:,i) = VS_h;
    IRh_res(:,:,i) = IR_h;

    dVSh_dISh_res = dVSh_dISh;
    dIRh_dVRh_res = dIRh_dVRh;
    dVSh_dVRh_res = zeros(size(dVSh_dISh_res,1),size(dIRh_dVRh_res,2),h_max+1,h_max+1);
    dIRh_dISh_res = zeros(size(dIRh_dVRh_res,1),size(dVSh_dISh_res,2),h_max+1,h_max+1);

    %% Grid

    for k=1:length(f) % no coupling between harmonics
        VSh_grd(:,k,i) = H_h.SS(:,:,k,k)*ISh(:,k,i-1) + H_h.SR(:,:,k,k)*VRh(:,k,i-1);
        IRh_grd(:,k,i) = H_h.RS(:,:,k,k)*ISh(:,k,i-1) + H_h.RR(:,:,k,k)*VRh(:,k,i-1);
    end

    %% Mismatch
        
    % df
    f_h_res = [VSh_res(:,:,i);IRh_res(:,:,i)];
    f_h_grd = [VSh_grd(:,:,i);IRh_grd(:,:,i)];
    
    df_h = f_h_res-f_h_grd;
    df = Fourier.buildVector(h,df_h);
    
    % Jacobian
    df_dx_h_res = [dVSh_dISh_res,dVSh_dVRh_res;dIRh_dISh_res,dIRh_dVRh_res];
    df_dx_h_grd = [H_h.SS,H_h.SR;H_h.RS,H_h.RR];

    df_dx_h = -df_dx_h_res + df_dx_h_grd;
    df_dx = Fourier.buildMatrix(df_dx_h,size(df_dx_h,1),size(df_dx_h,2));

%     cond(df_dx)

    dx = df_dx \ df * options.alpha;
    length_x = n_phases*length([nodes.S,nodes.R]);
    [~,dx_h] = Fourier.splitVector(dx,length_x);


    dISh = dx_h(1:n_phases*length(nodes_red.S),:);
    dVRh = dx_h(n_phases*length(nodes_red.S)+1:end,:);

    ISh(:,:,i) = ISh(:,:,i-1) + dISh;
    VRh(:,:,i) = VRh(:,:,i-1) + dVRh;

    %% Convergence

    dx_max(i) = max(max(abs(dx_h)));
    df_max(i) = max(max(abs(df_h)));
    disp(['Convergence: dx_max = ' num2str(dx_max(i),'%.2e')...
                        ', df_max = ' num2str(df_max(i),'%.2e')]);%...
%                         ', cond(df_dx) = ' num2str(cond_df_dx(i),'%.2e')...
%                         ', rho(df_dx) = ' num2str(max(abs(eig(df_dx))),'%.2e')]);
    
    if (dx_max(i)<=options.tolerance && dx_met == 0)
        dx_met = 1;
        disp(['Convergence criterion (dx) met after ' int2str(i-1) ' iterations.']);
    end
    if (df_max(i)<=options.tolerance && df_met == 0)
        df_met = 1;
        disp(['Convergence criterion (df) met after ' int2str(i-1) ' iterations.']);
    end
    if (dx_met == 1 && df_met == 1)
        disp(['HPF (Newton-Raphson) converged after ' int2str(i-1) ' iterations.']);
        disp(' ');
%         convergence.cond = cond_df_dx(i);
%         convergence.rho  = max(abs(eig(df_dx)));
        break;
    end
end

%% Write Output

%% Write Output

n_iter = i-1;

if options.kronReduction == 1 && ~isempty(nodes.internal)

    V_h = zeros([size(V_h_0),n_iter+1]);
    I_h = zeros([size(I_h_0),n_iter+1]);

    % Kron reconstruct
    for i = 1:size(V_h,3)
            V_h(:,:,i) = KronTechnique.reconstruct(Y_h_full,[nodes.S,nodes.R]',[VSh_res(:,:,i);VRh(:,:,i)],n_phases);
            for k = 1:h_max+1
                I_h(:,k,i) = Y_h_full(:,:,k)*V_h(:,k,i);
            end
    end

    disp(' ');
    disp('Kron Reduction - maximum violation:');   
    
    idx_S = reshape((nodes.S-1)*n_phases + (1:n_phases)',1,[])';
    idx_R = reshape((nodes.R-1)*n_phases + (1:n_phases)',1,[])';

    dI_max_S = max(max(abs(I_h(idx_S,:,end)-ISh(:,:,n_iter+1))));
    dI_max_R = max(max(abs(I_h(idx_R,:,end)-IRh_res(:,:,n_iter+1))));

    disp(table(dI_max_S,dI_max_R));
else
    
    idx_S = reshape((nodes.S-1)*n_phases + (1:n_phases)',1,[])';
    idx_R = reshape((nodes.R-1)*n_phases + (1:n_phases)',1,[])';
    
    I_h(idx_S,:,:) = ISh(:,:,1:i);
    I_h(idx_R,:,:) = IRh_res(:,:,1:i);
    V_h(idx_S,:,:) = VSh_res(:,:,1:i);
    V_h(idx_R,:,:) = VRh(:,:,1:i);

end

disp('HPF (Newton-Raphson): stop.');
disp(' ');

disp('##########');
t_exec = toc(timer);
disp(['Execution time: ' num2str(t_exec) ' s.']);

end

