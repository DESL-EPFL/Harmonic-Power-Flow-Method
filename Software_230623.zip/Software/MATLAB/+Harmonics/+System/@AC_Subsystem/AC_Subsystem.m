classdef AC_Subsystem < Harmonics.System.Subsystem
    % ACDC_SYSTEM Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        slack;
        resources_forming;
        resources_following;
        passive_loads;
    end
    
    methods
        function obj = AC_Subsystem(grid,slack,resources_forming,resources_following,passive_loads)
            % obj = AC_Subsystem(grid,slack,resources_forming,resources_following,passive_loads)
            
            import Harmonics.*;
            import Harmonics.Grid.*;
            import Harmonics.Resource.*;
            
            obj = obj@Harmonics.System.Subsystem(grid);

            if(~isa(slack,'Thevenin'))
                error('slack_node: type.');
            elseif(xor(~isa(resources_forming,'CIR_V'),...
                       isempty(resources_forming)))
                error('resources_forming: type.');
            elseif(xor(~(isa(resources_following,'CIR_I')),...
                       isempty(resources_following)))  
                error('resources_following: type.');
            elseif(~(isa(passive_loads,'RLC_S_Load')||...
                     isa(passive_loads,'RLC_P_Load')))
                error('passive_loads: type.');
            else
                obj.slack = slack;
                obj.resources_forming = resources_forming;
                obj.resources_following = resources_following;
                obj.passive_loads = passive_loads;
            end
        end
        
        function n = getNumberOfResources(obj)
            n.slack   = length(obj.slack);
            n.form    = length(obj.resources_forming);
            n.follow  = length(obj.resources_following);
            n.passive = length(obj.passive_loads);
        end
        
        function nodes = getNodePartition(obj)
            
            import Harmonics.*;
            import Harmonics.Grid.*;
            
            N_slack = {obj.slack.node};
            [found_slack,nodes.slack] = Node.findByName(obj.grid.nodes,N_slack);
            if(~all(found_slack))
                error('slack_node.');
            end
            
            if ~isempty(obj.resources_forming)
                N_form = {obj.resources_forming.node};
                [found_form,nodes.form] = Node.findByName(obj.grid.nodes,N_form);
                if(~all(found_form))
                    error('resources_forming.');
                end
            else
                N_form = {};
                nodes.form = [];
            end
            
            N_follow = {obj.resources_following.node};
            [found_follow,nodes.follow] = Node.findByName(obj.grid.nodes,N_follow);
            if(~all(found_follow))
                error('resources_following.');
            end

            N_passive = {obj.passive_loads.node};
            [found_passive,nodes.passive] = Node.findByName(obj.grid.nodes,N_passive);
            if(~all(found_passive))
                error('passive_loads.');
            end
            
            N_resources = [N_slack,N_form,N_follow,N_passive];
            N_internal = setdiff({obj.grid.nodes.name},N_resources); % internal nodes
            [found_internal,nodes.internal] = Node.findByName(obj.grid.nodes,N_internal);
            if(~all(found_internal))
                error('internal.');
            end
        end
        
        % HPF
        [VSh,IRh,dVSh_dISh,dIRh_dVRh,O_V_h,O_I_h] = calculateResourceQuantities(obj,Ts,f_1,h_max,ISh,VRh,O_V_h,O_I_h,nodes,base,options)
        [V_h,I_h,n_iter,t_exec] = solveNewtonRaphson(obj,Ts,f_1,h_max,V_h_0,I_h_0,O_V_h_0,O_I_h_0,base,options);

        % TDS
        [] = initializeTimeDomainSimulation(obj,modelName,subsystemName)
        [t_exec,t_proc,simOut] = runTimeDomainSimulation(obj,modelName,subsystemName,h_max,Ts)
    end
end