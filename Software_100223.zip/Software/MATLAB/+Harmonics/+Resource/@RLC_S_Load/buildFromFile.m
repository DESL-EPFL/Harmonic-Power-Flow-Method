function load = buildFromFile(file,number_of_wires,base,f_1)
% load = buildFromFile(file,base,f_1,type)

import Harmonics.*;
import Harmonics.Resource.*;

if(~isa(file,'char'))
    error('file: type.');
else
    
    
    %% Read
    
    [numeric,text,raw] = xlsread(file,'Node');
    node = raw{2,1};
    index = raw{2,2};
    
    % Reference
    
    [numeric,text,raw] = xlsread(file,'Reference');
    P_reference = numeric(1);
    Q_reference = numeric(2);
%     S_ref_ph = (P_reference + 1j*Q_reference)/3;
    
    % Coefficients
    
    [numeric,text,raw] = xlsread(file,'Coefficients');
    if number_of_wires == 3
        alpha = numeric(1:3)';
    else
        alpha = numeric(1)';
    end
    
%     % Phase powers
%     S_ref_ph = alpha*(P_reference + 1j*Q_reference)/3;
%     
%     % Output impedance
%     V_rms = base.getBaseVoltage()/sqrt(2);
%     
%     Z = -V_rms^2./conj(S_ref_ph);
%     
%     R = real(Z);
% %     R(S_ref_ph == 0)= 0;
%     L = imag(Z)/(2*pi*f_1);
% %     L(S_ref_ph == 0)= 0;
%     warning('Check impedance calculation for P = 0 in detail.');

    %% Build
    
    load = RLC_S_Load(node,index,P_reference,Q_reference,alpha);%R,L,
end

end