function control_software = buildControlSoftware(L_stage,C_stage,f_1,base)
% control_software = buildControlSoftware(L_stage,C_stage,f_1,base)

import Harmonics.Resource.*;

if(~isa(L_stage,'PI_Loop_L'))
    error('L_stage: type.'),
elseif(~isa(C_stage,'PI_Loop_C'))
    error('C_stage: type.');
elseif(~isa(f_1,'numeric'))
    error('f_1: type.');
else
    h = 0;
    
    [KA_FT,KA_FF,KA_FB,TA_FB] = L_stage.buildSoftwareModel(f_1,base);
    [KG_FT,KG_FF,KG_FB,TG_FB] = C_stage.buildSoftwareModel(f_1,base);
    
    Z = zeros(2,2); % Zero matrix (w.r.t. DQ frame).
    I = eye(2); % Identity matrix (w.r.t. DQ frame).
    
    A_h = [Z,KG_FB/TG_FB;Z,Z];
    B_h = [-I,-KG_FB,KG_FT;Z,-I,Z];
    E_h = [KG_FF+KG_FB;I];
    
    C_h = [KA_FB/TA_FB,(KA_FF+KA_FB)*KG_FB/TG_FB];
    D_h = [-KA_FB,KA_FT-(KA_FF+KA_FB)*KG_FB,(KA_FF+KA_FB)*KG_FT];
    F_h = (KA_FF+KA_FB)*(KG_FF+KG_FB);
    
    control_software = LTP_System(h,A_h,B_h,C_h,D_h,E_h,F_h);
end

end